import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

class ScanCodeController extends GetxController {
  var currentIndex = 0.obs;
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? qrController;


  @override
  void onInit() {
    super.onInit();
    _requestCameraPermission();
  }

  Future<void> _requestCameraPermission() async {
    var status = await Permission.camera.status;
    if (!status.isGranted) {
      await Permission.camera.request();
    }
  }


  @override
  void onClose() {
    qrController?.dispose();
    super.onClose();
  }
}

class ScanCodeScreen extends StatelessWidget {
  final ScanCodeController controller = Get.put(ScanCodeController());

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Color(0xFFF2E7FE), // Light purple background color
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black54),
            onPressed: () => Get.back(),
          ),
          title: Text('Scan Code', style: TextStyle(color: Colors.black)),
          centerTitle: false,
          bottom: TabBar(
            indicatorColor: Colors.blueAccent, // Active tab underline color
            labelColor: Colors.black,           // Active tab text color
            unselectedLabelColor: Colors.grey,  // Inactive tab text color
            tabs: [
              // Tab(text: 'Scan code'),
              // Tab(text: 'My code'),
              Tab(
                icon: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                   // Icon(Icons.group, size: 16), // Group icon
                    SizedBox(width: 5), // Spacing between icon and text
                    Text('Scan code'),
                  ],
                ),
              ),
              Tab(
                icon: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                //    Icon(Icons.person, size: 16), // Friends icon
                    SizedBox(width: 5), // Spacing between icon and text
                    Text('My code'),
                  ],
                ),
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // First Tab - Scan Code
            buildScanCodeTab(controller),

            // Second Tab - My Code (QR Code and Share)
            buildMyCodeTab(context),
          ],
        ),
      ),
    );
  }

  // QR Scanner UI

  Widget buildScanCodeTab(ScanCodeController controller) {
    return Stack(
      children: [
        // This will fill the background
        Positioned.fill(
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Center(
                  child: Text(
                    'Place the QR code inside the area',
                    style: TextStyle(color: Colors.black54, fontSize: 16),
                  ),
                ),
              ),
              // QRView with reduced size
              SizedBox(
                width: 250, // Set desired width here
                height: 250, // Set desired height here
                child: QRView(
                  key: controller.qrKey,
                  onQRViewCreated: (QRViewController qrController) {
                    controller.qrController = qrController;
                    qrController.scannedDataStream.listen((scanData) {
                      // Handle the scanned data
                      print(scanData.code);
                    });
                  },
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(), // Empty space below the scanner
              ),
            ],
          ),
        ),

        // Positioned.fill(
        //   child: Column(
        //     children: [
        //       Expanded(
        //         flex: 1,
        //         child: Center(
        //           child: Text(
        //             'Place the QR code inside the area',
        //             style: TextStyle(color: Colors.black54, fontSize: 16),
        //           ),
        //         ),
        //       ),
        //       AspectRatio(
        //         aspectRatio: 1, // Square ratio
        //         child: Container(
        //           child: QRView(
        //             key: controller.qrKey,
        //             onQRViewCreated: (QRViewController qrController) {
        //               controller.qrController = qrController;
        //               qrController.scannedDataStream.listen((scanData) {
        //                 // Handle the scanned data
        //                 print(scanData.code);
        //               });
        //             },
        //           ),
        //         ),
        //       ),
        //       Expanded(
        //         flex: 1,
        //         child: Container(), // Empty space below the scanner
        //       ),
        //     ],
        //   ),
        // ),



        // no  need
        // Create an overlay to darken areas outside the square
        // Positioned.fill(
        //   child: IgnorePointer(
        //     child: Column(
        //       children: [
        //         Expanded(
        //           flex: 1,
        //           child: Container(
        //             color: Colors.black.withOpacity(0.5),
        //           ),
        //         ),
        //         Row(
        //           children: [
        //             Expanded(
        //               flex: 1,
        //               child: Container(
        //                 color: Colors.black.withOpacity(0.5),
        //               ),
        //             ),
        //             AspectRatio(
        //               aspectRatio: 1, // This is where the QR scanner is
        //               child: Container(
        //                 decoration: BoxDecoration(
        //                   border: Border.all(color: Colors.white, width: 4),
        //                 ),
        //               ),
        //             ),
        //             Expanded(
        //               flex: 1,
        //               child: Container(
        //                 color: Colors.black.withOpacity(0.5),
        //               ),
        //             ),
        //           ],
        //         ),
        //         Expanded(
        //           flex: 1,
        //           child: Container(
        //             color: Colors.black.withOpacity(0.5),
        //           ),
        //         ),
        //       ],
        //     ),
        //   ),
        // ),
      ],
    );
  }

  // Widget buildScanCodeTab(ScanCodeController controller) {
  //   return Column(
  //     children: [
  //       Expanded(
  //         flex: 4,
  //         child: QRView(
  //           key: controller.qrKey,
  //           onQRViewCreated: (QRViewController qrController) {
  //             controller.qrController = qrController;
  //             qrController.scannedDataStream.listen((scanData) {
  //               // Handle the scanned data
  //               print(scanData.code);
  //               // Optionally navigate or process scanned data
  //             });
  //           },
  //         ),
  //       ),
  //       Expanded(
  //         flex: 1,
  //         child: Center(
  //           child: Text(
  //             'Place the QR code inside the area',
  //             style: TextStyle(color: Colors.black54, fontSize: 16),
  //           ),
  //         ),
  //       ),
  //     ],
  //   );
  // }

  // My Code Tab UI
  Widget buildMyCodeTab(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // QR Code Box
          Container(
            width: MediaQuery.of(context).size.width*.9,
            height: 250,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 6,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: Icon(Icons.qr_code, size: 220),
            ),
          ),
          SizedBox(height: 20),

          // Shareable Link Section with Copy Icon inside
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: Colors.white,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Splitwise.com/sharecode',
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 14,
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.copy, color: Colors.blueAccent),
                  onPressed: () {
                    // Copy to clipboard logic
                    Clipboard.setData(ClipboardData(text: 'Splitwise.com/sharecode'));
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Link copied to clipboard')),
                    );
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 20),

          // Share Code Button with matching UI
          ElevatedButton.icon(
            onPressed: () {
              Share.share('Join me on Splitwise: Splitwise.com/sharecode');
            },
            icon: Icon(Icons.share, color: Colors.white),
            label: Text('Share Code', style: TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(

              backgroundColor:    Color(0xFF8082ED), // Button color
              minimumSize: Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          SizedBox(height: 20),

          // Additional note
          Text(
            'Your code can be used by anyone to add you, so share it only with trusted individuals.',
            style: TextStyle(color: Colors.black54, fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
