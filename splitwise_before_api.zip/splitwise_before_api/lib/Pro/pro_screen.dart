import 'package:flutter/material.dart';


class ProScreen extends StatefulWidget {
  const ProScreen({super.key});

  @override
  State<ProScreen> createState() => _ProScreenState();
}

class _ProScreenState extends State<ProScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: Text("PRO"),
        centerTitle: true,
        backgroundColor: Colors.grey.shade100,
        automaticallyImplyLeading: false,
      ),
      body: Center(child:
      Image.asset("assets/images/comingsoon.png",width: 200,height: 200,)
      ),
    );
  }
}
