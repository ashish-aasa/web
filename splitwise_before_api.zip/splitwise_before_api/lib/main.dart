import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:splitwise/SplashScreen/ui/Splash_screen.dart';
import 'package:splitwise/utils/translations.dart';

import 'widgets/firebase_options.dart';


// void main(){
void main() async{
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Activate Firebase App Check
  await FirebaseAppCheck.instance.activate(
    androidProvider: AndroidProvider.playIntegrity,  // Use Play Integrity for Android
   //  appleProvider: AppleProvider.deviceCheck,        // Use DeviceCheck for iOS
  );



  // Load selected language from SharedPreferences
 //  SharedPreferences prefs = await SharedPreferences.getInstance();
  // String selectedLanguage = prefs.getString('selectedLanguage') ?? 'en_US';

  // Set the locale based on the selected language
  // Get.updateLocale(Locale(
  //   selectedLanguage.split('_')[0],
  //   selectedLanguage.split('_')[1],
  // ));
  runApp(const MainScreen());
}
class MainScreen  extends StatelessWidget {
  const MainScreen({super.key});


  @override
  Widget build(BuildContext context) {

    // return   MaterialApp(
    return   GetMaterialApp(
      translations: AppTranslations(),
     // locale: Get.deviceLocale, // Default locale based on device settings
    //  fallbackLocale: Locale('en', 'US'),
      debugShowCheckedModeBanner: false,
      home:  SplashScreen(),
    );
  }
}