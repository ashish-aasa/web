import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/passcode/add_new_passcode.dart';
import 'package:splitwise/utils/colors.dart';

class PasscodeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FC), // Background color matching the image
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Passcode',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Circular Gradient Icon (lock)
            SizedBox(height: MediaQuery.of(context).size.height*.1,),
            // Container(
            //   width: 150,
            //   height: 150,
            //   decoration: BoxDecoration(
            //     shape: BoxShape.circle,
            //     gradient: LinearGradient(
            //       colors: [Color(0xFF8184E7), Color(0xFF92C6FF)], // Match gradient from the image
            //       begin: Alignment.topCenter,
            //       end: Alignment.bottomCenter,
            //     ),
            //   ),
            //   child: Center(
            //     child: Icon(
            //       Icons.lock_outline,
            //       color: Colors.white,
            //       size: 100,
            //     ),
            //   ),
            // ),
            Image.asset("assets/images/passcodeimg.png"),
            SizedBox(height: 50), // Space between icon and button

            // Outlined Button for "Add a new passcode"
            OutlinedButton.icon(
              onPressed: () {
                // Define your logic for adding a passcode here
                Navigator.push(    context, MaterialPageRoute(builder: (context) => AddNewPasscode()));

              },
              icon: Icon(
                Icons.lock_outline,
                color:uitext, // Icon color matching the outline button border color
              ),
              label: Text(
                'Add a new passcode',
                style: TextStyle(
                  color: uitext, // Text color matching the outline button border color
                  fontWeight: FontWeight.normal,
                  fontSize: 16,
                ),
              ),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                side: BorderSide(
                  color: uitext, // Border color
                  width: 1, // Border width
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30), // Rounded corners
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

