import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/passcode/change_passcode_old.dart';



class PasscodeSettingController extends GetxController {
  // Observable variable to track the passcode switch
  var isPasscodeEnabled = true.obs;
}


class PasscodeSetting extends StatelessWidget {
  final PasscodeSettingController controller = Get.put(PasscodeSettingController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FC),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Passcode',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Circular Gradient Icon (lock)
            SizedBox(height:MediaQuery.of(context).size.height*.1 ,),
            Image.asset("assets/images/passcodeimg.png"),
            // Container(
            //   width: 150,
            //   height: 150,
            //   decoration: BoxDecoration(
            //     shape: BoxShape.circle,
            //     gradient: LinearGradient(
            //       colors: [Color(0xFF8184E7), Color(0xFF92C6FF)],
            //       begin: Alignment.topCenter,
            //       end: Alignment.bottomCenter,
            //     ),
            //   ),
            //   child: Center(
            //     child: Icon(
            //       Icons.lock_outline,
            //       color: Colors.white,
            //       size: 100,
            //     ),
            //   ),
            // ),
            SizedBox(height: 40), // Space between icon and toggle switch

            // Toggle Switch for "Turn off/on passcode"
            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Turn off/on passcode',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Obx(() {
                    return Switch(
                      value: controller.isPasscodeEnabled.value,
                      onChanged: (newValue) {
                        controller.isPasscodeEnabled.value = newValue;
                      },
                      activeColor: Color(0xFF8184E7), // Match switch active color
                    );
                  }),
                ],
              ),
            ),
            SizedBox(height: 40), // Space between toggle and button

            // Elevated Button for "Change your passcode"
            ElevatedButton.icon(
              onPressed: () {
                // Define your logic for changing passcode
                Get.to(() => ChangePasscodeOld());
              },
              icon: Icon(Icons.sync, color: Colors.white),
              label: Text(
                'Change your passcode',
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: 16,color: Colors.white
                ),
              ),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                backgroundColor: Color(0xFF8184E7),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

