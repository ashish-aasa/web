import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/passcode/reenter_passocde.dart';
import 'package:splitwise/utils/colors.dart';

import '../widgets/otp_widget.dart';


class AddnewpasscodeController extends GetxController {
  var currentIndex = 0.obs;
  RxBool isentered =false.obs;
  RxBool isresententered =false.obs;



  @override
  void onInit() {
    super.onInit();

  }
}


class AddNewPasscode extends StatelessWidget {


  final AddnewpasscodeController controller = Get.put(AddnewpasscodeController());


  Future<void> _onOTPCompleted(String otp) async {
    print("OTP Entered: $otp");
    // Handle OTP submission here
    try {
      print("otp is : " + otp.toString());
      controller.isentered.value= true;
       Get.to(() => ReenterPassocde());
    } catch (e) {
      Get.snackbar("Error".tr, e.toString(),
          backgroundColor: Colors.red, colorText: Colors.white);
    }

  }


  Future<void> _onOTPCompletedresend(String otp) async {
    print("OTP resend Entered: $otp");
    // Handle OTP submission here
    try {
      print("otp resend is : " + otp.toString());
      controller.isresententered.value= true;
      // Get.to(() => RegisterAsCompanyPage());
    } catch (e) {
      Get.snackbar("Error".tr, e.toString(),
          backgroundColor: Colors.red, colorText: Colors.white);
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FC), // Background color matching the image
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Add Passcode',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Circular Gradient Icon (lock)
            SizedBox(height: MediaQuery.of(context).size.height*.1,),
            // Container(
            //   width: 150,
            //   height: 150,
            //   decoration: BoxDecoration(
            //     shape: BoxShape.circle,
            //     gradient: LinearGradient(
            //       colors: [Color(0xFF8184E7), Color(0xFF92C6FF)], // Match gradient from the image
            //       begin: Alignment.topCenter,
            //       end: Alignment.bottomCenter,
            //     ),
            //   ),
            //   child: Center(
            //     child: Icon(
            //       Icons.lock_outline,
            //       color: Colors.white,
            //       size: 100,
            //     ),
            //   ),
            // ),
            Image.asset("assets/images/passcodeimg.png",width: 80,height: 80,),
            SizedBox(height: 40), // Space between icon and button




            Text(
              'Enter your new passcode',
              style: TextStyle(
                color: uitext, // Text color matching the outline button border color
                fontWeight: FontWeight.normal,
                fontSize: 16,
              ),
            )
                ,


            // Outlined Button for "Add a new passcode"

            Padding(
              padding: const EdgeInsets.only(left: 20,right: 20),
              child: OTPWidget(
                length: 6, // Length of the OTP
                onCompleted: _onOTPCompleted,
              ),
            ),

          ],
        ),
      ),
    );
  }
}

