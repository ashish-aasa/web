// To parse this JSON data, do
//
//     final currencyResponseModel = currencyResponseModelFromJson(jsonString);

import 'dart:convert';

CurrencyResponseModel currencyResponseModelFromJson(String str) => CurrencyResponseModel.fromJson(json.decode(str));

String currencyResponseModelToJson(CurrencyResponseModel data) => json.encode(data.toJson());

class CurrencyResponseModel {
  int? status;
  String? message;
  List<Datum>? data;

  CurrencyResponseModel({
    this.status,
    this.message,
    this.data,
  });

  factory CurrencyResponseModel.fromJson(Map<String, dynamic> json) => CurrencyResponseModel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  String? currencyCode;
  String? currencyName;

  Datum({
    this.currencyCode,
    this.currencyName,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    currencyCode: json["currency_code"],
    currencyName: json["currency_name"],
  );

  Map<String, dynamic> toJson() => {
    "currency_code": currencyCode,
    "currency_name": currencyName,
  };
}
