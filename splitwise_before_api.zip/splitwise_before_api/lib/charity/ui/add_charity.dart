import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';


class AddCharityController extends GetxController {
  var selectedFriend = 'Select'.obs;
  var selectedPaidBy = 'Friend 1'.obs;
  var selectedSplitOption = 'equally'.obs;
  var selectedDate = 'Date'.obs;
  var selectedImageName = 'Upload Receipt'.obs;
  var notes = ''.obs;

  var paidAmount = 20000.obs;
  var participants = [
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "User Name", "share": 0.obs}
  ].obs;






}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      home: AddCharity(),
    );
  }
}

class AddCharityDetailController extends GetxController {
  var selectedCurrency = ''.obs;
  RxBool isLoading = false.obs;
  Rx<XFile?> selectedScreenshot = Rx<XFile?>(null);

  void setSelectedCurrency(String currency) {
    selectedCurrency.value = currency;
    Get.back(); // Close the popup after selection
  }


  Future<void> pickScreenshot() async {
    isLoading.value = true;
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.gallery).then((value) {
      selectedScreenshot.value = value;
      print("skillllling pick get c" + selectedScreenshot.value.toString());
    });
    isLoading.value = false;
  }

  void removeScreenshot() {
    selectedScreenshot.value = null;
  }

  var selectedCurrencies = <String>[].obs; // List to store selected items

  void toggleCurrencySelection(String currency) {
    if (selectedCurrencies.contains(currency)) {
      selectedCurrencies.remove(currency);
    } else {
      selectedCurrencies.add(currency);
    }
  }
}

class AddCharity extends StatelessWidget {
  final AddCharityController controller = Get.put(AddCharityController());
  final AddCharityDetailController currencyController = Get.put(AddCharityDetailController());

  final List<String> friends = ['Friend 1', 'Friend 2', 'Friend 3'];
  final List<String> splitOptions = ['equally', 'unequally', 'percentage'];
  late double width;
  late double height;

  final List<String> currencies = [
    // 'All Members of group name',
    'All Members ',
    'Friend 1',
    'Friend 2',
    'Friend 3',
    'Friend 4',
    'Friend 5',
    'Friend 6',

  ];
  void _showCurrencyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Members',style: TextStyle(fontSize: 18),),
          content: Container(
            width: double.infinity,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: currencies.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: double.infinity,
                  child: Obx(() {
                    bool isSelected = currencyController.selectedCurrencies.contains(currencies[index]);

                    return GestureDetector(
                      onTap: () {
                        currencyController.toggleCurrencySelection(currencies[index]);
                      },
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    currencies[index],
                                    style: TextStyle(fontSize: 13),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Icon(
                                  isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                                  color: isSelected ? Colors.blue : Colors.grey,
                                ),

                              ],
                            ),
                          ),
                          Divider(height: 2,
                            color:Colors.grey[300],
                          )
                        ],
                      ),
                    );
                  }),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('Done'),
            ),
          ],
        );
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Add Charity'),
            Text('Group Name', style: TextStyle(color: Colors.red,fontSize: 17)),
          ],
        ),
      ),
      body: SingleChildScrollView(
        // color: Colors.grey.shade100,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Group Name



            // With you and Select Dropdown

            Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Row(
                children: [
                  Text('With you and:'),
                  SizedBox(width: 10),
                  GestureDetector(
                    onTap: () => _showCurrencyDialog(context),
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child:

                      Obx(() {
                        String selectedText = currencyController.selectedCurrencies.isEmpty
                            ? 'Select'
                            : currencyController.selectedCurrencies.join(', ');


                        return

                          Container(
                            constraints: BoxConstraints(
                              maxWidth: 190, // Set a max width to allow scrolling
                            ),
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal, // Enables horizontal scrolling
                              child: Text(
                                selectedText,
                                style: TextStyle(
                                  color: selectedText == 'Select' ? Colors.black : Colors.black,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          );

                      }),
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height:height *.05,),

            Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Text('Add Description'),
            ),
            SizedBox(height: 10,),
            // Description field
            // TextField(
            //   decoration: InputDecoration(
            //     labelText: 'Add Description',
            //     border: OutlineInputBorder(),
            //   ),
            // ),

            Padding(
              padding: const EdgeInsets.only(left: 16,right: 16),
              child: TextField(
                //  onChanged: controller.setGroupName,


                decoration: InputDecoration(
                  filled: true,  // Enables filling the background
                  fillColor: Colors.white,
                  hintText: 'Add Description',  // Hint text

                  hintStyle: TextStyle(
                    color: Colors.grey,  // Hint text color
                    fontSize: 16,  // Font size
                    fontWeight: FontWeight.w400,  // Optional: Font weight
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20), // Set the border radius here
                    borderSide: BorderSide(color: Colors.white ), // Optional: customize border color
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize enabled border color
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize focused border color
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),

            // Amount section
            Container(
              color: Colors.white,
              height: 100,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Container(
                      width: 100,
                      child: OutlinedButton(
                        onPressed: () {
                          // Handle Payment ID


                        },
                        style: OutlinedButton.styleFrom(
                          // side: BorderSide(color: Colors.grey[700]!),
                          side: BorderSide(color:Color(0xFF233f78),),
                          padding: EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(13),
                          ),
                        ),
                        child: Text(
                          'Amount (₹)',
                          style: TextStyle(fontSize: 16, color: Color(0xFF233f78),),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: TextField(
                        style: TextStyle(
                          fontSize: 20,  // Set font size to 20
                        ),
                        textAlign: TextAlign.right,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: '0',
                          //  border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                ],
              ),
            ),
            SizedBox(height: 10),


            // Paid by and Split options

            //   Spacer(),


          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.grey.shade100,
        child:  Obx(() => Container(

          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 3.0,
              colors:   currencyController.selectedCurrencies.isEmpty ?

              [
                Color(0xFF5278C7).withOpacity(0.4), // #5278C7
                Color(0xFF233F78).withOpacity(0.4), // #233F78
              ]:
              [
                Color(0xFF5278C7), // #5278C7
                Color(0xFF233F78), // #233F78
              ],
            ),
            borderRadius: BorderRadius.circular(30), // Same as button radius
          ),
          child: ElevatedButton(
            onPressed: null,

            //  controller.canCreateGroup() ? () {} : null,
            style: ElevatedButton.styleFrom(

              minimumSize: Size(double.infinity, 50),
              backgroundColor: Colors.grey[400],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text('Save', style: TextStyle(fontSize: 18,color: Colors.white)),
          ),
        )),
      ),
    );
  }
}
