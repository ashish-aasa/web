import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:splitwise/charity/ui/add_charity.dart';
import 'package:splitwise/charity/ui/edit_charity.dart';
import 'package:splitwise/utils/colors.dart';

class CharityController extends GetxController {
  var expenseTitle = "Chairty".obs;
  var expenseAmount = 20000.obs;
  var paidAmount = 20000.obs;

  var participants = [
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "User Name", "share": 4000.obs}
  ].obs;
  var expenseDate = "06 August 2024".obs;
  var notes =
      "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, to"
          .obs;
  var photo = "photo.jpg".obs;
}

class CharityDetails extends StatelessWidget {
  final CharityController controller = Get.put(CharityController());
  late double width;
  late double height;

  final AddCharityDetailController currencyController = Get.put(AddCharityDetailController());
  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    var username = "username".obs;
    return Scaffold(
      appBar: AppBar(
        title: Text('Charity Details'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Expense Section
              Container(
                width: width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  //  color: Colors.grey[200],
                  gradient: LinearGradient(
                    colors: [cardColor, cardColor2,cardColor2],
                    stops: [0.001, 0.5, 0.8], // Stops for each color
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),

                ),
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    //    Icon(Icons.image, size: 60, color: Colors.grey),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(""),
                        Padding(
                          padding: const EdgeInsets.only(left: 25),
                          child: Container(
                            width: 40,
                            height: 40,
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child:
                                Image.asset("assets/images/grp1.png")
                              // Image.network(
                              //   'https://your-image-url.com', // replace with your image URL
                              //   width: 60,
                              //   height: 60,
                              //   fit: BoxFit.cover,
                              // ),
                            ),
                          ),
                        ),
                        GestureDetector(onTap: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => EditCharity()),
                          );
                        },
                            child:
                        Image.asset("assets/images/PencilSimple.png",width: 25,height: 25,))
                      ],
                    ),
                    SizedBox(height: 8),
                    Obx(() => Text(controller.expenseTitle.value,
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold,color: Colors.white))),
                    SizedBox(height: 4),
                    Obx(() => Text("₹${controller.expenseAmount.value}",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold,color: Colors.white))),
                  ],
                ),
              ),
              SizedBox(height: 16),

              // Date

              SizedBox(height: 8),

              // You Paid and Friends' Shares

              SizedBox(height: 16),

              // Notes Section
              Text("Description", style: TextStyle(fontSize: 16)),
              SizedBox(height: 8),
              Obx(() => Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey),
                ),
                child: Text(controller.notes.value),
              )),
              SizedBox(height: 16),

              // Photo Section
              Text("Charity opened by :", style: TextStyle(fontSize: 16)),
              SizedBox(height: 8),
              Obx(() => Container(
                padding: EdgeInsets.all(12),
                // decoration: BoxDecoration(
                //   borderRadius: BorderRadius.circular(8),
                //   border: Border.all(color: Colors.grey),
                // ),
                child: Row(
                  children: [
                    // Icon(Icons.image, size: 40, color: Colors.grey),
                    // Image.asset("assets/images/jpeg.png"),
                    // SizedBox(width: 8),
                    Text(username.value),
                  ],
                ),
              )),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.grey.shade100,
        child:  Obx(() => Container(

          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 3.0,
              colors:   currencyController.selectedCurrencies.isEmpty ?

              [
                Color(0xFF5278C7).withOpacity(0.4), // #5278C7
                Color(0xFF233F78).withOpacity(0.4), // #233F78
              ]:
              [
                Color(0xFF5278C7), // #5278C7
                Color(0xFF233F78), // #233F78
              ],
            ),
            borderRadius: BorderRadius.circular(30), // Same as button radius
          ),
          child: ElevatedButton(
            onPressed: null,

            //  controller.canCreateGroup() ? () {} : null,
            style: ElevatedButton.styleFrom(

              minimumSize: Size(double.infinity, 50),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text('Close Charity', style: TextStyle(fontSize: 18,color: Colors.white)),
          ),
        )),
      ),
    );
  }
}

