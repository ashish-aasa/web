import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


const Color textColor1 = Color.fromRGBO(0, 0, 0, 1);

const Color black = Colors.black;
const Color iconColor = Color.fromRGBO(48, 70, 116, 1);
const Color cardColor = Color.fromRGBO(233, 255, 172, 1);
const Color cardColor2 = Color.fromRGBO(107,143,233,1);
const Color twoui = Color.fromRGBO(82,120,199,1);
const Color uitext = Color.fromRGBO(35,63,120,1);

const Color transparent = Colors.transparent;

var fontZillaSlab = GoogleFonts.zillaSlab;
var fontQuicksand = GoogleFonts.quicksand;
var fontNunito = GoogleFonts.nunito;
