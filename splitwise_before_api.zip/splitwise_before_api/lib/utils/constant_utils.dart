import 'dart:math';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:splitwise/utils/shared_prefhelper.dart';


String generateOrderUniqueIdentifier(int length) {
  const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  Random random = Random();

  // Generate a random string of the specified length
  String randomString = String.fromCharCodes(
      Iterable.generate(
          length,
              (_) => characters.codeUnitAt(random.nextInt(characters.length))
      )
  );

  return randomString;
}

  void showToastSuccess(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.green,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

void showToastFail(String message) {
  Fluttertoast.showToast(
    msg: message,
    toastLength: Toast.LENGTH_SHORT,
    gravity: ToastGravity.CENTER,
    timeInSecForIosWeb: 1,
    backgroundColor: Colors.red,
    textColor: Colors.white,
    fontSize: 16.0,
  );
}

void showToastFaillong(String message) {
  Fluttertoast.showToast(
    msg: message,
    toastLength: Toast.LENGTH_SHORT,
    gravity: ToastGravity.CENTER,
    timeInSecForIosWeb: 10,
    backgroundColor: Colors.red,
    textColor: Colors.white,
    fontSize: 16.0,

  );
}





void showCustomToast(BuildContext context, String message, {int duration = 10}) {
  OverlayEntry overlayEntry = OverlayEntry(
    builder: (context) => Positioned(
      top: 50.0,
      left: MediaQuery.of(context).size.width * 0.1, // Adjust for center alignment
      width: MediaQuery.of(context).size.width * 0.8, // Set width for multiline
      child: Material(
        color: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
          decoration: BoxDecoration(
            color: Colors.red,
            borderRadius: BorderRadius.circular(25.0),
          ),
          child: Text(
            message,
            style: TextStyle(color: Colors.white, fontSize: 16.0),
            textAlign: TextAlign.center, // Align text to the center
            maxLines: 5, // Limit to 3 lines
            softWrap: true, // Ensure text wraps properly
            overflow: TextOverflow.ellipsis, // Add ellipsis if text exceeds
          ),
        ),
      ),
    ),
  );

  // Insert the overlay
  Overlay.of(context)?.insert(overlayEntry);

  // Remove the overlay after the specified duration
  Future.delayed(Duration(seconds: duration), () {
    overlayEntry.remove();
  });
}



   Future<String> getMarketdataToken() async {
  String token= await SharedPrefHelper().get("marketdatatoken");
  return token;
}


