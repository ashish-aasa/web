class AppUrl {
// code scanning all api
  //static const String liveBaseURL = "http://uat.vcqru.com/api/";
  static const String AppVersion="1.0.0";

  //----------comp_name
  static const String compName_qa="KD NoteBook";
  static const String comp_name=compName_qa;

  //-----Comp_id
  static const String compID_QA="Comp-1274";
  static const String Comp_Id=compID_QA;


  static const String QA_BaseURL1= "https://vrkableuat.afdd.com/api/";
  static const String ttblazebaseurlmarket = "https://ttblaze.iifl.com/apimarketdata/";
  // static const String shareriselogin = "http://212.38.94.48:8080/shareshiksha/api/v1/auth/authenticationForSharerise";
  static const String shareriselogin = "http://156.67.208.123:9339/shareshiksha/api/v1/auth/authenticationForSharerise";
  static const String baseUrl = ttblazebaseurlmarket;

  static const String LOGIN_PASS = baseUrl + "ApiLogin";
  static const String ttblazebaseurl = "https://ttblaze.iifl.com/";




}