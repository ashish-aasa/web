import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:splitwise/Expenses/ui/add_expense_details.dart';
import 'package:splitwise/Groups/ui/create_group.dart';
import 'package:splitwise/Groups/ui/group_page.dart';
import 'package:splitwise/utils/colors.dart';

import '../../Friend/ui/add_friend.dart';

class HomeController extends GetxController with SingleGetTickerProviderMixin {
  var currentIndex = 0.obs;
  late TabController tabController;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 2, vsync: this); // 2 tabs for Groups and Friends
  }

  @override
  void onClose() {
    tabController.dispose();
    super.onClose();
  }

  void changePage(int index) {
    currentIndex.value = index;
  }
}



// Controller using GetX for managing visibility of buttons
class FloatingButtonController extends GetxController {
  // Observable variable for button visibility
  var isButtonVisible = false.obs;

  // Function to toggle button visibility
  void toggleButtons() {
    isButtonVisible.value = !isButtonVisible.value;
  }
}

class HomeScreen extends StatelessWidget {
  final HomeController controller = Get.put(HomeController());
  // Create instance of controller
  final FloatingButtonController floatingButtonController = Get.put(FloatingButtonController());

  @override
  Widget build(BuildContext context) {
    return

  Scaffold(
      appBar: AppBar(
        title: Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: 'WELCOME, ',
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 17),
              ),
              TextSpan(
                text: 'User Name',
                style: TextStyle(color: Color(0xFFFC8F31), fontSize: 17),
              ),
            ],
          ),
        )
        ,
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        toolbarHeight: 60,
        automaticallyImplyLeading: false,
      ),
      body: _buildBody(context),

      // open this for old code
      // controller.currentIndex.value == 2
      //     ? PlusIconScreen()
      //     : _buildBody(context),
      // bottomNavigationBar: _buildBottomNavigationBar(),


      // floatingActionButton: FloatingActionButton(
      //   onPressed: () {
      //     // Plus Icon action
      //    // Get.to(() => PlusIconScreen());
      //   floatingButtonController.toggleButtons();
      //   },
      //   child:
      //
      //   Image.asset("assets/images/Group24.jpg")
      //
      // //  backgroundColor: Colors.red, // Adjust color
      //  // elevation: 5,
      // ),
     // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );

  }

  Widget _buildBody(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: controller.tabController,
                children: [
                  _buildGroupsTab(context),
                  _buildFriendsTab(context),
                ],
              ),
            ),

            // Floating buttons

          ],
        ),
        //center button
   /*     Obx(() {
          return floatingButtonController.isButtonVisible.value

              ? Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FloatingActionButton.extended(
                    onPressed: () {
                      // Add your charity action here
                    },
                    label: Text('Add Charity'),
              //      icon: Icon(Icons.favorite_border),
                    backgroundColor: Colors.white,
                    foregroundColor: uitext,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  SizedBox(height: 10),
                  FloatingActionButton.extended(
                    onPressed: () {
                      // Add your expense action here
                      Navigator.push(
                          context, MaterialPageRoute(builder: (context) => ExpenseScreen())
                      );
                    },
                    label: Text('Add Expense'),
                 //   icon: Icon(Icons.attach_money),
                    backgroundColor: Colors.white,
                    foregroundColor: uitext,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ],
              ),
            ),
          )
              : SizedBox.shrink(); // Empty widget when buttons are hidden
        }),*/
      ],
    );
  }

  // Widget _buildTabBar() {
  //   return TabBar(
  //     controller: controller.tabController,
  //     labelColor: Colors.black,
  //     unselectedLabelColor: Colors.grey,
  //     indicatorColor: Colors.black,
  //     tabs: [
  //       Tab(text: 'Groups'),
  //       Tab(text: 'Friends'),
  //     ],
  //   );
  // }

  Widget _buildTabBar() {
    return TabBar(
      controller: controller.tabController,
      labelColor: Colors.black,
      unselectedLabelColor: Colors.grey,
      indicatorColor: Colors.black,
      tabs: [
        Tab(
          icon: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.group, size: 16), // Group icon
              SizedBox(width: 5), // Spacing between icon and text
              Text('Groups'),
            ],
          ),
        ),
        Tab(
          icon: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.person, size: 16), // Friends icon
              SizedBox(width: 5), // Spacing between icon and text
              Text('Friends'),
            ],
          ),
        ),
      ],
    );
  }


  Widget _buildGroupsTab(BuildContext context) {
    return Column(
      children: [
        _buildSearchBar(Icons.group_add), // Search Bar for Groups with add icon outside
        GestureDetector(onTap: (){

          Navigator.push(
              context, MaterialPageRoute(builder: (context) => GroupPage())
          );
        },
            child: GroupCard()),

        Expanded(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
               // Icon(Icons.group, size: 100, color: Colors.grey[300]),
                SvgPicture.asset(
                  'assets/images/nofriend.svg',
                  width: 150, // specify width
                  height: 150, // specify height
                  //color: Color(0xFF233F78), // optional: colorize the SVG
                ),
                SizedBox(height: 10,),
                Text('No Groups here',
                    style: TextStyle(color: Colors.black, fontSize: 17,fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text(
                  'Once group is created, it will show here!',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
                SizedBox(height: 20),
                // ElevatedButton.icon(
                //   onPressed: () {},
                //   icon: Icon(Icons.group_add),
                //   label: Text('Create a group'),
                //   style: ElevatedButton.styleFrom(
                //     shape: StadiumBorder(),
                //   ),
                // ),
                OutlinedButton(
                  onPressed: () {
                    // Your onPressed function here
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => CreateGroupScreen())
                    );
                  },
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Color(0xFF233F78)), // Border color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30), // Rounded corners
                    ),
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20), // Padding
                  ),
                  child: Row(

                    mainAxisSize: MainAxisSize.min, // Ensures the button width adapts to content
                    children: [
                      SizedBox(width: 30),
                   //   Icon(Icons.group_add, size: 18, color: Colors.grey), // Add friend icon

                      SvgPicture.asset(
                        'assets/images/creategicon.svg',
                        width: 20, // specify width
                        height: 20, // specify height
                        color: Color(0xFF233F78), // optional: colorize the SVG
                      ),
                      SizedBox(width: 8), // Space between icon and text
                      Text(
                        'Create a group',
                        style: TextStyle(color: Color(0xFF233F78)), // Text color
                      ),
                      SizedBox(width: 40),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFriendsTab(BuildContext context) {
    return Column(
      children: [
        _buildSearchBar(Icons.person_add), // Search Bar for Friends with add icon outside
        Expanded(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                //Icon(Icons.person, size: 100, color: Colors.grey[300]),

                SvgPicture.asset(
                  'assets/images/nofriend.svg',
                  width: 150, // specify width
                  height: 150, // specify height
                  //color: Color(0xFF233F78), // optional: colorize the SVG
                ),
                SizedBox(height: 10),
                Text('No Friends here',
                    style: TextStyle(color: Colors.black, fontSize: 17,fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text(
                  'Once friend is added, it will show here!',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
                SizedBox(height: 20),
                OutlinedButton(
                  onPressed: () {
                    // Your onPressed function here
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => AddFriendScreen())
                    );
                  },
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Color(0xFF233F78)), // Border color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30), // Rounded corners
                    ),
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20), // Padding
                  ),
                  child: Row(

                    mainAxisSize: MainAxisSize.min, // Ensures the button width adapts to content
                    children: [
                      SizedBox(width: 30),
                     // Icon(Icons.person_add_alt_1, size: 18, color: Colors.grey), // Add friend icon
                      SvgPicture.asset(
                        'assets/images/addfriend.svg',
                        width: 20, // specify width
                        height: 20, // specify height
                        color: Color(0xFF233F78), // optional: colorize the SVG
                      ),
                      SizedBox(width: 8), // Space between icon and text
                      Text(
                        'Add friend',
                        style: TextStyle(color: Color(0xFF233F78)), // Text color
                      ),
                      SizedBox(width: 40),
                    ],
                  ),
                )

                // ElevatedButton.icon(
                //   onPressed: () {},
                //   icon: Icon(Icons.person_add),
                //   label: Text('Add friend'),
                //   style: ElevatedButton.styleFrom(
                //     shape: StadiumBorder(),
                //   ),
                // ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBar(IconData trailingIcon) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 8.0),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search, color: Colors.black),
             //    prefixIcon:    SvgPicture.asset(
             //      'assets/images/search-line.svg',
             //      width: 3, // specify width
             //      height: 3, // specify height
             //      color: Color(0xFF233F78), // optional: colorize the SVG
             //    ),
                hintText: 'Search...',
                hintStyle: TextStyle(
                  color: Colors.grey,  // Hint text color
                  fontSize: 16,  // Font size
                  fontWeight: FontWeight.w400,  // Optional: Font weight
                ),
                contentPadding: EdgeInsets.symmetric(vertical: 10),
                filled: true,
              //  fillColor: Colors.grey[200],
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          SizedBox(width: 8), // Space between search bar and icon
          CircleAvatar(
           // backgroundColor: Colors.grey[200], // Background color for icon
            backgroundColor: Colors.white, // Background color for icon
            child:
            //Icon(trailingIcon, color: Colors.grey),
            SvgPicture.asset(
              'assets/images/creategicon.svg',
              width: 20, // specify width
              height: 20, // specify height
              color: Color(0xFF233F78), // optional: colorize the SVG
            ),
          )
        ],
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Obx(() => BottomNavigationBar(
      currentIndex: controller.currentIndex.value,
      onTap: (index) {
        if (index == 2) {
          // Handle Plus Icon Click
          Get.to(() => PlusIconScreen());
        } else {
          controller.changePage(index);
        }
      },
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
            icon:
       // Icon(Icons.home),
            SvgPicture.asset(
              'assets/images/home.svg',
              width: 20, // specify width
              height: 20, // specify height
              color: Color(0xFF233F78), // optional: colorize the SVG
            ),

            label: 'Home'),


        BottomNavigationBarItem(icon:
      //  Icon(Icons.list),
        SvgPicture.asset(
          'assets/images/Pulse.svg',
          width: 20, // specify width
          height: 20, // specify height
          color: Color(0xFF233F78), // optional: colorize the SVG
        ),

            label: 'Activity'),
        BottomNavigationBarItem(
            icon:

           // Icon(Icons.add, size: 30),
            SvgPicture.asset(
              'assets/images/Group124.svg',
              width: 20, // specify width
              height: 20, // specify height
              color: Color(0xFF233F78), // optional: colorize the SVG
            ),

            label: ''), // Plus icon


        BottomNavigationBarItem(icon:

       // Icon(Icons.diamond),
        SvgPicture.asset(
          'assets/images/SketchLogo.svg',
          width: 20, // specify width
          height: 20, // specify height
          color: Color(0xFF233F78), // optional: colorize the SVG
        ),

            label: 'PRO'),
        BottomNavigationBarItem(icon:

       // Icon(Icons.person),
        SvgPicture.asset(
          'assets/images/account.svg',
          width: 20, // specify width
          height: 20, // specify height
          color: Color(0xFF233F78), // optional: colorize the SVG
        ),
            label: 'Account'),
      ],
    ));
  }



}







class PlusIconScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create'),
      ),
      body: Center(child: Text('New screen after Plus Icon is clicked')),
    );
  }
}


class GroupCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Image Section
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: 
               Image.asset("assets/images/grp1.png")
              // Image.network(
              //   'https://your-image-url.com', // replace with your image URL
              //   width: 60,
              //   height: 60,
              //   fit: BoxFit.cover,
              // ),
            ),
            SizedBox(width: 12),

            // Group Name and Details Section
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Group Name and Badge
                  Row(
                    children: [
                      Text(
                        'Group Name',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(width: 8),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.purple.shade200,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          '1',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 8),

                  // Trip Icon and Type
                  Row(
                    children: [
                      // Left-aligned content (SVG and 'Trip' text)
                      Expanded(
                        child: Row(
                          children: [
                            SvgPicture.asset(
                              'assets/images/CameraPlus.svg',
                              width: 16, // specify width for the icon
                              height: 16, // specify height for the icon
                              color: Colors.blue,
                            ),
                            SizedBox(width: 4),
                            Text(
                              'Trip',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Right-aligned content ('No expenses added')
                      Text(
                        'No expenses added',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),

                ],
              ),
            ),

            // Expenses Section
            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.end,
            //   children: [
            //     Text(
            //       'No expenses added',
            //       style: TextStyle(
            //         color: Colors.grey,
            //         fontSize: 12,
            //       ),
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}


