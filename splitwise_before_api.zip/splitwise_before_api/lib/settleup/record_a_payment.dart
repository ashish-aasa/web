import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';


class RecordAPaymentController extends GetxController {
  var selectedFriend = 'Select'.obs;
  var selectedPaidBy = 'Friend 1'.obs;
  var selectedSplitOption = 'equally'.obs;
  var selectedDate = 'Date'.obs;
  var selectedImageName = 'Upload Payment Proof'.obs;
  var notes = ''.obs;

  var paidAmount = 20000.obs;
  var participants = [
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "User Name", "share": 0.obs}
  ].obs;

  // Function to set selected date
  void pickDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null) {
      selectedDate.value = DateFormat('dd MMM').format(pickedDate);
    }
  }

  // Function to pick an image from the gallery
  void pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      selectedImageName.value = image.name;
    }
  }

  // Function to open notes editor
  void openNotesEditor(BuildContext context) {
    TextEditingController notesController = TextEditingController(text: notes.value);
    Get.bottomSheet(
      Container(
        padding: EdgeInsets.all(20),
        color: Colors.white,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: notesController,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'Enter your notes',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                notes.value = notesController.text;
                Get.back();
              },
              child: Text('Save Notes'),
            )
          ],
        ),
      ),
    );
  }
}



class AddExpenseDetailsController2 extends GetxController {
  var selectedCurrency = ''.obs;
  RxBool isLoading = false.obs;
  Rx<XFile?> selectedScreenshot = Rx<XFile?>(null);

  void setSelectedCurrency(String currency) {
    selectedCurrency.value = currency;
    Get.back(); // Close the popup after selection
  }


  Future<void> pickScreenshot() async {
    isLoading.value = true;
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.gallery).then((value) {
      selectedScreenshot.value = value;
      print("skillllling pick get c" + selectedScreenshot.value.toString());
    });
    isLoading.value = false;
  }

  void removeScreenshot() {
    selectedScreenshot.value = null;
  }

  var selectedCurrencies = <String>[].obs; // List to store selected items

  void toggleCurrencySelection(String currency) {
    if (selectedCurrencies.contains(currency)) {
      selectedCurrencies.remove(currency);
    } else {
      selectedCurrencies.add(currency);
    }
  }
}

class RecordAPaymentScreen extends StatelessWidget {
  final RecordAPaymentController controller = Get.put(RecordAPaymentController());
  final AddExpenseDetailsController2 currencyController = Get.put(AddExpenseDetailsController2());

  final List<String> friends = ['Friend 1', 'Friend 2', 'Friend 3'];
  final List<String> splitOptions = ['equally', 'unequally', 'percentage'];
  late double width;
  late double height;

  final List<String> currencies = [
    // 'All Members of group name',
    'All Members ',
    'Friend 1',
    'Friend 2',
    'Friend 3',
    'Friend 4',
    'Friend 5',
    'Friend 6',

  ];

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Record a payment'),

          ],
        ),
      ),
      body: SingleChildScrollView(
        // color: Colors.grey.shade100,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Group Name


            SizedBox(height:height *.05,),
            // With you and Select Dropdown
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.blue.shade100,
                        radius: 28,
                        child: Icon(
                          Icons.person,
                          color: Colors.blue,
                          size: 32,
                        ),
                      ),
                      SizedBox(height:4,),
                      Text("Friend Name")
                    ],
                  ),
                  Column(
                    children: [
                      Image.asset("assets/images/Arrow25.png"),
                      Text("")
                    ],
                  ),
                  Column(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.blue.shade100,
                        radius: 28,
                        child: Icon(
                          Icons.person,
                          color: Colors.blue,
                          size: 32,
                        ),
                      ),
                      SizedBox(height:4,),
                      Text("Me")
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height:height *.05,),

            Center(
              child: Padding(
                padding: const EdgeInsets.only(left: 16),
                child: Text('Friend name paid you'),
              ),
            ),
            SizedBox(height: 10,),



            SizedBox(height: 10),

            // Amount section
            Container(
              color: Colors.white,
              height: 100,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Container(
                      width: 100,
                      child: OutlinedButton(
                        onPressed: () {
                          // Handle Payment ID


                        },
                        style: OutlinedButton.styleFrom(
                          // side: BorderSide(color: Colors.grey[700]!),
                          side: BorderSide(color:Color(0xFF233f78),),
                          padding: EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(13),
                          ),
                        ),
                        child: Text(
                          'Amount (₹)',
                          style: TextStyle(fontSize: 16, color: Color(0xFF233f78),),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: TextField(
                        style: TextStyle(
                          fontSize: 20,  // Set font size to 20
                        ),
                        textAlign: TextAlign.right,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: '0',
                          //  border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                ],
              ),
            ),
            SizedBox(height: 10),

            Divider(height: 2,
            ),
            SizedBox(height: 10),
            // Date, Upload Receipt, Notes
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // GestureDetector(
                //   onTap: () => controller.pickDate(context),
                //   child: Row(
                //     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //     children: [
                //       Image.asset("assets/images/CalendarDots.png"),
                //       SizedBox(width: 5,),
                //       Obx(() => Text(controller.selectedDate.value)),
                //     ],
                //   ),
                // ),
                // Text("|"),
                GestureDetector(
                  onTap: () => controller.pickImage(),
                  child: Row(
                    children: [
                      Image.asset("assets/images/bxs_image.png"),
                      SizedBox(width: 5,),
                      Obx(() => Text(controller.selectedImageName.value)),
                    ],
                  ),
                ),
                Text("|"),
                GestureDetector(
                  onTap: () => controller.openNotesEditor(context),
                  child: Row(
                    children: [
                      Image.asset("assets/images/ic_round-edit-note.png"),
                      SizedBox(width: 5,),
                      Text('Notes'),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Divider(height: 2,
            ),
            SizedBox(height: 20),

            // Paid by and Split options

            SizedBox(height: 30),





            //   Spacer(),


          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.grey.shade100,
        child:  Obx(() => Container(

          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 3.0,
              colors:   currencyController.selectedCurrencies.isEmpty ?

              [
                Color(0xFF5278C7).withOpacity(0.4), // #5278C7
                Color(0xFF233F78).withOpacity(0.4), // #233F78
              ]:
              [
                Color(0xFF5278C7), // #5278C7
                Color(0xFF233F78), // #233F78
              ],
            ),
            borderRadius: BorderRadius.circular(30), // Same as button radius
          ),
          child: ElevatedButton(
            onPressed: null,

            //  controller.canCreateGroup() ? () {} : null,
            style: ElevatedButton.styleFrom(

              minimumSize: Size(double.infinity, 50),
              backgroundColor: Colors.grey[400],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text('Save', style: TextStyle(fontSize: 18,color: Colors.white)),
          ),
        )),
      ),
    );
  }
}
