import 'package:flutter/material.dart';
import 'package:splitwise/settleup/record_payment_type.dart';

class WhoisgettingpaidScreen extends StatefulWidget {
  @override
  _WhoisgettingpaidScreenState createState() => _WhoisgettingpaidScreenState();
}

class _WhoisgettingpaidScreenState extends State<WhoisgettingpaidScreen> {
  String selectedFriend = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF6F7FB),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // Handle back action
            Navigator.pop(context);
          },
        ),
        title: Text(
          "Settle Up",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(height: 20,),
            // Top image
            Center(
              child: Image.asset(
                'assets/images/whoisgettingpaid.png', // Replace with your asset image
                height: 150,
              ),
            ),
            SizedBox(height: 20),
            Text(
              "Select who is getting paid",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 20,),
            SizedBox(height: 20),
            // Friend selection list
            _buildFriendOption("Friend 1"),
            SizedBox(height: 12),
            _buildFriendOption("Friend 2"),
            SizedBox(height: 12),
            _buildFriendOption("Friend 3"),
          ],
        ),
      ),
    );
  }

  // Helper method to build each friend option
  Widget _buildFriendOption(String friendName) {
    bool isSelected = selectedFriend == friendName;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedFriend = friendName;
        });

        Navigator.push(
            context, MaterialPageRoute(builder: (context) => RecordPaymentType())
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: isSelected
              ? Border.all(color: Colors.blueAccent, width: 2)
              : Border.all(color: Colors.transparent),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 5,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Colors.blueAccent,
              child: Icon(Icons.person, color: Colors.white),
            ),
            SizedBox(width: 16),
            Text(
              friendName,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
