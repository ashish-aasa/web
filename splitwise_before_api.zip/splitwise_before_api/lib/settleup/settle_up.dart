import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/settleup/record_a_payment.dart';
import 'package:splitwise/settleup/whoispaying.dart';

class SettleUpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Get.back(); // Navigate back using GetX
          },
        ),
        title: Text(
          'Settle Up',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: false, // Center the title
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: 4, // Number of items
                itemBuilder: (context, index) {
                  return GestureDetector(onTap: (){
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => RecordAPaymentScreen())
                    );
                  },
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 12.0),
                      child: Container(
                        //color: Colors.white,
                        child: Card(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          elevation: 4, // Slight shadow effect
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                // Profile icon
                                CircleAvatar(
                                  backgroundColor: Colors.blue.shade100,
                                  radius: 28,
                                  child: Icon(
                                    Icons.person,
                                    color: Colors.blue,
                                    size: 32,
                                  ),
                                ),
                                SizedBox(width: 16),
                                // Name and Borrowed status
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Friend Name',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),

                                    ],
                                  ),
                                ),
                                // Amount
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [

                                    Text(
                                      'Borrowed from you',
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: Colors.grey,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      '₹4000',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 16),
            // New Settlement button
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Color(0xFF5278C7)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50.0),
                    ),
                    padding:
                    EdgeInsets.symmetric(horizontal: 24, vertical: 12), // Padding
                  ),
                  onPressed: () {
                    // Handle New settlement button press
                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => WhoispayingScreen()));

                  },
                  child: Text(
                    "New settlement",
                    style: TextStyle(color: Color(0xFF5278C7)),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
