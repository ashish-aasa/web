import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';


class SettleupController extends GetxController {
  var selectedFriend = 'Select'.obs;
  var selectedPaidBy = 'Friend 1'.obs;
  var selectedSplitOption = 'equally'.obs;
  var selectedDate = 'Date'.obs;
  var selectedImageName = 'Upload Payment Proof'.obs;
 // var notes = 'this is nots it can be change s per requireo f user it will happen some time siol chaning iof not'.obs;

  var paidAmount = 20000.obs;
  var participants = [
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "User Name", "share": 0.obs}
  ].obs;
  var notes =
      "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, to"
          .obs;
  var photo = "receipt.jpg".obs;
  // Function to set selected date


  // Function to pick an image from the gallery


  // Function to open notes editor

}



class SettleupDetailsController2 extends GetxController {
  var selectedCurrency = ''.obs;
  RxBool isLoading = false.obs;
  Rx<XFile?> selectedScreenshot = Rx<XFile?>(null);

  void setSelectedCurrency(String currency) {
    selectedCurrency.value = currency;
    Get.back(); // Close the popup after selection
  }




}

class SettleUpDetails extends StatelessWidget {
  final SettleupController controller = Get.put(SettleupController());
  final SettleupDetailsController2 currencyController = Get.put(SettleupDetailsController2());

  final List<String> friends = ['Friend 1', 'Friend 2', 'Friend 3'];
  final List<String> splitOptions = ['equally', 'unequally', 'percentage'];
  late double width;
  late double height;

  final List<String> currencies = [
    // 'All Members of group name',
    'All Members ',
    'Friend 1',
    'Friend 2',
    'Friend 3',
    'Friend 4',
    'Friend 5',
    'Friend 6',

  ];

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Settle up Details'),

          ],
        ),
      ),
      body: SingleChildScrollView(
        // color: Colors.grey.shade100,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Group Name


            SizedBox(height:height *.05,),
            // With you and Select Dropdown
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.blue.shade100,
                        radius: 28,
                        child: Icon(
                          Icons.person,
                          color: Colors.blue,
                          size: 32,
                        ),
                      ),
                      SizedBox(height:4,),
                      Text("Friend 1")
                    ],
                  ),
                  Column(
                    children: [
                      Image.asset("assets/images/Arrow25.png"),
                      Text("")
                    ],
                  ),
                  Column(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.blue.shade100,
                        radius: 28,
                        child: Icon(
                          Icons.person,
                          color: Colors.blue,
                          size: 32,
                        ),
                      ),
                      SizedBox(height:4,),
                      Text("Friend 2")
                    ],
                  ),
                ],
              ),
            ),

          //  SizedBox(height:height *.05,),


            SizedBox(height: 10,),

            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10,),
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.transparent),

                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 5,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                       Image.asset("assets/images/MoneyWavy.png"),
                          SizedBox(width: 16),
                          Text(
                            "Cash Payment",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),

                      Text("₹2000",style: TextStyle(color: Colors.green,fontSize: 18),)
                    ],
                  ),
                ),
              ),
            ),
            // Notes Section
            SizedBox(height: 10,),
            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Text("Notes", style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 8),
            Obx(() => Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey),
                ),
                child: Text(controller.notes.value),
              ),
            )),
            SizedBox(height: 16),

            // Paid by and Split options



           //photo section
            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Text("Photo", style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 8),
            Obx(() => GestureDetector(onTap: (){
              _showImagePopup(context);
            },
              child: Padding(
                padding: const EdgeInsets.only(left: 10,right: 10),
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey),
                  ),
                  child: GestureDetector(onTap: (){
                    _showImagePopup(context);
                  },
                    child: Row(
                      children: [
                        // Icon(Icons.image, size: 40, color: Colors.grey),
                        Image.asset("assets/images/jpeg.png"),
                        SizedBox(width: 8),
                        Text(controller.photo.value),
                      ],
                    ),
                  ),
                ),
              ),
            )),



            //   Spacer(),


          ],
        ),
      ),
      /*bottomNavigationBar: BottomAppBar(
        color: Colors.grey.shade100,
        child:  Obx(() => Container(

          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 3.0,
              colors:   currencyController.isLoading.value  ?

              [
                Color(0xFF5278C7).withOpacity(0.4), // #5278C7
                Color(0xFF233F78).withOpacity(0.4), // #233F78
              ]:
              [
                Color(0xFF5278C7), // #5278C7
                Color(0xFF233F78), // #233F78
              ],
            ),
            borderRadius: BorderRadius.circular(30), // Same as button radius
          ),
          child: ElevatedButton(
            onPressed: null,

            //  controller.canCreateGroup() ? () {} : null,
            style: ElevatedButton.styleFrom(

              minimumSize: Size(double.infinity, 50),
              backgroundColor: Colors.grey[400],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text('Save', style: TextStyle(fontSize: 18,color: Colors.white)),
          ),
        )),
      ),*/
    );
  }


  void _showImagePopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          // Removing insetPadding to ensure the image covers the popup completely
          insetPadding: EdgeInsets.only(top: 100,bottom: 100,left: 20,right: 20),
          child: Stack(
            children: [
              // Background Image covering the whole popup
              Positioned.fill(
                child: Image.asset(
                  "assets/images/icecream.jpeg",
                  fit: BoxFit.cover, // Ensures the image covers the entire space
                ),
              ),

              // Close Button in the top-right corner
              Positioned(
                top: 20,
                right: 20,
                child: GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop(); // Close the popup
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white, // Background color of the close button
                      shape: BoxShape.circle,
                    ),
                    padding: EdgeInsets.all(8),
                    child: Icon(
                      Icons.close,
                      color: Colors.black, // Color of the cross icon
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

}
