import 'package:flutter/material.dart';
import 'package:get/get.dart';

class NotificationController extends GetxController {
  var groupFriendNotifications = {
    'groupAdded': true.obs,
    'friendAdded': true.obs,
  };

  var expenseNotifications = {
    'expenseAdded': false.obs,
    'expenseEdited': false.obs,
    'commentOnExpense': true.obs,
    'expenseDue': false.obs,
    'paymentReceived': true.obs,
  };

  var newsUpdatesNotifications = {
    'monthlySummary': false.obs,
    'majorUpdates': false.obs,
  };
}

class NotificationSettingsScreen extends StatelessWidget {
  final NotificationController controller = Get.put(NotificationController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FC), // Light background color matching the image
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Notifications',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: false,
      ),
      body: Stack(
        children: [
          // Scrollable content
          Padding(
            padding: const EdgeInsets.only(bottom: 80), // Reserve space for the bottom button
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(0.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  //  Groups & Friends Section
                    Container(
                      padding: EdgeInsets.only(left: 20,right: 20),
                      color: Colors.white,
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,  // Ensures the text aligns to the left
                            child: _buildSectionTitle('Groups & Friends'),
                          ),
                          Divider(thickness: 1, color: Colors.grey.shade300),
                        ],
                      ),
                    ),


                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When someone add me to the group",
                        controller.groupFriendNotifications['groupAdded']!,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When someone add me as a friend",
                        controller.groupFriendNotifications['friendAdded']!,
                      ),
                    ),

                    SizedBox(height: 20,),
                    // Expenses Section
                    //_buildSectionTitle('Expenses'),
                    Container(
                      padding: EdgeInsets.only(left: 20,right: 20),
                      color: Colors.white,
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,  // Ensures the text aligns to the left
                            child: _buildSectionTitle('Expenses'),
                          ),
                          Divider(thickness: 1, color: Colors.grey.shade300),
                        ],
                      ),
                    ),
                    // _buildCheckBoxTile(
                    //   "When an expense added",
                    //   controller.expenseNotifications['expenseAdded']!,
                    // ),


                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When an expense added",
                        controller.expenseNotifications['expenseAdded']!,
                      ),
                    ),
                    // _buildCheckBoxTile(
                    //   "When an expense is edited/deleted",
                    //   controller.expenseNotifications['expenseEdited']!,
                    // ),

                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When an expense is edited/deleted",
                        controller.expenseNotifications['expenseEdited']!,
                      ),
                    ),
                    // _buildCheckBoxTile(
                    //   "When someone comments on an expense",
                    //   controller.expenseNotifications['commentOnExpense']!,
                    // ),
                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When someone comments on an expense",
                        controller.expenseNotifications['commentOnExpense']!,
                      ),
                    ),

                    // _buildCheckBoxTile(
                    //   "When an expense is due",
                    //   controller.expenseNotifications['expenseDue']!,
                    // ),
                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When an expense is due",
                        controller.expenseNotifications['expenseDue']!,
                      ),
                    ),
                    // _buildCheckBoxTile(
                    //   "When someone pays me",
                    //   controller.expenseNotifications['paymentReceived']!,
                    // ),

                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "When someone pays me",
                        controller.expenseNotifications['paymentReceived']!,
                      ),
                    ),
                  SizedBox(height: 20,),

                    // News & Updates Section
                    Container(
                      padding: EdgeInsets.only(left: 20,right: 20),
                      color: Colors.white,
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,  // Ensures the text aligns to the left
                            child: _buildSectionTitle('News & Updates'),
                          ),
                          Divider(thickness: 1, color: Colors.grey.shade300),
                        ],
                      ),
                    ),
                    //_buildSectionTitle('News & Updates'),
                    // _buildCheckBoxTile(
                    //   "Monthly summery of my activity",
                    //   controller.newsUpdatesNotifications['monthlySummary']!,
                    // ),
                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "Monthly summery of my activity",
                        controller.newsUpdatesNotifications['monthlySummary']!,
                      ),
                    ),

                    // _buildCheckBoxTile(
                    //   "Major app related news & updates",
                    //   controller.newsUpdatesNotifications['majorUpdates']!,
                    // ),

                    Container(
                      padding: EdgeInsets.only(left: 20),
                      width: MediaQuery.of(context).size.width,
                      color: Colors.white,
                      child: _buildCheckBoxTile(
                        "Major app related news & updates",
                        controller.newsUpdatesNotifications['majorUpdates']!,
                      ),
                    ),
                    SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),

          // Fixed Save Changes Button at the Bottom
          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: ElevatedButton(
              onPressed: () {
                // Handle Save Changes action
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                backgroundColor: Color(0xFF8184E7),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Text(
                'Save Changes',
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Section Title Builder
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,  ), textAlign: TextAlign.left,
          ),
        //  Divider(thickness: 1, color: Colors.grey.shade300),
        ],
      ),
    );
  }

  // Checkbox Tile Builder
  Widget _buildCheckBoxTile(String label, RxBool value) {
    return Obx(
          () => CheckboxListTile(
        value: value.value,
        onChanged: (bool? newValue) {
          value.value = newValue!;
        },
        title: Text(
          label,
          style: TextStyle(fontSize: 14),
        ),
        activeColor: Color(0xFF8184E7), // Checkbox color matching the design
        controlAffinity: ListTileControlAffinity.trailing,
      ),
    );
  }
}

