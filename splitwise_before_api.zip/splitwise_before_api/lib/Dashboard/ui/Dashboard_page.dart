import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:splitwise/Account/account_screen.dart';
import 'package:splitwise/Activity/activity_screen.dart';
import 'package:splitwise/Expenses/ui/add_expense_details.dart';
import 'package:splitwise/Groups/ui/create_group.dart';
import 'package:splitwise/Groups/ui/group_page.dart';
import 'package:splitwise/Pro/pro_screen.dart';
import 'package:splitwise/charity/ui/add_charity.dart';
import 'package:splitwise/utils/colors.dart';

import '../../Friend/ui/add_friend.dart';
import '../../Home/ui/home_screen.dart';

class HomeController2 extends GetxController with SingleGetTickerProviderMixin {
  var currentIndex = 0.obs;
  late TabController tabController;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 2, vsync: this); // 2 tabs for Groups and Friends
  }

  @override
  void onClose() {
    tabController.dispose();
    super.onClose();
  }

  void changePage(int index) {
    currentIndex.value = index;
  }
}



// Controller using GetX for managing visibility of buttons
class FloatingButtonController2 extends GetxController {
  // Observable variable for button visibility
  var isButtonVisible = false.obs;

  // Function to toggle button visibility
  void toggleButtons() {
    isButtonVisible.value = !isButtonVisible.value;
  }
}

class DashboardScreen extends StatelessWidget {
  final HomeController2 controller = Get.put(HomeController2());
  // Create instance of controller
  final FloatingButtonController2 floatingButtonController2 = Get.put(FloatingButtonController2());
  final MainController controllermain = Get.put(MainController());
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: controllermain.pageController,
            onPageChanged: (index) {
              controllermain.currentIndex.value = index; // Update the index when page changes
            },
            children: [
              HomeScreen(), // Page for Home
              ActivityScreen(), // Page for Activity
              Container(), // Placeholder for Plus Icon
              ProScreen(), // Page for PRO
              AccountScreen(), // Page for Account
            ],
            physics: NeverScrollableScrollPhysics(), // Disable swipe between pages
          ),

          // Floating action buttons
          Obx(() {
            return floatingButtonController2.isButtonVisible.value
                ? Positioned(
              bottom: 100, // Adjust position above the main FAB
              left: 0,
              right: 0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FloatingActionButton.extended(
                    onPressed: () {
                      // Handle Add Charity action
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AddCharity()),
                      );
                    },
                    label: Text('Add Charity'),
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black, // uitext color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  SizedBox(height: 10),
                  FloatingActionButton.extended(
                    onPressed: () {
                      // Navigate to ExpenseScreen
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ExpenseScreen()),
                      );
                    },
                    label: Text('Add Expense'),
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black, // uitext color
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ],
              ),
            )
                : SizedBox.shrink(); // Empty space when buttons are hidden
          }),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          floatingButtonController2.toggleButtons();
        },
        child: Image.asset("assets/images/Group24.jpg"), // Your custom plus icon image
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
/*    return Scaffold(
      body: PageView(
        controller: controllermain.pageController,
        onPageChanged: (index) {
          controllermain.currentIndex.value = index; // Update the index when page changes
        },
        children: [

          HomeScreen(), // Page for Home
          ActivityScreen(), // Page for Activity
          Container(), // Placeholder for Plus Icon
          ProScreen(), // Page for PRO
          AccountScreen(), // Page for Account
        ],
        physics: NeverScrollableScrollPhysics(), // Disable swipe between pages
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),

      floatingActionButton: FloatingActionButton(
          onPressed: () {
            // Plus Icon action
            // Get.to(() => PlusIconScreen());
            floatingButtonController2.toggleButtons();
          },
          child:
          // Icon(Icons.add),
          //  SvgPicture.asset(
          //    'assets/images/Group124.svg',
          //    width: 80, // specify width
          //    height: 80, // specify height
          //  //  color: Color(0xFF233F78), // optional: colorize the SVG
          //  ),
          Image.asset("assets/images/Group24.jpg")

        //  backgroundColor: Colors.red, // Adjust color
        // elevation: 5,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      bottomSheet: Obx(() {
        return floatingButtonController2.isButtonVisible.value
            ? Padding(
          padding: const EdgeInsets.only(bottom: 20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              FloatingActionButton.extended(
                onPressed: () {
                  // Handle Add Charity action
                },
                label: Text('Add Charity'),
                backgroundColor: Colors.white,
                foregroundColor: Colors.black, // uitext color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              SizedBox(height: 10),
              FloatingActionButton.extended(
                onPressed: () {
                  // Navigate to ExpenseScreen
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ExpenseScreen()),
                  );
                },
                label: Text('Add Expense'),
                backgroundColor: Colors.white,
                foregroundColor: Colors.black, // uitext color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ],
          ),
        )
            : SizedBox.shrink(); // Empty space when buttons are hidden
      }),
    );*/
  }










  Widget _buildBottomNavigationBar() {
    return Obx(() => BottomNavigationBar(
      currentIndex: controllermain.currentIndex.value,
      onTap: (index) {
        if (index == 2) {
          // Handle Plus Icon Click
          Get.to(() => PlusIconScreen());
        } else {
          controllermain.changePage(index);
        }
      },
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
            icon:
            // Icon(Icons.home),
            SvgPicture.asset(
              'assets/images/home.svg',
              width: 20, // specify width
              height: 20, // specify height
              color: Color(0xFF233F78), // optional: colorize the SVG
            ),

            label: 'Home'),


        BottomNavigationBarItem(icon:
        //  Icon(Icons.list),
        SvgPicture.asset(
          'assets/images/Pulse.svg',
          width: 20, // specify width
          height: 20, // specify height
          color: Color(0xFF233F78), // optional: colorize the SVG
        ),

            label: 'Activity'),
        BottomNavigationBarItem(
            icon:

            // Icon(Icons.add, size: 30),
            SvgPicture.asset(
              'assets/images/Group124.svg',
              width: 20, // specify width
              height: 20, // specify height
              color: Color(0xFF233F78), // optional: colorize the SVG
            ),

            label: ''), // Plus icon


        BottomNavigationBarItem(icon:

        // Icon(Icons.diamond),
        SvgPicture.asset(
          'assets/images/SketchLogo.svg',
          width: 20, // specify width
          height: 20, // specify height
          color: Color(0xFF233F78), // optional: colorize the SVG
        ),

            label: 'PRO'),
        BottomNavigationBarItem(icon:

        // Icon(Icons.person),
        SvgPicture.asset(
          'assets/images/account.svg',
          width: 20, // specify width
          height: 20, // specify height
          color: Color(0xFF233F78), // optional: colorize the SVG
        ),
            label: 'Account'),
      ],
    ));
  }



}









class MainController extends GetxController {
  var currentIndex = 3.obs;

  PageController pageController = PageController();

  void changePage(int index) {
    print("indexchanging : " + index.toString());
    currentIndex.value = index;
    pageController.jumpToPage(index);

  }
}