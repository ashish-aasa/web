import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/Account/block_list.dart';
import 'package:splitwise/utils/colors.dart';



class LanguageEditController extends GetxController {
  var selectedCurrency = ''.obs;
  RxBool isLoading = false.obs;


  void setSelectedCurrency(String currency) {
    selectedCurrency.value = currency;
    Get.back(); // Close the popup after selection
  }





}

class EditAccountSettings extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final LanguageEditController languageEditController = Get.put(LanguageEditController());


  final List<String> languages = [
    'English',
    'Hindi',
    'Spanish',
    'French',
    'Portuguese',

  ];

  void _showLanguageDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Language'),
          content: Container(
            width: double.infinity, // Makes the dialog take full width
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: languages.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: double.infinity, // Ensures Row takes full width
                  child: GestureDetector(
                    onTap: () {
                      languageEditController.setSelectedCurrency(languages[index]);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            languages[index],
                            style: TextStyle(fontSize: 13),
                            overflow: TextOverflow.ellipsis, // Handle long text gracefully
                          ),
                        ),
                        Obx(() {
                          return Radio<String>(
                            value: languages[index],
                            groupValue: languageEditController.selectedCurrency.value,
                            onChanged: (value) {
                              languageEditController.setSelectedCurrency(value!);
                            },
                          );
                        }),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }


  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [

                // Center(
                //   child: Text(
                //     'Logout',
                //     style: TextStyle(
                //       fontSize: 20.0,
                //       fontWeight: FontWeight.bold,
                //     ),
                //   ),
                // ),
                SizedBox(height: 16),
                // Content
                Text(
                  'Are you sure, you want to delete \n your account?',
                  style:
                  // GoogleFonts.poppins(
                  //     textStyle: TextStyle(
                  //         fontSize: 16,
                  //         fontWeight: FontWeight.w300,
                  //         color: textColor1)),
                  TextStyle(fontSize: 16.0),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 24),
                // Buttons
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child:
                        Container(

                          child: OutlinedButton(
                            onPressed: () {
                              // Perform delete action here
                              Navigator.of(context).pop();
                            },
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Colors.grey[700]!),
                              padding: EdgeInsets.symmetric(vertical: 13),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: Text(
                              'Cancel',
                              style: TextStyle(fontSize: 16, color: Colors.black),
                            ),
                          ),
                        ),

                        // ElevatedButton(
                        //   onPressed: () {
                        //     Navigator.of(context).pop();
                        //   },
                        //   style: ElevatedButton.styleFrom(
                        //     backgroundColor: Colors.grey[700],
                        //     padding: EdgeInsets.symmetric(vertical: 13),
                        //     shape: RoundedRectangleBorder(
                        //       borderRadius: BorderRadius.circular(30),
                        //     ),
                        //   ),
                        //   child: Text(
                        //     'Cancel',
                        //     style: TextStyle(fontSize: 16, color: Colors.white),
                        //   ),
                        // ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              center: Alignment.center,
                              radius: 3.0,
                              colors: [
                                Color(0xFF5278C7), // #5278C7
                                Color(0xFF233F78), // #233F78
                              ],
                            ),
                            borderRadius: BorderRadius.circular(30), // Same as button radius
                          ),
                          child: OutlinedButton(
                            onPressed: () {
                              // Perform delete action here
                            },
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Colors.grey[700]!),
                              padding: EdgeInsets.symmetric(vertical: 13),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: Text(
                              'Delete',
                              style: TextStyle(fontSize: 16, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Account Settings'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Personal Details Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Personal Details',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                Image.asset("assets/images/PencilSimple.png",width: 20,height: 20,)
              ],
            ),
            SizedBox(height: 15),

            // Full Name TextField
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Full Name*',
                labelStyle: TextStyle(color: Colors.black54),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),

            // Email ID TextField (Optional)
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email Id (Optional)',
                labelStyle: TextStyle(color: Colors.black54),
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),

            // Advanced Options Section
            // Advanced Options Section with Currency and Language in Row
            Text(
              "Advanced Options",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),

            // Currency and Language in a row
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Container(
                //   child: _buildCustomButton('Currency', 'Indian Rupee'),
                // ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Currency",
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black54),
                    ),
                    SizedBox(height: 5),
                    Container(
                      //  width: double.infinity,
                      width: MediaQuery.of(context).size.width*.6,
                      padding: EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: Color(0xFFBAC1F7), // Background color matching the image
                      ),
                      child: Text(
                        "Indian",
                        style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                // Container(
                //   child: _buildCustomButton('Language', 'English'),
                // ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Language",
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black54),
                    ),
                    SizedBox(height: 5),
                    GestureDetector(
                      onTap: () => _showLanguageDialog(context),
                      child: Container(
                        width: MediaQuery.of(context).size.width*.6,
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          //   color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(8),
                          //   border: Border.all(color: Colors.grey),
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 3.0,
                            colors: [
                              Color(0xFF8082ED), // #5278C7
                              Color(0xFF9B9CF8), // #233F78
                            ],
                          ),


                        ),
                        child: Obx(() {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                languageEditController.selectedCurrency.value.isEmpty
                                    ? 'Select'
                                    : languageEditController.selectedCurrency.value,
                                style: TextStyle(
                                  color: languageEditController.selectedCurrency.value.isEmpty
                                      ? Colors.white
                                      : Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                              Icon(Icons.arrow_drop_down),
                            ],
                          );
                        }),
                      ),
                    ),
                    // Container(
                    //   width: MediaQuery.of(context).size.width*.6,
                    //   padding: EdgeInsets.all(15),
                    //   decoration: BoxDecoration(
                    //     borderRadius: BorderRadius.circular(5),
                    //     color: Color(0xFFBAC1F7), // Background color matching the image
                    //   ),
                    //   child: Text(
                    //     "English",
                    //     style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold),
                    //   ),
                    // ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 20),

            // Manage Users Section
            Text(
              "Manage Users",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            GestureDetector(onTap: (){
              Navigator.push(
                  context,

                  MaterialPageRoute(builder: (context) => BlocklistScreen()));
            },
                child: _buildManageButton(Icons.block, 'Manage your blocklist', Colors.white)),
            SizedBox(height: 10),
            GestureDetector(onTap: (){

              _showDeleteDialog(context);
            },
                child: _buildManageButton(Icons.delete, 'Delete your account', Colors.white)),
            SizedBox(height: 30),

            // Save Changes Button
            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 3.0,
                    colors:

                    [
                      Color(0xFF5278C7), // #5278C7
                      Color(0xFF233F78), // #23
                    ]

                ),
                borderRadius: BorderRadius.circular(30), // Same as button radius
              ),
              child: Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Handle Save Changes action
                  },
                  // style: ElevatedButton.styleFrom(
                  //   padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  //   backgroundColor: Color(0xFF8184E7),
                  //   shape: RoundedRectangleBorder(
                  //     borderRadius: BorderRadius.circular(30),
                  //   ),
                  // ),
                  style: ElevatedButton.styleFrom(

                    minimumSize: Size(double.infinity, 50),
                    backgroundColor:twoui,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    'Save Changes',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


  // Button for Manage Blocklist and Delete Account
  Widget _buildManageButton(IconData icon, String label, Color color) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        // color: Color(0xFFBAC1F7), // Background color matching the image
        gradient: LinearGradient(
       //   center: Alignment.center,
       //   radius: 3.0,
          colors: [
            Color(0xFF8082ED), // #5278C7
            Color(0xFF9B9CF8), // #233F78
          ],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 18),
            SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(fontSize: 14, color: color, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
