import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:splitwise/Account/account_settings.dart';
import 'package:splitwise/Account/payment_id.dart';
import 'package:splitwise/notifications.dart';
import 'package:splitwise/passcode/passcode_screen.dart';
import 'package:splitwise/scancode/scan_code.dart';

import '../utils/colors.dart';

// Controller for Account Screen (optional if using GetX)
class AccountController extends GetxController {}

class AccountScreen extends StatelessWidget {
  final AccountController controller = Get.put(AccountController());


  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
            padding: EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [

                Center(
                  child: Text(
                    'Logout',
                    style: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(height: 16),
                // Content
                Text(
                  'Are you sure, you want to logout?',
                  style:
                  // GoogleFonts.poppins(
                  //     textStyle: TextStyle(
                  //         fontSize: 16,
                  //         fontWeight: FontWeight.w300,
                  //         color: textColor1)),
                  TextStyle(fontSize: 16.0),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 24),
                // Buttons
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child:
                        Container(

                          child: OutlinedButton(
                            onPressed: () {
                              // Perform delete action here
                              Navigator.of(context).pop();
                            },
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Colors.grey[700]!),
                              padding: EdgeInsets.symmetric(vertical: 13),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: Text(
                              'Cancel',
                              style: TextStyle(fontSize: 16, color: Colors.black),
                            ),
                          ),
                        ),

                        // ElevatedButton(
                        //   onPressed: () {
                        //     Navigator.of(context).pop();
                        //   },
                        //   style: ElevatedButton.styleFrom(
                        //     backgroundColor: Colors.grey[700],
                        //     padding: EdgeInsets.symmetric(vertical: 13),
                        //     shape: RoundedRectangleBorder(
                        //       borderRadius: BorderRadius.circular(30),
                        //     ),
                        //   ),
                        //   child: Text(
                        //     'Cancel',
                        //     style: TextStyle(fontSize: 16, color: Colors.white),
                        //   ),
                        // ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              center: Alignment.center,
                              radius: 3.0,
                              colors: [
                                Color(0xFF5278C7), // #5278C7
                                Color(0xFF233F78), // #233F78
                              ],
                            ),
                            borderRadius: BorderRadius.circular(30), // Same as button radius
                          ),
                          child: OutlinedButton(
                            onPressed: () {
                              // Perform delete action here
                            },
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Colors.grey[700]!),
                              padding: EdgeInsets.symmetric(vertical: 13),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: Text(
                              'Yes,Logout',
                              style: TextStyle(fontSize: 16, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FC), // Light background color
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text(
          'Account',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // User Card
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Stack(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      // gradient: LinearGradient(
                      //   colors: [Color(0xFF85D8CE), Color(0xFF1FBAB1)],
                      //   begin: Alignment.topLeft,
                      //   end: Alignment.bottomRight,
                      // ),
                      gradient: LinearGradient(
                        colors: [cardColor, cardColor2,cardColor2],
                        stops: [0.001, 0.5, 0.8], // Stops for each color
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          spreadRadius: 3,
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.white,
                          radius: 30,
                          child:
                          // Icon(
                          //   Icons.account_circle,
                          //   size: 40,
                          //   color: Colors.black,
                          // ),
                          SvgPicture.asset(
                            'assets/images/CameraPlus.svg',
                            width: 36, // specify width for the icon
                            height: 36, // specify height for the icon
                            color: Colors.blue,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'User Name',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          '98XXXXXXXX',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: GestureDetector(
                      onTap: () {
                        // Settings action
                        Navigator.push(
                            context,

                            MaterialPageRoute(builder: (context) => AccountSettingsScreen()));

                      },
                      child: Icon(
                        Icons.settings,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Menu Items
            MenuItem(
             // icon: Icons.qr_code_scanner,
              image: AssetImage('assets/images/Scan.png'), // Image from assets
              label: 'Scan Code',
              onTap: () {
                // Handle Scan Code action
                Navigator.push(    context, MaterialPageRoute(builder: (context) => ScanCodeScreen()));



              },
            ),
            SectionHeader('Preference'),
            MenuItem(
              image: AssetImage('assets/images/notify.png'), //
              label: 'Notification',
              onTap: () {
                // Handle Notification action
                Navigator.push(    context, MaterialPageRoute(builder: (context) => NotificationSettingsScreen()));

              },
            ),
            MenuItem(
              image: AssetImage('assets/images/LockLaminated.png'), //

              label: 'Passcode',
              onTap: () {
                // Handle Passcode action
                Navigator.push(    context, MaterialPageRoute(builder: (context) => PasscodeScreen()));


              },
            ),
            MenuItem(
              image: AssetImage('assets/images/ContactlessPayment.png'), //
              label: 'Payment Id',
              onTap: () {
                // Handle Payment Id action
                Navigator.push(    context, MaterialPageRoute(builder: (context) => PaymentIdScreen()));

              },
            ),
            SectionHeader('Feedback'),
            MenuItem(
              image: AssetImage('assets/images/Star.png'), //
              label: 'Rate App',
              onTap: () {
                // Handle Rate App action
              },
            ),
            MenuItem(
              image: AssetImage('assets/images/At.png'), //
              label: 'Contact Us',
              onTap: () {
                // Handle Contact Us action
              },
            ),
            MenuItem(
              image: AssetImage('assets/images/Power.png'), //
              label: 'Log Out',
              onTap: () {
                // Handle Log Out actionc
                _showLogoutDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

// Section Header Widget
class SectionHeader extends StatelessWidget {
  final String title;
  const SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.grey[600],
          ),
        ),
      ),
    );
  }
}

// Menu Item Widget

// class MenuItem extends StatelessWidget {
//   final ImageProvider image; // Use ImageProvider for assets or network images
//   final String label;
//   final VoidCallback onTap;
//
//   const MenuItem({
//     required this.image,
//     required this.label,
//     required this.onTap,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap, // Handle tap
//       child: Padding(
//         padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
//         child: Row(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             // Leading Image (CircleAvatar)
//             CircleAvatar(
//
//               backgroundImage: image,
//               backgroundColor: Colors.transparent, // No background color
//             ),
//             const SizedBox(width: 16), // Add space between the image and text
//             // Title Text
//             Expanded(
//               child: Text(
//                 label,
//                 style: TextStyle(fontSize: 16),
//               ),
//             ),
//             // Trailing Icon
//             Icon(Icons.arrow_forward_ios, size: 16),
//           ],
//         ),
//       ),
//     );
//   }
// }

class MenuItem extends StatelessWidget {
  final ImageProvider image; // Use ImageProvider for assets or network images
  final String label;
  final VoidCallback onTap;

  const MenuItem({
    required this.image,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.symmetric(horizontal: 10.0), // Adjust this value
      leading: CircleAvatar(
        radius: 15,
        backgroundImage: image,
        backgroundColor: Colors.transparent, // Optional: To avoid a background color
      ),
      title: Text(
        label,
        style: TextStyle(fontSize: 16),
      ),
      trailing: Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );

  }
}

// class MenuItem extends StatelessWidget {
//   final IconData icon;
//   final String label;
//   final VoidCallback onTap;
//
//   const MenuItem({required this.icon, required this.label, required this.onTap});
//
//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       leading: Icon(
//         icon,
//         color: Color(0xFF1FBAB1), // Customize color of icons
//       ),
//       title: Text(
//         label,
//         style: TextStyle(fontSize: 16),
//       ),
//       trailing: Icon(Icons.arrow_forward_ios, size: 16),
//       onTap: onTap,
//     );
//   }
// }
