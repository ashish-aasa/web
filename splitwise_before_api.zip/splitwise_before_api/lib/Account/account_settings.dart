import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/Account/block_list.dart';
import 'package:splitwise/Account/edit_account_settings.dart';

import '../utils/colors.dart';

class AccountSettingsController extends GetxController {
  var isEditing = false.obs;
}


void _showDeleteDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              // Center(
              //   child: Text(
              //     'Logout',
              //     style: TextStyle(
              //       fontSize: 20.0,
              //       fontWeight: FontWeight.bold,
              //     ),
              //   ),
              // ),
              SizedBox(height: 16),
              // Content
              Text(
                'Are you sure, you want to delete \n your account?',
                style:
                // GoogleFonts.poppins(
                //     textStyle: TextStyle(
                //         fontSize: 16,
                //         fontWeight: FontWeight.w300,
                //         color: textColor1)),
                TextStyle(fontSize: 16.0),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              // Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child:
                      Container(

                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Cancel',
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ),
                      ),

                      // ElevatedButton(
                      //   onPressed: () {
                      //     Navigator.of(context).pop();
                      //   },
                      //   style: ElevatedButton.styleFrom(
                      //     backgroundColor: Colors.grey[700],
                      //     padding: EdgeInsets.symmetric(vertical: 13),
                      //     shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(30),
                      //     ),
                      //   ),
                      //   child: Text(
                      //     'Cancel',
                      //     style: TextStyle(fontSize: 16, color: Colors.white),
                      //   ),
                      // ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 3.0,
                            colors: [
                              Color(0xFF5278C7), // #5278C7
                              Color(0xFF233F78), // #233F78
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30), // Same as button radius
                        ),
                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Delete',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

class AccountSettingsScreen extends StatelessWidget {
  final AccountSettingsController controller = Get.put(AccountSettingsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FC), // Light background color matching the image
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Account Settings',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Personal Details Section with Edit Icon in the Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Personal Details",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),

                  GestureDetector(onTap: (){
                    Navigator.push(
                        context,

                        MaterialPageRoute(builder: (context) => EditAccountSettings()));

                  },

                      child: Image.asset("assets/images/PencilSimple.png",width: 20,height: 20,))
                  // IconButton(
                  //   icon: Icon(Icons.edit, color: Colors.black),
                  //   onPressed: () {
                  //     controller.isEditing.value = !controller.isEditing.value;
                  //     Navigator.push(
                  //         context,
                  //
                  //         MaterialPageRoute(builder: (context) => EditAccountSettings()));
                  //
                  //   },
                  // ),
                ],
              ),
              SizedBox(height: 2),
              _buildTextField("User Name", "User Name"),
              SizedBox(height: 10),
              _buildTextField("Email", "user@gmail.com"),
              SizedBox(height: 10),
              _buildTextField("Phone Number", "9876XXXXXX"),
              SizedBox(height: 20),

              // Advanced Options Section with Currency and Language in Row
              Text(
                "Advanced Options",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),

              // Currency and Language in a row
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Container(
                  //   child: _buildCustomButton('Currency', 'Indian Rupee'),
                  // ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Currency",
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black54),
                      ),
                      SizedBox(height: 5),
                      Container(
                        //  width: double.infinity,
                        width: MediaQuery.of(context).size.width*.6,
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Color(0xFFBAC1F7), // Background color matching the image
                        ),
                        child: Text(
                          "Indian",
                          style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  // Container(
                  //   child: _buildCustomButton('Language', 'English'),
                  // ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Language",
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black54),
                      ),
                      SizedBox(height: 5),
                      Container(
                          width: MediaQuery.of(context).size.width*.6,
                        padding: EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Color(0xFFBAC1F7), // Background color matching the image
                        ),
                        child: Text(
                          "English",
                          style: TextStyle(fontSize: 14, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20),

              // Manage Users Section
              Text(
                "Manage Users",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              GestureDetector(onTap: (){
                Navigator.push(
                    context,

                    MaterialPageRoute(builder: (context) => BlocklistScreen()));
              },
                  child: _buildManageButton(Icons.block, 'Manage your blocklist', Colors.white)),
              SizedBox(height: 10),
              GestureDetector(onTap: (){

                _showDeleteDialog(context);
              },
                  child: _buildManageButton(Icons.delete, 'Delete your account', Colors.white)),
              SizedBox(height: 30),

              // Save Changes Button
              Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 3.0,
                    colors:

                    [
                      Color(0xFF5278C7), // #5278C7
                      Color(0xFF233F78), // #23
                    ]

                  ),
                  borderRadius: BorderRadius.circular(30), // Same as button radius
                ),
                child: Center(
                  child: ElevatedButton(
                    onPressed: () {
                      // Handle Save Changes action
                    },
                    // style: ElevatedButton.styleFrom(
                    //   padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    //   backgroundColor: Color(0xFF8184E7),
                    //   shape: RoundedRectangleBorder(
                    //     borderRadius: BorderRadius.circular(30),
                    //   ),
                    // ),
                    style: ElevatedButton.styleFrom(

                      minimumSize: Size(double.infinity, 50),
                      backgroundColor:twoui,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Text(
                      'Save Changes',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // TextField Builder for Non-Editable Fields
  Widget _buildTextField(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Text(
        //   label,
        //   style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black54),
        // ),
        SizedBox(height: 5),
        Container(
          width: double.infinity, // Adjusted the width to be dynamic and match the design
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          //  color: Color(0xFFEFEFF6), // Background color to match the design
            color: Colors.white, // Background color to match the design
          ),
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          child: Text(
            value,
            style: TextStyle(fontSize: 14, color: Colors.black),
          ),
        ),
      ],
    );
  }

  // Custom Button Builder for Currency and Language


  // Button for Manage Blocklist and Delete Account
  Widget _buildManageButton(IconData icon, String label, Color color) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        // color: Color(0xFFBAC1F7), // Background color matching the image
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 3.0,
          colors: [
            Color(0xFF8082ED), // #5278C7
            Color(0xFF9B9CF8), // #233F78
          ],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 18),
            SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(fontSize: 14, color: color, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
