import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BlocklistController extends GetxController {
  // Simulate a list of blocked users
  var blockedUsers = [
    {'name': 'Friend Name', 'phone': '98XXXXXXXX'},
    {'name': 'Friend Name', 'phone': '98XXXXXXXX'},
  ].obs;

  void unblockUser(int index) {
    blockedUsers.removeAt(index); // Remove the user from the list
    Get.snackbar('Unblocked', 'User has been unblocked.');
  }
}


void _showBlockDialog(BuildContext context,VoidCallback unblock) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              // Center(
              //   child: Text(
              //     'Logout',
              //     style: TextStyle(
              //       fontSize: 20.0,
              //       fontWeight: FontWeight.bold,
              //     ),
              //   ),
              // ),
              SizedBox(height: 16),
              // Content
              Text(
                'Are you sure, want to unblock\n "Friend Name"?',
                style:
                // GoogleFonts.poppins(
                //     textStyle: TextStyle(
                //         fontSize: 16,
                //         fontWeight: FontWeight.w300,
                //         color: textColor1)),
                TextStyle(fontSize: 16.0),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              // Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child:
                      Container(

                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'No',
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ),
                      ),

                      // ElevatedButton(
                      //   onPressed: () {
                      //     Navigator.of(context).pop();
                      //   },
                      //   style: ElevatedButton.styleFrom(
                      //     backgroundColor: Colors.grey[700],
                      //     padding: EdgeInsets.symmetric(vertical: 13),
                      //     shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(30),
                      //     ),
                      //   ),
                      //   child: Text(
                      //     'Cancel',
                      //     style: TextStyle(fontSize: 16, color: Colors.white),
                      //   ),
                      // ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 3.0,
                            colors: [
                              Color(0xFF5278C7), // #5278C7
                              Color(0xFF233F78), // #233F78
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30), // Same as button radius
                        ),
                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                            unblock;
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Yes,Unblock',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}


class BlocklistScreen extends StatelessWidget {
  final BlocklistController controller = Get.put(BlocklistController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF2E7FE), // Light background color
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black54),
          onPressed: () => Get.back(),
        ),
        title: Text('Blocklist', style: TextStyle(color: Colors.black)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Obx(() => ListView.builder(
          itemCount: controller.blockedUsers.length,
          itemBuilder: (context, index) {
            final user = controller.blockedUsers[index];
            return BlocklistItem(
              name: user['name']!,
              phone: user['phone']!,
              onUnblock: () => controller.unblockUser(index),
            );
          },
        )),
      ),
    );
  }
}

class BlocklistItem extends StatelessWidget {
  final String name;
  final String phone;
  final VoidCallback onUnblock;

  BlocklistItem({
    required this.name,
    required this.phone,
    required this.onUnblock,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          // Circle Avatar for user image or icon
          CircleAvatar(
            radius: 24,
            backgroundColor: Colors.blueAccent,
            child: Icon(Icons.person, color: Colors.white, size: 30),
          ),
          SizedBox(width: 16),

          // User details (name and phone)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
                Text(
                  phone,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          ),

          // Unblock button
          OutlinedButton(
           // onPressed: onUnblock,
            onPressed: (){

              _showBlockDialog(context,onUnblock);

            },
            style: OutlinedButton.styleFrom(
              side: BorderSide(color: Colors.blueAccent),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
            ),
            child: Text(
              'Unblock',
              style: TextStyle(color: Colors.blueAccent),
            ),
          ),
        ],
      ),
    );
  }
}
