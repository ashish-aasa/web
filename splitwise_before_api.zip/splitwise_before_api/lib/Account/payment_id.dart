


import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:splitwise/utils/colors.dart';


class PaymentidController extends GetxController {
  var selectedCurrency = ''.obs;
  RxBool isLoading = false.obs;
  Rx<XFile?> selectedScreenshot = Rx<XFile?>(null);

  void setSelectedCurrency(String currency) {
    selectedCurrency.value = currency;
    Get.back(); // Close the popup after selection
  }


  Future<void> pickScreenshot() async {
    isLoading.value = true;
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.gallery).then((value) {
      selectedScreenshot.value = value;
      print("skillllling pick get c" + selectedScreenshot.value.toString());
    });
    isLoading.value = false;
  }

  void removeScreenshot() {
    selectedScreenshot.value = null;
  }
}


class SwitchController extends GetxController {
  // Boolean observable to track the switch state
  var isSwitched = false.obs;

  void toggleSwitch(bool value) {
    isSwitched.value = value;
  }
}
class PaymentIdScreen extends StatelessWidget {
  final PaymentidController currencyController = Get.put(PaymentidController());
  final SwitchController switchController = Get.put(SwitchController());
  String? _uploadedFileName;

  final List<String> currencies = [
    'AED - United Arab Emirates Dirham',
    'AFN - Afghani Afghani',
    'ALL - Albanian Lek',
    'AMD - Armenian Dram',
    'ANG - Netherland Antillean Guilder',
    'AOA - Angolan Kwanza',
    'ARS - Argentina Peso',
    'AUD - Australian Dollar',
    'AWG - Aruban Florin'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Get.back(); // This will handle back navigation
          },
        ),
        title: Text('Payment Id',style: TextStyle(fontSize: 20),),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),









      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView( // Make the content scrollable
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              SizedBox(height: 20), // Added space for better layout
              Text(
                "UPI Id",
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 8),
              TextFormField(
                initialValue: 'upi@okaxis',

                decoration: InputDecoration(
                  filled: true,  // Enables filling the background
                  fillColor: Colors.white,
                  hintText: 'Enter your UPI Id*',  // Hint text
                  hintStyle: TextStyle(
                    color: Colors.grey,  // Hint text color
                    fontSize: 16,  // Font size
                    fontWeight: FontWeight.w400,  // Optional: Font weight
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20), // Set the border radius here
                    borderSide: BorderSide(color: Colors.white ), // Optional: customize border color
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize enabled border color
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize focused border color
                  ),
                ),
              ),

              SizedBox(height: 24),
              Text(
                "Upload QR code",
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 8),
              /*    GestureDetector(onTap: (){
                currencyController.pickScreenshot();
              },
                child: CustomPaint(
                  painter: DashedBorderPainter(
                    borderRadius: 10.0, // Curve radius
                    dashWidth: 5.0,     // Width of each dash
                    dashSpace: 5.0,     // Space between dashes
                    color: Colors.grey, // Color of the dashes
                  ),
                  child: Container(
                    width: double.infinity,
                    height: 54,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.upload_file),
                        SizedBox(width: 8),
                        Text("Upload"),
                      ],
                    ),
                  ),
                ),
              ),*/

              // updated obx

              Obx(() {
                return currencyController.isLoading.value
                    ? Center(child: CircularProgressIndicator())
                    : currencyController.selectedScreenshot.value == null
                    ? GestureDetector(
                  onTap: () {
                    currencyController.pickScreenshot();
                  },
                  child:

                  CustomPaint(
                    painter: DashedBorderPainter(
                      borderRadius: 10.0, // Curve radius
                      dashWidth: 5.0,     // Width of each dash
                      dashSpace: 5.0,     // Space between dashes
                      color: Colors.grey, // Color of the dashes
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 54,
                      decoration: BoxDecoration(
                        color: Colors.white, // Fill with white color
                        borderRadius: BorderRadius.circular(10), // Match the dashed border radius
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset("assets/images/uploadv.png"),
                          SizedBox(width: 8),
                          Text("Upload"),
                        ],
                      ),
                    ),
                  ),
                  // not filled with white bg
                  /*  CustomPaint(
                  painter: DashedBorderPainter(
                    borderRadius: 10.0, // Curve radius
                    dashWidth: 5.0,     // Width of each dash
                    dashSpace: 5.0,     // Space between dashes
                    color: Colors.grey, // Color of the dashes
                  ),
                  child: Container(
                    width: double.infinity,
                    height: 54,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       // Icon(Icons.upload_file),
                        Image.asset("assets/images/uploadv.png"),
                        SizedBox(width: 8),
                        Text("Upload"),
                      ],
                    ),
                  ),
                ),*/
                )
                    : Container(
                  padding: EdgeInsets.only(left: 20,right: 15,top: 4,bottom: 4), // Padding inside the container
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20), // Rounded corners with a radius of 20
                    border: Border.all(color: Colors.grey),  // Grey border color
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Show image preview
                      Image(
                        image: FileImage(File(currencyController
                            .selectedScreenshot.value!.path)),
                        height: 40,
                        width: 40,
                      ),
                      SizedBox(width: 8),

                      // Show file name
                      Expanded(
                        child: Text(
                          currencyController.selectedScreenshot.value!.name,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),

                      // Show remove icon (cross)
                      IconButton(
                        icon: Icon(Icons.cancel),
                        onPressed: () {
                          currencyController.removeScreenshot();
                        },
                      ),
                    ],
                  ),
                );
              }),



              SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Show payment id in friend detail',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(width: 10),
                  Obx(() => Switch(
                    value: switchController.isSwitched.value,
                    onChanged: switchController.toggleSwitch,
                  //  activeColor: uitext, // Blue when switched on
                    activeTrackColor: uitext,
                    activeColor:Colors.white ,
                    inactiveThumbColor: Colors.grey, // Grey when off
                    inactiveTrackColor: Colors.grey.shade300, // Light grey track when off
                  )),
                ],
              ),
              SizedBox(height: 70), // Added space for better layout


              SizedBox(height: 20),
            ],
          ),
        ),
      ),

      // body: Padding(
      //   padding: const EdgeInsets.all(16.0),
      //   child: Column(
      //     crossAxisAlignment: CrossAxisAlignment.start,
      //     children: [
      //       SizedBox(height: 20),
      //       Text(
      //         'Select default currency*',
      //         style: TextStyle(fontSize: 16, color: Colors.black),
      //       ),
      //       SizedBox(height: 10),
      //       GestureDetector(
      //         onTap: () => _showCurrencyDialog(context),
      //         child: Container(
      //           padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      //           decoration: BoxDecoration(
      //             borderRadius: BorderRadius.circular(8),
      //             border: Border.all(color: Colors.grey),
      //           ),
      //           child: Obx(() {
      //             return Row(
      //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //               children: [
      //                 Text(
      //                   currencyController.selectedCurrency.value.isEmpty
      //                       ? 'Select'
      //                       : currencyController.selectedCurrency.value,
      //                   style: TextStyle(
      //                     color: currencyController.selectedCurrency.value.isEmpty
      //                         ? Colors.grey
      //                         : Colors.black,
      //                     fontSize: 16,
      //                   ),
      //                 ),
      //                 Icon(Icons.arrow_drop_down),
      //               ],
      //             );
      //           }),
      //         ),
      //       ),
      //       SizedBox(height: 10),
      //       Text(
      //         'Once you select a currency, all your expenses & share will show in that currency, you cannot change it after.',
      //         style: TextStyle(fontSize: 14, color: Colors.grey),
      //       ),
      //
      //
      //       Text(
      //         "UPI Id",
      //         style: TextStyle(fontSize: 16),
      //       ),
      //       SizedBox(height: 8),
      //       TextFormField(
      //         initialValue: 'upi@okaxis',
      //         decoration: InputDecoration(
      //           border: OutlineInputBorder(),
      //         ),
      //       ),
      //       SizedBox(height: 24),
      //       Text(
      //         "Upload QR code",
      //         style: TextStyle(fontSize: 16),
      //       ),
      //       SizedBox(height: 8),
      //       Row(
      //         children: [
      //           _uploadedFileName != null
      //               ? Image.asset(
      //             'assets/qrcode.jpg', // Placeholder for QR image
      //             width: 50,
      //             height: 50,
      //           )
      //               : Container(
      //             width: 50,
      //             height: 50,
      //             color: Colors.grey[300],
      //           ),
      //           SizedBox(width: 16),
      //           Expanded(
      //             child: Text(_uploadedFileName ?? 'qrcode.jpg'),
      //           ),
      //           IconButton(
      //             icon: Icon(Icons.close),
      //             onPressed: () {
      //               // setState(() {
      //               //   _uploadedFileName = null;
      //               // });
      //             },
      //           ),
      //         ],
      //       ),
      //       SizedBox(height: 16),
      //       Text(
      //         "Description provided by admin",
      //         style: TextStyle(color: Colors.grey),
      //       ),
      //        Spacer(),
      //       Obx(() {
      //         return ElevatedButton(
      //           onPressed: currencyController.selectedCurrency.value.isEmpty
      //               ? null
      //               : () {
      //             // Handle continue action
      //           },
      //           style: ElevatedButton.styleFrom(
      //             backgroundColor: currencyController.selectedCurrency.value.isEmpty
      //                 ? Colors.grey[300]
      //                 : Colors.grey,
      //             padding: EdgeInsets.symmetric(vertical: 13),
      //             shape: RoundedRectangleBorder(
      //               borderRadius: BorderRadius.circular(30),
      //             ),
      //           ),
      //           child: Center(
      //             child: Text(
      //               'Continue',
      //               style: TextStyle(fontSize: 16, color: Colors.white),
      //             ),
      //           ),
      //         );
      //       }),
      //       SizedBox(height: 20),
      //
      //
      //
      //     ],
      //   ),
      // ),

    );
  }

  void _showCurrencyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Currency'),
          content: Container(
            width: double.infinity, // Makes the dialog take full width
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: currencies.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: double.infinity, // Ensures Row takes full width
                  child: GestureDetector(
                    onTap: () {
                      currencyController.setSelectedCurrency(currencies[index]);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            currencies[index],
                            style: TextStyle(fontSize: 13),
                            overflow: TextOverflow.ellipsis, // Handle long text gracefully
                          ),
                        ),
                        Obx(() {
                          return Radio<String>(
                            value: currencies[index],
                            groupValue: currencyController.selectedCurrency.value,
                            onChanged: (value) {
                              currencyController.setSelectedCurrency(value!);
                            },
                          );
                        }),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }



}

class DashedBorderPainter extends CustomPainter {
  final double borderRadius;
  final double dashWidth;
  final double dashSpace;
  final Color color;

  DashedBorderPainter({
    this.borderRadius = 10.0,
    this.dashWidth = 5.0,
    this.dashSpace = 5.0,
    this.color = Colors.grey,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    final path = Path()
      ..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        Radius.circular(borderRadius),
      ));

    _drawDashedPath(canvas, path, paint);
  }

  void _drawDashedPath(Canvas canvas, Path path, Paint paint) {
    // Convert the path into path metrics to draw dashes along it
    final PathMetrics pathMetrics = path.computeMetrics();
    for (PathMetric pathMetric in pathMetrics) {
      double distance = 0.0;
      final totalLength = pathMetric.length;

      while (distance < totalLength) {
        final pathSegment = pathMetric.extractPath(
          distance,
          distance + dashWidth,
        );
        canvas.drawPath(pathSegment, paint);
        distance += dashWidth + dashSpace;
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

// class DashedBorderPainter extends CustomPainter {
//   @override
//   void paint(Canvas canvas, Size size) {
//     double dashWidth = 5, dashSpace = 5;
//     final paint = Paint()
//       ..color = Colors.grey
//       ..strokeWidth = 1
//       ..style = PaintingStyle.stroke;
//
//     var max = size.width;
//     double startX = 0;
//     while (startX < max) {
//       canvas.drawLine(Offset(startX, 0), Offset(startX + dashWidth, 0), paint);
//       startX += dashWidth + dashSpace;
//     }
//
//     max = size.height;
//     double startY = 0;
//     while (startY < max) {
//       canvas.drawLine(Offset(0, startY), Offset(0, startY + dashWidth), paint);
//       startY += dashWidth + dashSpace;
//     }
//
//     startX = 0;
//     max = size.width;
//     while (startX < max) {
//       canvas.drawLine(Offset(startX, size.height), Offset(startX + dashWidth, size.height), paint);
//       startX += dashWidth + dashSpace;
//     }
//
//     startY = 0;
//     max = size.height;
//     while (startY < max) {
//       canvas.drawLine(Offset(size.width, startY), Offset(size.width, startY + dashWidth), paint);
//       startY += dashWidth + dashSpace;
//     }
//   }
//
//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) {
//     return false;
//   }
// }