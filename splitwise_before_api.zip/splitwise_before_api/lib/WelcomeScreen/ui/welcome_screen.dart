import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/Dashboard/ui/Dashboard_page.dart';
import 'package:splitwise/Home/ui/home_screen.dart';

import '../../Dashboard/ui/add_details.dart';






class OnboardingController extends GetxController {
  var currentPage = 0.obs;

  void onPageChanged(int index) {
    currentPage.value = index;
  }

   skip(BuildContext context) {


    Get.snackbar('Skipped', 'Onboarding skipped');
  }

  void getStarted() {
    Get.snackbar('Started', 'Get started clicked');

  }
}

class OnboardingScreen extends StatelessWidget {
  final OnboardingController onboardingController = Get.put(OnboardingController());

  final List<Map<String, String>> onboardingData = [
    {
      "image": "assets/images/split1a.png",
      "title": "Effortless Group Expense Management",

      "description": "Create groups, add friends, and manage shared expenses in one place."
    },
    {
      "image": "assets/images/split2a.png",
      "title": "Settle Up, Track Balance Stay Organized",

      "description": "Keep track of who owes what and settle payments effortlessly."
    },
    {
      "image": "assets/images/split3a.png",
      "title": "Contribute to Charity with Ease",
      "description": "Add charity in group with friends who want to contribute."
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            onPageChanged: onboardingController.onPageChanged,
            itemCount: onboardingData.length,
            itemBuilder: (context, index) {
              return OnboardingContent(
                image: onboardingData[index]['image']!,
                title: onboardingData[index]['title']!,
                description: onboardingData[index]['description']!,
              );
            },
          ),
          Obx(() {
            return onboardingController.currentPage.value != onboardingData.length - 1
                ? Positioned(
              bottom: 60,
              left: 20,
              child: GestureDetector(
                onTap: (){
                  Navigator.push(
                      context,
                    //  MaterialPageRoute(builder: (context) => HomeScreen()));
                      MaterialPageRoute(builder: (context) => DashboardScreen()));
                },
                child: Text(
                  'Skip',
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            )
                : SizedBox(); // No skip on the last screen
          }),
          Obx(() {
            return onboardingController.currentPage.value != onboardingData.length - 1
                ? Positioned(
              bottom: 60,
              right: 20,
              child: GestureDetector(
                onTap: () {
                  int nextPage = onboardingController.currentPage.value + 1;
                  onboardingController.onPageChanged(nextPage);
                },
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey,
                  child: Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                  ),
                ),
              ),
            )
                : SizedBox(); // No arrow on the last screen
          }),
          Obx(() {
            return onboardingController.currentPage.value == onboardingData.length - 1
                ? Positioned(
              bottom: 60,
              left: 20,
              right: 20,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 3.0,
                    colors: [
                      Color(0xFF5278C7), // #5278C7
                      Color(0xFF233F78), // #233F78
                    ],
                  ),
                  borderRadius: BorderRadius.circular(30), // Same as button radius
                ),
                child: ElevatedButton(
                 // onPressed: onboardingController.getStarted,
                  onPressed: (){
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(builder: (context) => HomeScreen()));

                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => CurrencySelectorScreen()));

                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 13), // Adjust padding
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    backgroundColor: Colors.transparent, // Set to transparent so gradient shows
                    shadowColor: Colors.transparent, // Remove shadow if not needed
                  ),
                  child: Text(
                    'Get started',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ),
            )
                : SizedBox(); // Only show the Get Started button on the last screen
          }),
          // Move the page indicator to be above the skip and arrow buttons
          Positioned(
            bottom: 150, // Adjust the position so it's above the buttons
            left: 0,
            right: 0,
            child: Obx(() {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(onboardingData.length, (index) {
                  return Container(
                    margin: EdgeInsets.symmetric(horizontal: 4),
                    width: onboardingController.currentPage.value == index ? 24 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: onboardingController.currentPage.value == index
                          ? Colors.black
                          : Colors.grey,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  );
                }),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class OnboardingContent extends StatelessWidget {
  final String image;
  final String title;
  final String description;

  const OnboardingContent({
    required this.image,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(height: 100,),
          Image.asset(
            image,
            height: 200,
            width: 200,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 40),
          Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Text(
            description,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }
}



/*
class OnboardingController extends GetxController {
  var currentPage = 0.obs;



  void onPageChanged(int index) {
    currentPage.value = index;
  }

  void skip() {
    Get.snackbar('Skipped', 'Onboarding skipped');
  }

  void getStarted() {
    Get.snackbar('Started', 'Get started clicked');
  }
}

class OnboardingScreen extends StatelessWidget {
  final OnboardingController onboardingController = Get.put(OnboardingController());

  late double width;
  late double height;


  final List<Map<String, String>> onboardingData = [
    {
      "image": "assets/images/split1.png",
      "title": "Lorem Ipsum",
      "description": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, to"
    },
    {
      "image": "assets/images/split2.jpeg",
      "title": "Lorem Ipsum",
      "description": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, to"
    },
    {
      "image": "assets/images/split3.jpg",
      "title": "Lorem Ipsum",
      "description": "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, to"
    }
  ];

  @override
  Widget build(BuildContext context) {

    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            onPageChanged: onboardingController.onPageChanged,
            itemCount: onboardingData.length,
            itemBuilder: (context, index) {
              return OnboardingContent(
                image: onboardingData[index]['image']!,
                title: onboardingData[index]['title']!,
                description: onboardingData[index]['description']!,
              );
            },
          ),
          Obx(() {
            return onboardingController.currentPage.value != onboardingData.length - 1
                ? Positioned(
              bottom: 60,
              left: 20,
              child: GestureDetector(
                onTap: onboardingController.skip,
                child: Text(
                  'Skip',
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
              ),
            )
                : SizedBox(); // No skip on the last screen
          }),
          Obx(() {
            return onboardingController.currentPage.value != onboardingData.length - 1
                ? Positioned(
              bottom: 60,
              right: 20,
              child: GestureDetector(
                onTap: () {
                  int nextPage = onboardingController.currentPage.value + 1;
                  onboardingController.onPageChanged(nextPage);
                },
                child: CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey,
                  child: Icon(
                    Icons.arrow_forward,
                    color: Colors.white,
                  ),
                ),
              ),
            )
                : SizedBox(); // No arrow on the last screen
          }),
          Obx(() {
            return onboardingController.currentPage.value == onboardingData.length - 1
                ? Positioned(
              bottom: 60,
              left: 20,
              right: 20,
              child: ElevatedButton(
                onPressed: onboardingController.getStarted,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  'Get started',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            )
                : SizedBox(); // Only show the Get Started button on the last screen
          }),
          Positioned(
            bottom: 100,
            left: 0,
            right: 0,
            child: Obx(() {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(onboardingData.length, (index) {
                  return Container(
                    margin: EdgeInsets.symmetric(horizontal: 4),
                    width: onboardingController.currentPage.value == index ? 24 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: onboardingController.currentPage.value == index
                          ? Colors.black
                          : Colors.grey,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  );
                }),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class OnboardingContent extends StatelessWidget {
  final String image;
  final String title;
  final String description;




  const OnboardingContent({
    required this.image,
    required this.title,
    required this.description,
  });


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [

          SizedBox(height:100,),
          Image.asset(
            image,
            height: 250,
            width: 250,
            fit: BoxFit.cover,
          ),
          SizedBox(height: 40),
          Text(
            title,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(height: 20),
          Text(
            description,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }
}
*/






