import 'package:flutter/material.dart';



class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  // void _launchUrl (String url) async{
  //   try{
  //     await  launch(url);
  //   }catch (e){
  //     print(e.toString());
  //   }
  // }
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return   Scaffold(
      backgroundColor: Colors.transparent,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            SizedBox(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(height*0.02),topRight: Radius.circular(height*0.02)),
                ),
                height: height*0.41,
                width: double.infinity,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(width: width*0.1 ,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: height*0.05 ,),
                        Image.asset('assets/images/shareTrickLogo.png',scale: 2.8,),
                        SizedBox(height: height*0.03 ,),
                        Text('Welcome to sharerise!',style: boldText.copyWith(fontSize: height*0.032,fontFamily: 'Pangram'),),
                        SizedBox(height: height*0.015 ,),
                        SizedBox(
                          height: height*0.1,
                          width: width*0.8,
                          child: InkWell(onTap: (){
                            const url = 'http://sharerise.net/';
                          //  _launchUrl(url);
                          },
                            child: Text.rich(
                              TextSpan( text: 'By Pressing the accept button, you agree with all ',style: semiBoldText,children: <TextSpan>[
                                TextSpan(text: 'Terms & Conditions',style: boldText.copyWith(color: blue, decorationColor: blue,decorationThickness: width*0.005,)),
                                //  TextSpan(text: 'Terms & Conditions, Privacy Policy',style: boldText.copyWith(color: blue, decorationColor: blue,decorationThickness: width*0.005,)),
                                //   const TextSpan(text: ' and the ' ,style: semiBoldText),
                                //   TextSpan(text: 'Disclaimer.',style: boldText.copyWith(decorationColor: blue,color: blue,decorationThickness: width*0.005))
                              ] ),
                              style: regulatText, ),
                          ),
                        ),
                        MaterialButton(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(height*0.005))),
                          minWidth: width*0.8,height: height*0.06,color: blue,onPressed: (){

                       //   Navigator.of(context).push( MaterialPageRoute(builder: (_)=>AuthenticationPage()));
                          //   Navigator.of(context).push( MaterialPageRoute(builder: (_)=>MyExample(selected: 1)));

                        },child: Text('Accept & Continue',style: boldText.copyWith(color: Colors.white,fontSize: height*0.025,),),)
                      ],
                    ),
                  ],
                ),
              ),
            )

          ],
        ),
      ),
    );
  }
}
// constant
// and the disclaimer.'

const regulatText = TextStyle(fontFamily: 'Pangram',fontWeight: FontWeight.normal);
const semiBoldText = TextStyle(fontFamily: 'Pangram',fontWeight: FontWeight.w500);
const boldText = TextStyle(fontFamily: 'Pangram',fontWeight: FontWeight.bold);
Color blue = const Color(0xFf027FFF);
