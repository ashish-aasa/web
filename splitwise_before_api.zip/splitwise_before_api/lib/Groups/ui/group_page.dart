

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/state_manager.dart';
import 'package:share_plus/share_plus.dart';
import 'package:splitwise/Expenses/ui/add_expense_details.dart';
import 'package:splitwise/Friend/ui/add_friend.dart';
import 'package:splitwise/Friend/ui/friend_details.dart';
import 'package:splitwise/Groups/ui/add_member_in_group.dart';
import 'package:splitwise/Groups/ui/group_setting.dart';
import 'package:splitwise/charity/ui/add_charity.dart';
import 'package:splitwise/charity/ui/charity_details.dart';
import 'package:splitwise/settleup/record_a_payment.dart';
import 'package:splitwise/settleup/settle_up.dart';
import 'package:splitwise/utils/colors.dart';

import '../../Expenses/ui/expense_details.dart';
import '../../settleup/settle_up_details.dart';

class GroupPageController extends GetxController {
  RxInt selectedTabIndex = 0.obs;
}


// Controller using GetX for managing visibility of buttons
class FloatingButtonControllergroup extends GetxController {
  // Observable variable for button visibility
  var isButtonVisible = false.obs;



  // Function to toggle button visibility
  void toggleButtons() {
    isButtonVisible.value = !isButtonVisible.value;
  }
}

class GroupPage extends StatefulWidget {
  @override
  _GroupPageState createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> with SingleTickerProviderStateMixin {
  final GroupPageController controller = Get.put(GroupPageController());
  late TabController _tabController;
  final FloatingButtonControllergroup floatingButtonController = Get.put(FloatingButtonControllergroup());
  TextEditingController _controller = TextEditingController();
  String savedText = '';
  var _bottomAppBarHeight =100.0;

  String dropdownValue = 'All Time';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
    _tabController.addListener(() {
      controller.selectedTabIndex.value = _tabController.index;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   leading: IconButton(
      //     icon: Icon(Icons.arrow_back),
      //     onPressed: () => Get.back(),
      //   ),
      //   backgroundColor: Colors.transparent,
      //   elevation: 0,
      // ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Group Header Section

            Stack(
              children: [
                // Background image
                Image.asset(
                  'assets/images/Bitmap.png', // Replace with your image
                  width: double.infinity,
                  height: 230,
                  fit: BoxFit.cover,
                ),
                // Back button
                Positioned(
                  top: 40, // Adjust this to position it vertically on the image
                  left: 16, // Adjust this to position it horizontally on the image
                  child: GestureDetector(
                    onTap: () {
                      // Action when the back icon is pressed
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                      size: 30, // Set the size of the back icon
                    ),
                  ),
                ),


                // Positioned container overlapping the image by 20px
                Positioned(
                  top: 210, // 230 (image height) - 20 (overlap)
                  left: 0,
                  right: 0,
                  child: Align(
                    alignment: Alignment.topCenter, // Align at the top with the offset
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.1, // Adjust the height as needed
                      decoration: BoxDecoration(
                        color: Color(0xFFF3F0FF), // Background color of the container
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25),
                          topRight: Radius.circular(25),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 10,
                            offset: Offset(0, -2), // Shadow towards the top
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Add your content here
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),







            SizedBox(height: 8),

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Positioned(
                bottom: 0,
                left: 16,
                right: 16,
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 8,
                        spreadRadius: 1,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset(
                          'assets/images/grp1.png', // Replace with group image
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Group Name',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Row(
                              children: [
                                Icon(Icons.person, size: 16), // Placeholder for SVG
                                SizedBox(width: 4),
                                Text(
                                  'Trip',
                                  style: TextStyle(fontSize: 14),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(onTap: (){

                        Navigator.push(
                            context, MaterialPageRoute(builder: (context) => GroupSettingsScreen())
                        );
                      },
                        child: IconButton(
                          icon: Icon(Icons.settings),
                          onPressed: () {

                            Navigator.push(
                                context, MaterialPageRoute(builder: (context) => GroupSettingsScreen())
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 8),
            // Group Members Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 8,
                      spreadRadius: 1,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Group Members',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        GestureDetector(onTap: (){

                          Navigator.push(
                              context, MaterialPageRoute(builder: (context) => AddMemberInGroup())
                          );

                        },
                          child: Column(
                            children: [
                              CircleAvatar(
                                radius: 24,
                                backgroundColor: Colors.grey[300],
                                child: Icon(Icons.add, size: 32),
                              ),
                              SizedBox(height: 4),
                              Text('Add Members'),
                            ],
                          ),
                        ),
                        SizedBox(width: 16),
                        Column(
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: Colors.blue,
                              child: Icon(Icons.person, size: 32, color: Colors.white),
                            ),
                            SizedBox(height: 4),
                            Text('User Name'),
                          ],
                        ),
                        Spacer(),
                        Text('1/250'),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 16),

            // Group Invitation Link Section

            GroupInvitationLinkWidget(),
            SizedBox(height: 16),

           // Tabs Section


            Container(
              height:MediaQuery.of(context).size.height *0.5,
              child: Column(

                children: [
                  Container(
                    height: 50, // Adjust the height based on content
                    color: Colors.white, // Background color for the tabs
                    child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      labelPadding: EdgeInsets.symmetric(horizontal: 16),
                      unselectedLabelColor: Colors.grey,
                      labelColor: Colors.white,
                      indicator: BoxDecoration(
                        color: Color(0xFF23395D), // Dark blue color for selected tab
                        borderRadius: BorderRadius.circular(10), // Rounded corners
                      ),
                      indicatorPadding: EdgeInsets.symmetric(vertical: 12,horizontal: -10),
                      tabs: [
                        Tab(text: 'Expenses'),
                        Tab(text: 'Balance'),
                        Tab(text: 'Totals'),
                        Tab(text: 'White Board'),
                        Tab(text: 'Export'),
                      ],
                    ),
                  ),
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        //Center(child: Text('No expenses to show')),
                        Container
                          (child: SingleChildScrollView(
                            child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: FriendPaymentDetailsWidget(),
                              ),
                              GestureDetector(onTap: (){
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => CharityDetails ()));
                              },
                                  child: CharityCard()),
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: ExpenseItem(),
                              ),
                            
                            ],
                                                    ),
                          )),
                        Center(child:

                        // Column(
                        //   children: [
                        //     Text('Balance content here'),
                        //   ],
                        // )
                        SingleChildScrollView(
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              children: [
                                // First user section
                                ExpansionTile(
                                  title: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          CircleAvatar(
                                            radius: 20,
                                            backgroundColor: Colors.blueAccent, // Icon color
                                            child: Icon(Icons.person, color: Colors.white),
                                          ),
                                          SizedBox(width: 8),
                                          Text(
                                            "Username",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Text(
                                            "will pay",
                                            style: TextStyle(color: Colors.grey, fontSize: 12),
                                          ),
                                          Text(
                                            "₹7000",
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  children: [
                                    _buildTransactionRow("Friend 1", 4000, "to Username"),
                                    _buildTransactionRow("Friend 2", 4000, "to Username"),
                                    _buildTransactionRow("Friend 3", 4000, "to Username"),
                                    _buildTransactionRow("Friend 4", 4000, "to Username"),
                                    _buildTransactionRow("Username", 14000, "to Friend 2"),
                                    _buildTransactionRow("Username", 8000, "to Friend 1"),
                                  ],
                                ),

                                // Other friends section
                                _buildFriendSection("Friend 1", 5000, "will get back"),
                                _buildFriendSection("Friend 2", 9000, "will get back"),
                                _buildFriendSection("Friend 3", 4000, "will pay"),
                                _buildFriendSection("Friend 4", 4000, "will pay"),
                              ],
                            ),
                          ),
                        ),
                        ),
                        SingleChildScrollView(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 20),
                              Padding(
                                padding: const EdgeInsets.only(left:15,right: 15),
                                child: Container(
                                  padding: EdgeInsets.symmetric(horizontal: 12),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black12,
                                        blurRadius: 5,
                                      ),
                                    ],
                                  ),
                                  child: DropdownButton<String>(
                                    value: dropdownValue,
                                    isExpanded: true,
                                    underline: SizedBox(), // Remove default underline
                                    icon: Icon(Icons.arrow_drop_down),
                                    items: <String>['This month', 'Last month', 'All Time']
                                        .map<DropdownMenuItem<String>>((String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        dropdownValue = newValue!;
                                      });
                                    },
                                  ),
                                ),
                              ),
                              SizedBox(height: 20),
                              // Financial details
                              buildFinancialDetail('Total Group Spending', '₹56000'),
                              buildFinancialDetail('Total You Paid', '₹20000'),
                              buildFinancialDetail('Your Total Share', '₹26000'),
                              buildFinancialDetail('Payment Made', '₹0'),
                              buildFinancialDetail('Payment Received', '₹0'),
                              buildFinancialDetail('Total Change in Balance', '₹0'),
                            ],
                          ),
                        ),
                        Center(child:

                        SingleChildScrollView(
                          child: Column(
                            children: [
                              // Card with Group Information and Editable TextField
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Card(
                                  color: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  elevation: 4,
                                  child: Padding(
                                    padding: const EdgeInsets.all(9.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        // Group Name and Last Update
                                        Text(
                                          'Group Name',
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(height: 8),
                                        Text(
                                          'Last Update  -  2023/06/30 18:28PM',
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        SizedBox(height: 1),
                                        Divider(), // Horizontal line
                                        SizedBox(height: 0),
                                        // Editable TextField
                                        TextField(
                                          controller: _controller,
                                          maxLines: 5,
                                          decoration: InputDecoration(
                                            hintText: 'Enter your text here...',
                                            border: InputBorder.none,
                                          ),
                                        ),
                                        SizedBox(height: 16),
                                        Align(
                                          alignment: Alignment.bottomRight,
                                          child: GestureDetector(
                                            onTap: () {
                                              setState(() {
                                                savedText = _controller.text; // Save the entered text
                                              });
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(content: Text('Text saved!')),
                                              );
                                            },
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                shape: BoxShape.circle,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.grey.withOpacity(0.5),
                                                    spreadRadius: 2,
                                                    blurRadius: 5,
                                                    offset: Offset(0, 3), // changes position of shadow
                                                  ),
                                                ],
                                              ),
                                              padding: EdgeInsets.all(10),
                                              child: Icon(
                                                Icons.check,
                                                color: Colors.blue,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        ),
                        Center(child: SingleChildScrollView(
                          child: Column(
                            children: [
                            //  Text('Export content here'),
                              _buildSecondScreen(context),

                            ],
                          ),
                        )),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          /*  Column(
              children: [
                TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  labelColor: Colors.blue,
                  unselectedLabelColor: Colors.grey,
                  indicatorColor: Colors.blue,
                  tabs: [
                    Tab(text: 'Expenses'),
                    Tab(text: 'Balance'),
                    Tab(text: 'Totals'),
                    Tab(text: 'White Board'),
                    Tab(text: 'Export'),
                  ],
                ),
                Container(
                  height: 500, // Adjust the height based on content
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      Center(child: Text('No expenses to show')),
                      Center(child: Text('Balance content here')),
                      Center(child: Text('Totals content here')),
                      Center(child: Text('White Board content here')),
                      Center(child: Text('Export content here')),
                    ],
                  ),
                ),
              ],
            ),*/

            SizedBox(height: 16),
         //   Spacer(),
            // Settle Up and Add Expense Section
            /*Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child:

              // Settle Up and Payment ID buttons
           Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        // Handle Settle Up
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey[700],
                        padding: EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: Text(
                        'Settle Up',
                        style: TextStyle(fontSize: 16,color: Colors.white),
                      ),
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        // Handle Payment ID
                       // showUPIDialog(context);

                      },
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: Colors.grey[700]!),
                        padding: EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: Text(
                        'Add Expenses',
                        style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                      ),
                    ),
                  ),
                ],
              ),
            //  SizedBox(height: 20),
            ),*/
            SizedBox(height: 32),





          ],
        ),
      ),

      bottomNavigationBar: BottomAppBar(
        color: Colors.grey.shade100,
      //  height: floatingButtonController.isButtonVisible.value ? _bottomAppBarHeight : 100 ,
        height: 100 ,
        child:  Container(


        //  height: 200,
          child:

              Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [

                    // Visibility(
                    //   visible: floatingButtonController.isButtonVisible.value,
                    //   child: Column(
                    //     children: [
                    //       Padding(
                    //         padding: const EdgeInsets.only(right: 40),
                    //         child: FloatingActionButton.extended(
                    //           onPressed: () {
                    //             // Add your charity action here
                    //
                    //           },
                    //           label: Text('Add Charity'),
                    //           //      icon: Icon(Icons.favorite_border),
                    //           backgroundColor: Colors.white,
                    //           foregroundColor: uitext,
                    //           shape: RoundedRectangleBorder(
                    //             borderRadius: BorderRadius.circular(20),
                    //           ),
                    //         ),
                    //       ),
                    //       SizedBox(height: 10),
                    //       Padding(
                    //         padding: const EdgeInsets.only(right: 35),
                    //         child: FloatingActionButton.extended(
                    //           onPressed: () {
                    //             print("clicked");
                    //             // Add your expense action here
                    //
                    //
                    //             Navigator.push(
                    //                 context, MaterialPageRoute(builder: (context) => ExpenseScreen())
                    //             );
                    //           },
                    //           label: Text('Add Expense'),
                    //           //   icon: Icon(Icons.attach_money),
                    //           backgroundColor: Colors.white,
                    //           foregroundColor: uitext,
                    //           shape: RoundedRectangleBorder(
                    //             borderRadius: BorderRadius.circular(20),
                    //           ),
                    //         ),
                    //       ),
                    //     ],
                    //   ),
                    // ),

                   SizedBox(height: 10,),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                // Handle Settle Up
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => SettleUpScreen()),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.grey[700],
                                padding: EdgeInsets.symmetric(vertical: 13),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                              child: Text(
                                'Settle Up',
                                style: TextStyle(fontSize: 16,color: Colors.white),
                              ),
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () {
                                // Handle Payment ID
                                // showUPIDialog(context);
                                floatingButtonController.toggleButtons();
                              },
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(color: Colors.grey[700]!),
                                padding: EdgeInsets.symmetric(vertical: 13),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                              child: Text(
                                'Add Expenses',
                                style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  ],
                ),
              ),


        )
      ),

      floatingActionButton: Stack(
        children: [
          Obx(() {
        return floatingButtonController.isButtonVisible.value ?

      Positioned(
      bottom: 16, // Adjust as per your design
      right: 16, // Align buttons on the right
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisSize: MainAxisSize.min,
        children: [
          Visibility(
            //  visible: floatingButtonController.isButtonVisible.value,
            visible: true,
            child: Column(
              children: [
                FloatingActionButton.extended(
                  onPressed: () {
                    // Add your charity action here
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => AddCharity()),
                    );
                  },
                  label: Text('Add Charity'),
                  backgroundColor: Colors.white,
                  foregroundColor: uitext,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                SizedBox(height: 10),
                FloatingActionButton.extended(
                  onPressed: () {
                    print("clicked");
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ExpenseScreen()),
                    );
                  },
                  label: Text('Add Expense'),
                  backgroundColor: Colors.white,
                  foregroundColor: uitext,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ],
            ),
          ),


        ],
      ),
    ):
             SizedBox.shrink();

          }
          )
        ],
      ),

    );
  }



}



// Helper method to build each transaction row
Widget _buildTransactionRow(String friendName, int amount, String toFrom) {
  return Padding(
    padding: const EdgeInsets.only(left: 16.0, right: 16.0, bottom: 8),
    child: Row(
      children: [
        CircleAvatar(
          radius: 16,
          backgroundColor: Colors.blueAccent,
          child: Icon(Icons.person, color: Colors.white, size: 16),
        ),
        SizedBox(width: 8),
        Expanded(
          child: Text(
            "$friendName need to pay ₹$amount $toFrom",
            style: TextStyle(color: Colors.black, fontSize: 14),
          ),
        ),
      ],
    ),
  );
}

// Helper method to build the friends section with expandable/collapsible feature
Widget _buildFriendSection(String friendName, int amount, String action) {
  return ExpansionTile(
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Colors.blueAccent, // Icon color
              child: Icon(Icons.person, color: Colors.white),
            ),
            SizedBox(width: 8),
            Text(
              friendName,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              action,
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
            Text(
              "₹$amount",
              style: TextStyle(
                color: action == "will get back" ? Colors.red : Colors.green,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ],
    ),
    children: [],
  );
}




Widget _buildSecondScreen(BuildContext context) {
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Row(
      children: [
        // Expanded(
        //   flex: 1,
        //   child: Center(
        //     child: Text(
        //       "Generating document for Group Expense...",
        //       style: TextStyle(fontSize: 18),
        //     ),
        //   ),
        // ),
        Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // File display box
              Container(
                width: MediaQuery.of(context).size.width*0.9,
            //    height: MediaQuery.of(context).size.height * 0.1,
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      "Document of Group Expenses",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    Icon(Icons.description, size: 60, color: Colors.green),
                    SizedBox(height: 8),

                    SizedBox(height: 4),
                    Text(
                      "File.csv",
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30),
              // Download Button

              Container(
                width: MediaQuery.of(context).size.width * 0.9, // Keeping the same width
                child: ElevatedButton(
                  onPressed: () {
                    // Handle share logic here
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF8082ED), // Button color
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12), // Padding
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start, // Align content to the left
                    children: [
                      Icon(Icons.download, color: Colors.white), // Icon on the left
                      SizedBox(width: 10), // Spacing between icon and text
                      Text("Download File", style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              ),

              SizedBox(height: 16),
              // Share Button

              Container(
                width: MediaQuery.of(context).size.width * 0.9, // Keeping the same width
                child: ElevatedButton(
                  onPressed: () {
                    // Handle share logic here
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF8082ED), // Button color
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12), // Padding
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start, // Align content to the left
                    children: [
                      Icon(Icons.share, color: Colors.white), // Icon on the left
                      SizedBox(width: 10), // Spacing between icon and text
                      Text("Share File", style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              ),

            ],
          ),
        ),
      ],
    ),
  );
}

// Helper method to create each financial detail row
Widget buildFinancialDetail(String title, String value) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 8.0),
    child: Padding(
      padding: const EdgeInsets.only(left: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 16, color: Colors.grey[700]),
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    ),
  );
}


class GroupInvitationLinkWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white, // Background color of the container
          borderRadius: BorderRadius.circular(16), // Rounded corners
          boxShadow: [
            BoxShadow(
              color: Colors.black12, // Light shadow effect
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title of the section
            Text(
              'Group Invitation Link',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 10), // Spacing between title and link field

            // The link and share icon row
            Container(
              decoration: BoxDecoration(
                color: Color(0xfff4f4fc), // Light purple background
                borderRadius: BorderRadius.circular(8), // Rounded corners for the link box
              ),
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Display the link
                  Expanded(
                    child: Text(
                      'https://shareroom/AS2eY9H',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                      overflow: TextOverflow.ellipsis, // Handles overflow
                    ),
                  ),
                  SizedBox(width: 8), // Space between link and icon
                  // Share icon
                  GestureDetector(
                    onTap: () {
                      // Add your share functionality here
                      print('Share link tapped');
                      Share.share("https://shareroom/AS2eY9H");
                    },
                    child: Icon(
                      Icons.share_outlined,
                      color: Colors.blue, // Color of the share icon
                      size: 24,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }


}


class ExpenseItem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Colors.white,
        ),
        padding: EdgeInsets.all(10),
        child: GestureDetector(onTap: (){
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => ExpenseDetailsScreen())
          );

        },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Icon and Goa Trip information
              Row(
                children: [
                  // Placeholder for image/icon
                  // Container(
                  //   width: 40,
                  //   height: 40,
                  //   decoration: BoxDecoration(
                  //     color: Colors.grey[300],
                  //     borderRadius: BorderRadius.circular(10),
                  //   ),
                  // ),

                  Container(
                    width: 40,
                    height: 40,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child:
                        Image.asset("assets/images/grp1.png")
                      // Image.network(
                      //   'https://your-image-url.com', // replace with your image URL
                      //   width: 60,
                      //   height: 60,
                      //   fit: BoxFit.cover,
                      // ),
                    ),
                  ),
                  SizedBox(width: 10),
                  // Goa Trip and Paid Info
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Goa Trip',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'Your paid ₹20000',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              // You Lent Info
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'You lent',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    '₹15000',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class FriendPaymentDetailsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: GestureDetector(onTap: (){
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => SettleUpDetails())
        );
      },
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Friend Name
              Text(
                'Friend Name',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[600],
                ),
              ),
              // Arrow and amount
              Column(
                children: [
                  Text(
                    '₹ 2,000',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[800],
                    ),
                  ),
                  SizedBox(width: 10),
                  Image.asset(
                    'assets/images/arrowblk.png',

                    width: 100,
                    height: 15,
                  ),
                ],
              ),
              // You
              Text(
                'You',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



class CharityCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            // Image Section
            ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child:
                Image.asset("assets/images/grp1.png")
              // Image.network(
              //   'https://your-image-url.com', // replace with your image URL
              //   width: 60,
              //   height: 60,
              //   fit: BoxFit.cover,
              // ),
            ),
            SizedBox(width: 12),

            // Group Name and Details Section
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Group Name and Badge
                  Row(
                    children: [
                      Text(
                        'Charity',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(width: 8),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.purple.shade200,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          '1',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 8),

                  // Trip Icon and Type
                  Row(
                    children: [
                      // Left-aligned content (SVG and 'Trip' text)
                      Expanded(
                        child: Row(
                          children: [
                            SvgPicture.asset(
                              'assets/images/CameraPlus.svg',
                              width: 16, // specify width for the icon
                              height: 16, // specify height for the icon
                              color: Colors.blue,
                            ),
                            SizedBox(width: 4),
                            Text(
                              'Trip',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Right-aligned content ('No expenses added')
                      Text(
                        'No expenses added',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),

                ],
              ),
            ),

            // Expenses Section
            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.end,
            //   children: [
            //     Text(
            //       'No expenses added',
            //       style: TextStyle(
            //         color: Colors.grey,
            //         fontSize: 12,
            //       ),
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}
