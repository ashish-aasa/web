import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:share_plus/share_plus.dart';

class InviteViaLinkScreen extends StatelessWidget {
  final String inviteLink = 'https://shareroom/AS2eY9H'; // Example group invite link

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Invite Via Link'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Description text
            Text(
              'Anyone can follow this link to join "Group Name".',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 20),

            // Group Invitation Link TextField


            GroupInvitationLinkWidget(),
            SizedBox(height: 20),

            // Copy Link Button
            ListTile(
              leading: Icon(Icons.copy, color: Colors.blue),
              title: Text('Copy Link'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: inviteLink));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Link copied to clipboard')),
                );
              },
            ),
            SizedBox(height: 10),

            // Share Link Button
            ListTile(
              leading: Icon(Icons.share, color: Colors.blue),
              title: Text('Share Link'),
              onTap: () {
                Share.share(inviteLink);
              },
            ),
          ],
        ),
      ),
    );
  }
}


class GroupInvitationLinkWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(3.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white, // Background color of the container
          borderRadius: BorderRadius.circular(16), // Rounded corners
          boxShadow: [
            BoxShadow(
              color: Colors.black12, // Light shadow effect
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title of the section
            Text(
              'Group Invitation Link',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 10), // Spacing between title and link field

            // The link and share icon row
            Container(
              decoration: BoxDecoration(
                color: Color(0xfff4f4fc), // Light purple background
                borderRadius: BorderRadius.circular(8), // Rounded corners for the link box
              ),
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Display the link
                  Expanded(
                    child: Text(
                      'https://shareroom/AS2eY9H',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black87,
                      ),
                      overflow: TextOverflow.ellipsis, // Handles overflow
                    ),
                  ),
                  SizedBox(width: 8), // Space between link and icon
                  // Share icon
                  GestureDetector(
                    onTap: () {
                      // Add your share functionality here
                      print('Share link tapped');
                      Share.share("https://shareroom/AS2eY9H");
                    },
                    child: Icon(
                      Icons.share_outlined,
                      color: Colors.blue, // Color of the share icon
                      size: 24,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

