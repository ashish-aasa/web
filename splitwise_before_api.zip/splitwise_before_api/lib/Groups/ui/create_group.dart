import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:splitwise/Groups/get_controller/group_controller.dart';


class CreateGroupScreen extends StatelessWidget {
  final GroupController controller = Get.put(GroupController());
  late double width;
  late double height;

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text('Create Group', style: TextStyle(color: Colors.black,fontSize: 19)),
       // centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // GestureDetector(
              //   onTap: controller.pickImage,
              //   child: Obx(() =>
              //
              //       CircleAvatar(
              //     radius: 50,
              //     backgroundColor: Colors.grey[200],
              //     backgroundImage: controller.imagePath.isNotEmpty
              //         ? FileImage(File(controller.imagePath.value))
              //         : null,
              //     child: controller.imagePath.isEmpty
              //         ? Icon(Icons.add, size: 40, color: Colors.grey[400])
              //         : null,
              //   )
              //
              //
              //
              //
              //   ),
              // ),
          
          
              // recent code
          
          
          
              GestureDetector(
                onTap: controller.pickImage,
                child: Obx(() => Container(
                  width: 80,  // Square size (width)
                  height: 80, // Square size (height)
                  decoration: BoxDecoration(
                  //  color: Colors.grey[200],
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),  // Shadow color
                        spreadRadius: 2,  // How wide the shadow will spread
                        blurRadius: 5,    // How blurry the shadow will be
                        offset: Offset(0, 3),  // Offset for the shadow (x, y)
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10), // Rounded corners
                    image: controller.imagePath.isNotEmpty
                        ? DecorationImage(
                      image: FileImage(File(controller.imagePath.value)),
                      fit: BoxFit.cover,
                    )
                        : null,
                  ),
                  child: controller.imagePath.isEmpty
                      ? Center( // Centering the icon inside the container
                    child: SizedBox(
                      width: 40,  // Size of the icon (smaller than container)
                      height: 40,
                      child: SvgPicture.asset(
                        'assets/images/CameraPlus.svg',
                        width: 40, // specify width for the icon
                        height: 40, // specify height for the icon
                        color: Colors.blue,
                      ),
                    ),
                  )
                      : null,
                )),
              ),
          
              SizedBox(height: 8),
              Text('Group Image', style: TextStyle(color: Colors.black54)),
              SizedBox(height: 20),
              TextField(
                onChanged: controller.setGroupName,
          
          
                decoration: InputDecoration(
                  filled: true,  // Enables filling the background
                  fillColor: Colors.white,
                  hintText: 'Group Name*',  // Hint text
          
                  hintStyle: TextStyle(
                    color: Colors.grey,  // Hint text color
                    fontSize: 16,  // Font size
                    fontWeight: FontWeight.w400,  // Optional: Font weight
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20), // Set the border radius here
                    borderSide: BorderSide(color: Colors.white ), // Optional: customize border color
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize enabled border color
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize focused border color
                  ),
                ),
              ),
              SizedBox(height: 26),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Type*', style: TextStyle(fontSize: 16, color: Colors.black)),
              ),
              SizedBox(height: 8),
              // Obx(() => Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceAround,
              //   children: [
              //     typeOption('Trip'),
              //     typeOption('Home'),
              //     typeOption('Couple'),
              //     typeOption('Other'),
              //   ],
              // )
              // ),
          
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Expanded(child: typeOption('Trip')),
                  SizedBox(width: 8,),
                  Expanded(child: typeOption('Home')),
                  SizedBox(width: 8,),
                  Expanded(child: typeOption('Couple')),
                  SizedBox(width: 8,),
                  Expanded(child: typeOption('Other')),
                ],
              ),
          
              //  Spacer(),
              SizedBox(height:height *.1,),
              Obx(() => Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 3.0,
                    colors:  controller.imagePath.isEmpty ?
          
                    [
                      Color(0xFF5278C7).withOpacity(0.4), // #5278C7
                      Color(0xFF233F78).withOpacity(0.4), // #233F78
                    ]:
                    [
                      Color(0xFF5278C7), // #5278C7
                      Color(0xFF233F78), // #233F78
                    ],
                  ),
                  borderRadius: BorderRadius.circular(30), // Same as button radius
                ),
                child: ElevatedButton(
                  onPressed: controller.canCreateGroup() ? () {} : null,
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 50),
                    backgroundColor: Colors.grey[400],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text('Create', style: TextStyle(fontSize: 18,color: Colors.white)),
                ),
              )),
            ],
          ),
        ),
      ),
    );
  }

  Widget typeOption(String type) {
    return GestureDetector(
      onTap: () => controller.setType(type),
      child: Obx(() => Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        decoration: BoxDecoration(
          color: controller.selectedType.value == type ? Colors.blue : Colors.grey[200],
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: Colors.black, // Black border color
            width: 1.0, // Border width
          ),
        ),
        child: Column(
          children: [
          //  Icon(Icons.image, color: Colors.blue),
            SvgPicture.asset(
              'assets/images/nofriend.svg',
             // 'assets/images/creategimg.svg',
              width: 20, // specify width
              height: 20, // specify height
              //color: Color(0xFF233F78), // optional: colorize the SVG
            ),

          SizedBox(height: 4),
            Text(type, style: TextStyle(fontSize: 13,color: controller.selectedType.value == type ? Colors.white : Colors.black)),
          ],
        ),
      )),
    );
  }
}
