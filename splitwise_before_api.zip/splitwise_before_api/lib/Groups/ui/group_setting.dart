import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:splitwise/Groups/ui/edit_group.dart';
import 'package:splitwise/Groups/ui/invite_link_screen.dart';

import '../../utils/colors.dart';

class GroupSettingsScreen extends StatelessWidget {
  final List<String> groupMembers = [
    'Your Name',
    'Friend Name',
    'Friend Name',
    'Friend Name'
  ];

  final List<String> phoneNumbers = [
    '98XXXXXXXX',
    '98XXXXXXXX',
    '98XXXXXXXX',
    '98XXXXXXXX'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Group Settings'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Group Info Container
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Positioned(
                  bottom: 0,
                  left: 16,
                  right: 16,
                  child: Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 8,
                          spreadRadius: 1,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset(
                            'assets/images/grp1.png', // Replace with group image
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Group Name',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              Row(
                                children: [
                                  Icon(Icons.person, size: 16), // Placeholder for SVG
                                  SizedBox(width: 4),
                                  Text(
                                    'Trip',
                                    style: TextStyle(fontSize: 14),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: IconButton(
                            icon: Icon(Icons.edit_outlined),
                            onPressed: () {

                              Navigator.push(
                                  context, MaterialPageRoute(builder: (context) => EditGroupScreen())
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),

              // Add People to Group
              ListTile(
                leading: Icon(Icons.group_add, color: Colors.blue),
                title: Text('Add People to Group'),
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey),
                onTap: () {
                  // Add functionality here
                },
              ),

              // Invite via Link
              ListTile(
                leading: Icon(Icons.share, color: Colors.blue),
                title: Text('Invite Via Link'),
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey),
                onTap: () {
                  // Add functionality here
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => InviteViaLinkScreen())
                  );

                },
              ),

              // Group Members Section
              Padding(
                padding: const EdgeInsets.only(left: 16.0, top: 16),
                child: Text(
                  'Group Members',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
              SizedBox(height: 10),

              // Group Members List
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: groupMembers.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                    child: GestureDetector(onTap: (){
                      _showCustomBottomSheet(context);
                    },
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey[300],
                          child: Icon(Icons.person, color: Colors.blue),
                        ),
                        title: Text(groupMembers[index]),
                        subtitle: Text(phoneNumbers[index]),
                      ),
                    ),
                  );
                },
              ),

              SizedBox(height: 20),

              // Advanced Settings Section
              Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: Text(
                  'Advanced Settings',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
              SizedBox(height: 10),

              // Leave Group
              ListTile(
                leading: Icon(Icons.exit_to_app, color: Colors.blue),
                title: Text('Leave Group'),
                subtitle: Text(
                  "You can't leave the group until you settle dues (if you have any).",
                  style: TextStyle(color: Colors.grey),
                ),
                onTap: () {
                  // Add functionality here
                  _showLeaveDialog(context);
                },
              ),

              // Delete Group
              ListTile(
                leading: Icon(Icons.delete, color: Colors.blue),
                title: Text('Delete Group'),
                onTap: () {
                  // Add functionality here
                  _showDeleteDialog(context);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void _showLeaveDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Title
          /*    Center(
                child: Text(
                  'Delete Group',
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),*/
              SizedBox(height: 16),
              // Content
              Text(
                'Are you sure, you want to leave the group?',
                style:
                // GoogleFonts.poppins(
                //     textStyle: TextStyle(
                //         fontSize: 16,
                //         fontWeight: FontWeight.w300,
                //         color: textColor1)),
                TextStyle(fontSize: 16.0),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              // Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child:
                      Container(

                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'No',
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ),
                      ),

                      // ElevatedButton(
                      //   onPressed: () {
                      //     Navigator.of(context).pop();
                      //   },
                      //   style: ElevatedButton.styleFrom(
                      //     backgroundColor: Colors.grey[700],
                      //     padding: EdgeInsets.symmetric(vertical: 13),
                      //     shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(30),
                      //     ),
                      //   ),
                      //   child: Text(
                      //     'Cancel',
                      //     style: TextStyle(fontSize: 16, color: Colors.white),
                      //   ),
                      // ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 3.0,
                            colors: [
                              Color(0xFF5278C7), // #5278C7
                              Color(0xFF233F78), // #233F78
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30), // Same as button radius
                        ),
                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Yes',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

void _showRemoveFriendDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Title
              // Center(
              //   child: Text(
              //     'Delete Group',
              //     style: TextStyle(
              //       fontSize: 20.0,
              //       fontWeight: FontWeight.bold,
              //     ),
              //   ),
              // ),
              SizedBox(height: 16),
              // Content
              Text(
                'Are you sure want to remove "Friend Name"  from group?',
                style:
                // GoogleFonts.poppins(
                //     textStyle: TextStyle(
                //         fontSize: 16,
                //         fontWeight: FontWeight.w300,
                //         color: textColor1)),
                 TextStyle(fontSize: 16.0),
                 textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              // Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child:
                      Container(

                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'No',
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ),
                      ),

                      // ElevatedButton(
                      //   onPressed: () {
                      //     Navigator.of(context).pop();
                      //   },
                      //   style: ElevatedButton.styleFrom(
                      //     backgroundColor: Colors.grey[700],
                      //     padding: EdgeInsets.symmetric(vertical: 13),
                      //     shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(30),
                      //     ),
                      //   ),
                      //   child: Text(
                      //     'Cancel',
                      //     style: TextStyle(fontSize: 16, color: Colors.white),
                      //   ),
                      // ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 3.0,
                            colors: [
                              Color(0xFF5278C7), // #5278C7
                              Color(0xFF233F78), // #233F78
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30), // Same as button radius
                        ),
                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Yes,Remove',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

void _showDeleteDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.9, // Increase the width to 90% of the screen width
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Title
              Center(
                child: Text(
                  'Delete Group',
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 16),
              // Content
              Text(
                'Are you sure, you want to delete the group? This will remove this group for all members & lost all data.',
                style:
                // GoogleFonts.poppins(
                //     textStyle: TextStyle(
                //         fontSize: 16,
                //         fontWeight: FontWeight.w300,
                //         color: textColor1)),
                TextStyle(fontSize: 16.0),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              // Buttons
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child:
                      Container(

                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Cancel',
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ),
                      ),

                      // ElevatedButton(
                      //   onPressed: () {
                      //     Navigator.of(context).pop();
                      //   },
                      //   style: ElevatedButton.styleFrom(
                      //     backgroundColor: Colors.grey[700],
                      //     padding: EdgeInsets.symmetric(vertical: 13),
                      //     shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(30),
                      //     ),
                      //   ),
                      //   child: Text(
                      //     'Cancel',
                      //     style: TextStyle(fontSize: 16, color: Colors.white),
                      //   ),
                      // ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 3.0,
                            colors: [
                              Color(0xFF5278C7), // #5278C7
                              Color(0xFF233F78), // #233F78
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30), // Same as button radius
                        ),
                        child: OutlinedButton(
                          onPressed: () {
                            // Perform delete action here
                          },
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.grey[700]!),
                            padding: EdgeInsets.symmetric(vertical: 13),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Yes, Delete',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}

void _showCustomBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(20.0),
      ),
    ),
    builder: (BuildContext context) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // The small handle at the top of the bottom sheet
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.blue.shade700,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            // First option with eye icon
            GestureDetector(onTap: (){

            },
              child: Row(
                children: [
                  Icon(
                    Icons.remove_red_eye_outlined,
                    color: Colors.blue.shade700,
                    size: 28,
                  ),
                  SizedBox(width: 10),
                  Text(
                    'View in friend settings',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            // Second option with trash icon
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.delete_outline,
                  color: Colors.blue.shade700,
                  size: 28,
                ),
                SizedBox(width: 10),
                GestureDetector(onTap: (){
                  _showRemoveFriendDialog(context);
                },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Remove Friend name from the Group',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'You can’t remove the friend if the friend has any\noutstanding balance.',
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
          ],
        ),
      );
    },
  );
}



/*
void _showDeleteDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Container(
          width: MediaQuery.of(context).size.width , // Set the width here (85% of screen width)
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min, // Adjust to the content size
            children: [
              Text(
                'Delete Group',
                style: TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16.0),
              Text(
                'Are you sure, you want to delete the group? This will remove this group for all members & lost all data.',
                style: TextStyle(fontSize: 16.0),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24.0),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey[700],
                          padding: EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: Text(
                          'Cancel',
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          // Handle delete action
                        },
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: Colors.grey[700]!),
                          padding: EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: Text(
                          'Yes, Delete',
                          style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
*/



