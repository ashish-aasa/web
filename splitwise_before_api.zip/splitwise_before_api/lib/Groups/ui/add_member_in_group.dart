import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:splitwise/Friend/ui/friend_details.dart';
import 'package:splitwise/Groups/ui/group_page.dart';
import 'package:splitwise/utils/colors.dart';

class AddMemberInGroupController extends GetxController {
  var contacts = List<Contact>.empty(growable: true).obs;
  var selectedContacts = List<Contact>.empty(growable: true).obs;
  var searchQuery = ''.obs;
  RxBool isLoading = false.obs;
  var isPermissionGranted = false.obs;

  @override
  void onInit() {
    super.onInit();
    // requestContactPermission();
    loadSelectedContacts();
  }

  // Request permission to access contacts
  void requestContactPermission() async {
    PermissionStatus permission = await Permission.contacts.status;
    if (permission != PermissionStatus.granted) {
      permission = await Permission.contacts.request();
    }

    if (permission == PermissionStatus.granted) {
      isPermissionGranted.value = true;
      loadContacts();

    } else {
      Get.snackbar('Permission Denied', 'Contact access is required to load contacts.');
    }
  }

  // Load contacts from the phone contact list
  void loadContacts() async {
    isLoading.value = true;
    Iterable<Contact> phoneContacts = await ContactsService.getContacts();
    contacts.assignAll(phoneContacts.toList());
    isLoading.value = false;
  }

  // Select/Deselect contact using radio buttons
  void selectContact(Contact contact) {
    if (selectedContacts.contains(contact)) {
      selectedContacts.remove(contact);
    } else {
      selectedContacts.add(contact);
    }
  }

  void saveSelectedContacts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> selectedContactsJson = selectedContacts.map((contact) => jsonEncode(contact.toMap())).toList();
    prefs.setStringList('selectedContacts', selectedContactsJson);
  }

  void loadSelectedContacts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? selectedContactsJson = prefs.getStringList('selectedContacts');
    if (selectedContactsJson != null) {
      selectedContacts.assignAll(
        selectedContactsJson.map((contact) => Contact.fromMap(jsonDecode(contact))).toList(),
      );
    }
  }

  // Filter contacts based on search query
  List<Contact> get filteredContacts => searchQuery.isEmpty
      ? contacts
      : contacts
      .where((c) => c.displayName != null && c.displayName!.toLowerCase().contains(searchQuery.value.toLowerCase()))
      .toList();
}

class AddMemberInGroup extends StatelessWidget {
  final AddMemberInGroupController controller = Get.put(AddMemberInGroupController());
  late double width;
  late double height;


  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Members'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body:
      Obx(() {
        return controller.isPermissionGranted.value
            ? Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(

            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Bar

              TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Search...',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onChanged: (value) => controller.searchQuery.value = value,
              ),
              SizedBox(height: 16),
              Text('From your contacts', style: TextStyle(fontSize: 17,color: Colors.grey),textAlign: TextAlign.left,),
              SizedBox(height: 10),
              Expanded(
                child: Obx(() {
                  return controller.isLoading.value
                      ? Center(child: CircularProgressIndicator()):
                  ListView.builder(
                    itemCount: controller.filteredContacts.length,
                    itemBuilder: (context, index) {
                      Contact contact = controller.filteredContacts[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey[300],
                          child: contact.avatar != null
                          //    ? Image.file(contact.avatar!)
                              ? Text("")
                              : Text(
                            contact.displayName != null ? contact.displayName![0] : '',
                            style: TextStyle(
                              color: Colors.pinkAccent,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        title: Text(contact.displayName ?? 'Unknown'),
                        subtitle: Text(contact.phones!.isNotEmpty ? contact.phones!.first.value! : 'No Phone Number'),
                        trailing: Obx(() {
                          return Radio(
                            value: contact,
                            groupValue: controller.selectedContacts.contains(contact) ? contact : null,
                            onChanged: (value) {
                              controller.selectContact(contact);
                            },
                          );
                        }),
                      );
                    },
                  );
                }),
              ),
              SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[800], // Dark button color
                    padding: EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: () {
                    controller.saveSelectedContacts();
                    Get.to(VerifyContactinfoGroup());
                  },
                  child: Text('Add', style: TextStyle(fontSize: 16,color: Colors.white)),
                ),
              ),
            ],
          ),
        )
            : Padding(
          padding: const EdgeInsets.symmetric(horizontal: 34.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height:height *.2,),

              CircleAvatar(
                child: Image.asset("assets/images/allowcontact.png"),
                radius: 60,
                backgroundColor: Colors.grey[300],
              ),

              SizedBox(height: 30),
              // Permission request text
              Text(
                'Allow Splitwise to access your contacts to add friends.'+controller.isPermissionGranted.value.toString(),
                textAlign: TextAlign.center,
                style: TextStyle(

                  color: Colors.grey,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 32),
              // Allow contact access button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                  //  backgroundColor: Colors.grey[800], // Dark button color
                    backgroundColor: uitext,
                    padding: EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () {
                    controller.requestContactPermission();
                  },
                  child: Text(
                    'Allow contact access',
                    style: TextStyle(fontSize: 16,
                        color: Colors.white

                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      }),



    );
  }
}





class VerifyContactinfoGroup extends StatelessWidget {
  final AddMemberInGroupController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.white,
        // elevation: 0,
        // leading: IconButton(
        //   icon: Icon(Icons.arrow_back, color: Colors.black),
        //   onPressed: () => Get.back(),
        // ),
        title: Text(
          'Verify Contact Info',
          style: TextStyle(color: Colors.black),
        ),
        //centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: Obx(() {
                return ListView.builder(
                  itemCount: controller.selectedContacts.length,
                  itemBuilder: (context, index) {
                    Contact contact = controller.selectedContacts[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.2),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child:
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 8.0), // Add padding inside the container for better layout
                            // decoration: BoxDecoration(
                            //   color: Colors.white,
                            //   borderRadius: BorderRadius.circular(20),
                            //   boxShadow: [
                            //     BoxShadow(
                            //       color: Colors.grey.withOpacity(0.2),
                            //       spreadRadius: 2,
                            //       blurRadius: 5,
                            //       offset: Offset(0, 3),
                            //     ),
                            //   ],
                            // ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 25,
                                  backgroundColor: Colors.grey[300],
                                  child: contact.avatar != null
                                      ? Text("") // You can replace this with the Image widget if needed
                                      : Icon(Icons.person, size: 40, color: Colors.blue),
                                ),
                                SizedBox(width: 12), // Space between avatar and contact info
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(contact.displayName ?? 'Unknown',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          )),
                                      SizedBox(height: 4),
                                      Text(
                                        contact.phones!.isNotEmpty
                                            ? contact.phones!.first.value!
                                            : 'No Phone Number',
                                        style: TextStyle(color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 20),
                                  child: IconButton(
                                    icon:
                                    //Icon(Icons.close, color: Colors.red, size: 24), // Adjust the size of the icon
                                    Image.asset("assets/images/xmark.png",width: 25,height: 25,),
                                    onPressed: () {
                                      // Remove contact from the list
                                      controller.selectedContacts.removeAt(index);
                                    },
                                  ),
                                ),

                              ],
                            ),
                          ),
                        )


                      ),
                    );
                  },
                );
              }),
            ),
          //  SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(""),
                TextButton.icon(
                  onPressed: () {
                    // Add functionality to add more contacts
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => AddMemberInGroup())
                    );

                  },
                  icon: Icon(Icons.add_circle_outline, color: Color(0xFF5278C7)),
                  label: Text("Add more", style: TextStyle(color: Color(0xFF5278C7))),
                  style: TextButton.styleFrom(
                    side: BorderSide(color: Color(0xFF5278C7)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'A notification will be sent to these people after adding them in friend list.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Confirm action
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => GroupPage())
                );

              },
              child: Text('Confirm',style: TextStyle(color: Colors.white,fontSize: 18),),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF23395D), // Dark blue color
                minimumSize: Size(double.infinity, 50), // Full-width button
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


// class VerifyContactinfoGroup extends StatelessWidget {
//   final AddMemberInGroupController controller = Get.find();
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Verify Contact info *'),
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () => Get.back(),
//         ),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Obx(() {
//           return GestureDetector(onTap: (){
//             Navigator.push(
//                 context, MaterialPageRoute(builder: (context) => FriendDetailsScreen())
//             );
//
//           },
//             child: ListView.builder(
//               itemCount: controller.selectedContacts.length,
//               itemBuilder: (context, index) {
//                 Contact contact = controller.selectedContacts[index];
//                 return ListTile(
//                   leading: CircleAvatar(
//                     backgroundColor: Colors.grey[300],
//                     child: contact.avatar != null
//                     // ? Image.file()
//                         ? Text("")
//                         : Text(
//                       contact.displayName != null ? contact.displayName![0] : '',
//                       style: TextStyle(
//                         color: Colors.pinkAccent,
//                         fontSize: 18,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                   title: Text(contact.displayName ?? 'Unknown'),
//                   subtitle: Text(contact.phones!.isNotEmpty ? contact.phones!.first.value! : 'No Phone Number'),
//                 );
//               },
//             ),
//           );
//         }),
//       ),
//     );
//   }
// }
//








