import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class GroupController extends GetxController {
  var groupName = ''.obs;
  var selectedType = ''.obs;
  var imagePath = ''.obs;

  final ImagePicker picker = ImagePicker();

  void pickImage() async {
    final XFile? pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      imagePath.value = pickedFile.path;
    }
  }

  void setGroupName(String value) {
    groupName.value = value;
  }

  void setType(String type) {
    selectedType.value = type;
  }

  bool canCreateGroup() {
    return groupName.isNotEmpty && selectedType.isNotEmpty && imagePath.isNotEmpty;
  }
}
