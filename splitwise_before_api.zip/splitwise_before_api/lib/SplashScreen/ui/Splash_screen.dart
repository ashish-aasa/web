import 'package:flutter/material.dart';
import 'package:splitwise/Authentication/ui/Sign_up.dart';
import '../../WelcomeScreen/ui/Welcome_page.dart';
import '../../utils/shared_prefhelper.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    call();
  }

  Future call() async {
   // bool isLoggedIn = await SharedPrefHelper().getWithDefault("logintokencheck", false);
   // print("Login Token Check: $isLoggedIn");

    Future.delayed(const Duration(seconds: 2)).then((value) {
     // if (isLoggedIn) {
      if (false) {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => WelcomePage())
        );
      } else {
        showDialog(
            context: context,
            builder: (context) {
              return  Scaffold(
                backgroundColor: Colors.transparent,
                body: SignUpPage(),
              );
            }
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.blue,
      body: Stack(
        children: [
          // Background image (Full-screen)
          SizedBox(
            width: width,
            height: height,
            child: Image.asset(
              'assets/images/bgwhite.png',

              fit: BoxFit.cover,
            ),
          ),
          // Centered logo
        //  Center(child: Text("sdfds")),
          Center(
            child: Container(
              // width: width * 0.358,
              // height: height * 0.272,
              child: Image.asset(
                'assets/images/logoplace.png',
                fit: BoxFit.contain,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
