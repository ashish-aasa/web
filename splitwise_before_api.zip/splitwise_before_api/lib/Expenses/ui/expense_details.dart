import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:splitwise/utils/colors.dart';

class ExpenseController extends GetxController {
  var expenseTitle = "Goa Trip".obs;
  var expenseAmount = 20000.obs;
  var paidAmount = 20000.obs;
  var participants = [
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "Friend Name", "share": 4000.obs},
    {"name": "User Name", "share": 4000.obs}
  ].obs;
  var expenseDate = "06 August 2024".obs;
  var notes =
      "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, to"
          .obs;
  var photo = "photo.jpg".obs;
}

class ExpenseDetailsScreen extends StatelessWidget {
  final ExpenseController controller = Get.put(ExpenseController());
  late double width;
  late double height;

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Text('Expense Details'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Expense Section
              Container(
                width: width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                //  color: Colors.grey[200],
                  gradient: LinearGradient(
                    colors: [cardColor, cardColor2,cardColor2],
                    stops: [0.001, 0.5, 0.8], // Stops for each color
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),

                ),
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                //    Icon(Icons.image, size: 60, color: Colors.grey),
                    Container(
                      width: 40,
                      height: 40,
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child:
                          Image.asset("assets/images/grp1.png")
                        // Image.network(
                        //   'https://your-image-url.com', // replace with your image URL
                        //   width: 60,
                        //   height: 60,
                        //   fit: BoxFit.cover,
                        // ),
                      ),
                    ),
                    SizedBox(height: 8),
                    Obx(() => Text(controller.expenseTitle.value,
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold,color: Colors.white))),
                    SizedBox(height: 4),
                    Obx(() => Text("₹${controller.expenseAmount.value}",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold,color: Colors.white))),
                  ],
                ),
              ),
              SizedBox(height: 16),

              // Date
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Split Details",style: TextStyle(fontSize: 18),),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Obx(() => Text(controller.expenseDate.value,
                        style: TextStyle(color: Colors.grey))),
                  ),
                ],
              ),
              SizedBox(height: 8),

              // You Paid and Friends' Shares
              Obx(() => Column(
                children: [
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.blue[300],
                      child:
                      Image.asset("assets/images/expdeusericon.png")
                     // Icon(Icons.person, color: Colors.grey),
                    ),
                    title: Text('You paid'),
                    trailing: Text('₹${controller.paidAmount.value}',
                        style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18,color: Color(0xFFFF675E))),
                  ),
                  for (var participant in controller.participants)
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: ListTile(
                        leading: Container(
                          width: 30,
                          height: 30,
                          child: CircleAvatar(
                            backgroundColor: Colors.grey[300],
                            child:
                                
                                Image.asset("assets/images/expdeusericon.png")
                            // SvgPicture.asset(
                            //   'assets/images/expdeuser.svg',
                            //   // 'assets/images/creategimg.svg',
                            //   width: 20, // specify width
                            //   height: 20, // specify height
                            //   //color: Color(0xFF233F78), // optional: colorize the SVG
                            // ),

                         //   Icon(Icons.person, color: Colors.grey,),
                          ),
                        ),
                        title: Text("${participant['name']}’s share",style: TextStyle(fontSize: 13),),
                        trailing: Text('₹${participant['share'].obs}',
                            style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xFF0E8A8E))),
                      ),
                    ),
                ],
              )),
              SizedBox(height: 16),

              // Notes Section
              Text("Notes", style: TextStyle(fontSize: 16)),
              SizedBox(height: 8),
              Obx(() => Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey),
                ),
                child: Text(controller.notes.value),
              )),
              SizedBox(height: 16),

              // Photo Section
              Text("Photo", style: TextStyle(fontSize: 16)),
              SizedBox(height: 8),
              Obx(() => GestureDetector(onTap: (){
                _showImagePopup(context);
              },
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey),
                  ),
                  child: GestureDetector(onTap: (){
                    _showImagePopup(context);
                  },
                    child: Row(
                      children: [
                       // Icon(Icons.image, size: 40, color: Colors.grey),
                        Image.asset("assets/images/jpeg.png"),
                        SizedBox(width: 8),
                        Text(controller.photo.value),
                      ],
                    ),
                  ),
                ),
              )),
            ],
          ),
        ),
      ),
    );
  }




  void _showImagePopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          // Removing insetPadding to ensure the image covers the popup completely
          insetPadding: EdgeInsets.only(top: 100,bottom: 100,left: 20,right: 20),
          child: Stack(
            children: [
              // Background Image covering the whole popup
              Positioned.fill(
                child: Image.asset(
                  "assets/images/icecream.jpeg",
                  fit: BoxFit.cover, // Ensures the image covers the entire space
                ),
              ),

              // Close Button in the top-right corner
              Positioned(
                top: 20,
                right: 20,
                child: GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop(); // Close the popup
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white, // Background color of the close button
                      shape: BoxShape.circle,
                    ),
                    padding: EdgeInsets.all(8),
                    child: Icon(
                      Icons.close,
                      color: Colors.black, // Color of the cross icon
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

}

