import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';


class ExpenseControllerDetails extends GetxController {
  var selectedFriend = 'Select'.obs;
  var selectedPaidBy = 'Friend 1'.obs;
  var selectedSplitOption = 'equally'.obs;
  var selectedDate = 'Date'.obs;
  var selectedImageName = 'Upload Receipt'.obs;
  var notes = ''.obs;

  var paidAmount = 20000.obs;
  var participants = [
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "Friend Name", "share": 0.obs},
    {"name": "User Name", "share": 0.obs}
  ].obs;

  // Function to set selected date
  void pickDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null) {
      selectedDate.value = DateFormat('dd MMM').format(pickedDate);
    }
  }

  // Function to pick an image from the gallery
  void pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      selectedImageName.value = image.name;
    }
  }

  // Function to open notes editor
  void openNotesEditor(BuildContext context) {
    TextEditingController notesController = TextEditingController(text: notes.value);
    Get.bottomSheet(
      Container(
        padding: EdgeInsets.all(20),
        color: Colors.white,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: notesController,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'Enter your notes',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                notes.value = notesController.text;
                Get.back();
              },
              child: Text('Save Notes'),
            )
          ],
        ),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      home: ExpenseScreen(),
    );
  }
}

class AddExpenseDetailsController extends GetxController {
  var selectedCurrency = ''.obs;
  RxBool isLoading = false.obs;
  Rx<XFile?> selectedScreenshot = Rx<XFile?>(null);

  void setSelectedCurrency(String currency) {
    selectedCurrency.value = currency;
    Get.back(); // Close the popup after selection
  }


  Future<void> pickScreenshot() async {
    isLoading.value = true;
    ImagePicker picker = ImagePicker();
    await picker.pickImage(source: ImageSource.gallery).then((value) {
      selectedScreenshot.value = value;
      print("skillllling pick get c" + selectedScreenshot.value.toString());
    });
    isLoading.value = false;
  }

  void removeScreenshot() {
    selectedScreenshot.value = null;
  }

  var selectedCurrencies = <String>[].obs; // List to store selected items

  void toggleCurrencySelection(String currency) {
    if (selectedCurrencies.contains(currency)) {
      selectedCurrencies.remove(currency);
    } else {
      selectedCurrencies.add(currency);
    }
  }
}

class ExpenseScreen extends StatelessWidget {
  final ExpenseControllerDetails controller = Get.put(ExpenseControllerDetails());
  final AddExpenseDetailsController currencyController = Get.put(AddExpenseDetailsController());

  final List<String> friends = ['Friend 1', 'Friend 2', 'Friend 3'];
  final List<String> splitOptions = ['equally', 'unequally', 'percentage'];
  late double width;
  late double height;

  final List<String> currencies = [
   // 'All Members of group name',
    'All Members ',
    'Friend 1',
    'Friend 2',
    'Friend 3',
    'Friend 4',
    'Friend 5',
    'Friend 6',

  ];
  void _showCurrencyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Members',style: TextStyle(fontSize: 18),),
          content: Container(
            width: double.infinity,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: currencies.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: double.infinity,
                  child: Obx(() {
                    bool isSelected = currencyController.selectedCurrencies.contains(currencies[index]);

                    return GestureDetector(
                      onTap: () {
                        currencyController.toggleCurrencySelection(currencies[index]);
                      },
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    currencies[index],
                                    style: TextStyle(fontSize: 13),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Icon(
                                  isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                                  color: isSelected ? Colors.blue : Colors.grey,
                                ),

                              ],
                            ),
                          ),
                          Divider(height: 2,
                          color:Colors.grey[300],
                          )
                        ],
                      ),
                    );
                  }),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('Done'),
            ),
          ],
        );
      },
    );
  }

/*  void _showCurrencyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Select Currency'),
          content: Container(
            width: double.infinity, // Makes the dialog take full width
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: currencies.length,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: double.infinity, // Ensures Row takes full width
                  child: GestureDetector(
                    onTap: () {
                      currencyController.setSelectedCurrency(currencies[index]);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            currencies[index],
                            style: TextStyle(fontSize: 13),
                            overflow: TextOverflow.ellipsis, // Handle long text gracefully
                          ),
                        ),
                        Obx(() {
                          return Radio<String>(
                            value: currencies[index],
                            groupValue: currencyController.selectedCurrency.value,
                            onChanged: (value) {
                              currencyController.setSelectedCurrency(value!);
                            },
                          );
                        }),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }*/

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Add Expense'),
            Text('Group Name', style: TextStyle(color: Colors.red,fontSize: 17)),
          ],
        ),
      ),
      body: SingleChildScrollView(
       // color: Colors.grey.shade100,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Group Name



            // With you and Select Dropdown

        Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Row(
          children: [
          Text('With you and:'),
          SizedBox(width: 10),
          GestureDetector(
            onTap: () => _showCurrencyDialog(context),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
              ),
              child:

              Obx(() {
                String selectedText = currencyController.selectedCurrencies.isEmpty
                    ? 'Select'
                    : currencyController.selectedCurrencies.join(', ');


                return

                  Container(
                    constraints: BoxConstraints(
                      maxWidth: 190, // Set a max width to allow scrolling
                    ),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal, // Enables horizontal scrolling
                      child: Text(
                        selectedText,
                        style: TextStyle(
                          color: selectedText == 'Select' ? Colors.black : Colors.black,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  );
                //   Row(
                //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //   children: [
                //     Text(
                //       selectedText,
                //       maxLines: 4, // Limit text to 4 lines
                //       overflow: TextOverflow.ellipsis,
                //       style: TextStyle(
                //         color: selectedText == 'Select' ? Colors.black : Colors.black,
                //         fontSize: 16,
                //       ),
                //     ),
                //     Icon(Icons.arrow_drop_down),
                //   ],
                // );
              }),
            ),
          ),
          ],
                  ),
        ),
         /*   Row(
              children: [
                Text('With you and:'),
                SizedBox(width: 10),
                GestureDetector(
                  onTap: () => _showCurrencyDialog(context),
                  child: Container(

                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      //   color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(8),
                      //   border: Border.all(color: Colors.grey),
                      // gradient: RadialGradient(
                      //   center: Alignment.center,
                      //   radius: 3.0,
                      //   colors: [
                      //     Color(0xFF8082ED), // #5278C7
                      //     Color(0xFF9B9CF8), // #233F78
                      //   ],
                      // ),


                    ),
                    child: Obx(() {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            currencyController.selectedCurrency.value.isEmpty
                                ? 'Select'
                                : currencyController.selectedCurrency.value,
                            style: TextStyle(
                              color: currencyController.selectedCurrency.value.isEmpty
                                  ? Colors.black
                                  : Colors.black,
                              fontSize: 16,
                            ),
                          ),
                          Icon(Icons.arrow_drop_down),
                        ],
                      );
                    }),
                  ),
                ),
          *//*      Expanded(
                  child: Obx(() => DropdownButton<String>(
                    value: controller.selectedFriend.value,
                    onChanged: (value) => controller.selectedFriend.value = value!,
                    items: friends.map((friend) {
                      return DropdownMenuItem(
                        value: friend,
                        child: Text(friend),
                      );
                    }).toList(),
                  )),
                ),*//*
              ],
            ),*/
            SizedBox(height:height *.05,),

            Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Text('Add Description'),
            ),
            SizedBox(height: 10,),
            // Description field
            // TextField(
            //   decoration: InputDecoration(
            //     labelText: 'Add Description',
            //     border: OutlineInputBorder(),
            //   ),
            // ),

            Padding(
              padding: const EdgeInsets.only(left: 16,right: 16),
              child: TextField(
              //  onChanged: controller.setGroupName,


                decoration: InputDecoration(
                  filled: true,  // Enables filling the background
                  fillColor: Colors.white,
                  hintText: 'Add Description',  // Hint text

                  hintStyle: TextStyle(
                    color: Colors.grey,  // Hint text color
                    fontSize: 16,  // Font size
                    fontWeight: FontWeight.w400,  // Optional: Font weight
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20), // Set the border radius here
                    borderSide: BorderSide(color: Colors.white ), // Optional: customize border color
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize enabled border color
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.white), // Customize focused border color
                  ),
                ),
              ),
            ),
            SizedBox(height: 10),

            // Amount section
            Container(
              color: Colors.white,
              height: 100,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Container(
                      width: 100,
                      child: OutlinedButton(
                        onPressed: () {
                          // Handle Payment ID


                        },
                        style: OutlinedButton.styleFrom(
                          // side: BorderSide(color: Colors.grey[700]!),
                          side: BorderSide(color:Color(0xFF233f78),),
                          padding: EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(13),
                          ),
                        ),
                        child: Text(
                          'Amount (₹)',
                          style: TextStyle(fontSize: 16, color: Color(0xFF233f78),),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: TextField(
                        style: TextStyle(
                          fontSize: 20,  // Set font size to 20
                        ),
                        textAlign: TextAlign.right,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: '0',
                        //  border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 20,),
                ],
              ),
            ),
            SizedBox(height: 10),

            Divider(height: 2,
            ),
            SizedBox(height: 10),
            // Date, Upload Receipt, Notes
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                GestureDetector(
                  onTap: () => controller.pickDate(context),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset("assets/images/CalendarDots.png"),
                      SizedBox(width: 5,),
                      Obx(() => Text(controller.selectedDate.value)),
                    ],
                  ),
                ),
              Text("|"),
                GestureDetector(
                  onTap: () => controller.pickImage(),
                  child: Row(
                    children: [
                      Image.asset("assets/images/bxs_image.png"),
                      SizedBox(width: 5,),
                      Obx(() => Text(controller.selectedImageName.value)),
                    ],
                  ),
                ),
                Text("|"),
                GestureDetector(
                  onTap: () => controller.openNotesEditor(context),
                  child: Row(
                    children: [
                      Image.asset("assets/images/ic_round-edit-note.png"),
                      SizedBox(width: 5,),
                      Text('Notes'),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Divider(height: 2,
            ),
            SizedBox(height: 20),

            // Paid by and Split options
            Padding(
              padding: const EdgeInsets.only(left: 16,right: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Paid by dropdown
                  Row(
                    children: [
                      Text('Paid by'),
                      SizedBox(width: 10),
                      Obx(() => DropdownButton<String>(
                        value: controller.selectedPaidBy.value,
                        onChanged: (value) => controller.selectedPaidBy.value = value!,
                        items: friends.map((friend) {
                          return DropdownMenuItem(
                            value: friend,
                            child: Text(friend),
                          );
                        }).toList(),
                      )),
                    ],
                  ),

                  // Split dropdown
                  Row(
                    children: [
                      Text('and Split'),
                      SizedBox(width: 5),
                      Obx(() => DropdownButton<String>(
                        value: controller.selectedSplitOption.value,
                        onChanged: (value) => controller.selectedSplitOption.value = value!,
                        items: splitOptions.map((option) {
                          return DropdownMenuItem(
                            value: option,
                            child: Text(option),
                          );
                        }).toList(),
                      )),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),



            Obx(() => Column(
              children: [

                for (var participant in controller.participants)
                  Padding(
                    padding: const EdgeInsets.only(left: 20),
                    child: ListTile(
                      leading: Container(
                        width: 30,
                        height: 30,
                        child: CircleAvatar(
                            backgroundColor: Colors.grey[300],
                            child:

                            Image.asset("assets/images/expdeusericon.png")
                          // SvgPicture.asset(
                          //   'assets/images/expdeuser.svg',
                          //   // 'assets/images/creategimg.svg',
                          //   width: 20, // specify width
                          //   height: 20, // specify height
                          //   //color: Color(0xFF233F78), // optional: colorize the SVG
                          // ),

                          //   Icon(Icons.person, color: Colors.grey,),
                        ),
                      ),
                      title: Text("${participant['name']}",style: TextStyle(fontSize: 13),),
                      trailing: Text('₹${participant['share'].obs}',
                          style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xFF0E8A8E))),
                    ),
                  ),
              ],
            )),

         //   Spacer(),


          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.grey.shade100,
        child:  Obx(() => Container(

          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 3.0,
              colors:   currencyController.selectedCurrencies.isEmpty ?

              [
                Color(0xFF5278C7).withOpacity(0.4), // #5278C7
                Color(0xFF233F78).withOpacity(0.4), // #233F78
              ]:
              [
                Color(0xFF5278C7), // #5278C7
                Color(0xFF233F78), // #233F78
              ],
            ),
            borderRadius: BorderRadius.circular(30), // Same as button radius
          ),
          child: ElevatedButton(
            onPressed: null,

            //  controller.canCreateGroup() ? () {} : null,
            style: ElevatedButton.styleFrom(

              minimumSize: Size(double.infinity, 50),
              backgroundColor: Colors.grey[400],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text('Save', style: TextStyle(fontSize: 18,color: Colors.white)),
          ),
        )),
      ),
    );
  }
}
