import 'dart:convert';


import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:splitwise/Authentication/model/sign_up_response_model.dart';
import 'package:splitwise/Authentication/ui/Sign_In.dart';
import 'package:splitwise/Authentication/ui/otp_screen.dart';
import 'package:splitwise/WelcomeScreen/ui/welcome_screen.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'dart:math';
class SignUpController extends GetxController {
  var fullName = ''.obs;
  var email = ''.obs;
  var phoneNumber = ''.obs;


  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  // RxBool isLoading = false.obs;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // api integration

  var isLoading = false.obs;
  String generateRandom6DigitNumber() {
    Random random = Random();
    int randomNumber = 100000 + random.nextInt(900000); // Generate a number between 100000 and 999999
    return randomNumber.toString();
  }
  Future<void> signUp(String fullName, String email, String mobile, String verificationId) async {
    isLoading(true);
    final url = Uri.parse('https://expense-sharing.in1.apiqcloud.com/api/auth/sign-up');

    // Create the request body
    final body = jsonEncode({
      "fullname": fullName,
      "email": email,
      "mobno": mobile,
      "verificationId": verificationId,
    });

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: body,
      );

      if (response.statusCode == 200) {
        // Parse the response body into a model
        SignupResponseModel signupResponse = signupResponseModelFromJson(response.body);

        Get.to(() => OtpScreen(
          verificationId: verificationId,
        ));

        // Save data in SharedPreferences
        await saveUserData(
          id: signupResponse.data?.id ?? '',
          fullName: signupResponse.data?.fullName ?? '',
          email: signupResponse.data?.email ?? '',
          mobile: signupResponse.data?.mobile ?? '',
          token: signupResponse.data?.token ?? '',
        );

        Get.snackbar('Success', 'User registered successfully');
      } else {
        Get.snackbar('Error', 'Failed to register user');
      }
    } catch (e) {
      Get.snackbar('Error', 'An error occurred');
    } finally {
      isLoading(false);
    }



  }

  Future<void> saveUserData({
    required String id,
    required String fullName,
    required String email,
    required String mobile,
    required String token,
  }) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('id', id);
    await prefs.setString('fullName', fullName);
    await prefs.setString('email', email);
    await prefs.setString('mobile', mobile);
    await prefs.setString('token', token);
  }

  Future<Map<String, String?>> getUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return {
      'id': prefs.getString('id'),
      'fullName': prefs.getString('fullName'),
      'email': prefs.getString('email'),
      'mobile': prefs.getString('mobile'),
      'token': prefs.getString('token'),
    };
  }

  Future<void> signUp2() async {
    // if (!formKey.currentState!.validate()) {
    //   return;
    // }

    isLoading.value = true;

    try {
      bool userExists = await checkUserExists(
          emailController.text.trim(), mobileController.text.trim());
      bool numberExistInIndividual =
      await checkIfSameNumberRegisteredInIndividual(
          mobileController.text.trim());

      if (userExists) {
        isLoading.value = false;
        // User already exists, show a snackbar and return
        Get.snackbar(
            "Warning", "User already exists with this email or phone number",
            snackPosition: SnackPosition.BOTTOM);
        isLoading.value = false;
        // return;
      } else if (numberExistInIndividual) {
        Get.snackbar("Warning",
            "This phone number exist as an Individual User already, cannot create a company account with same number",
            snackPosition: SnackPosition.BOTTOM);
      } else {
        verifyPhoneNumber();
      }

      print("myselfid :" + mobileController.text.toString());
      //  print("myselfidemail :" +FirebaseAuth.instance.currentUser!.email!,);
    } catch (e) {
      Get.snackbar("Error".tr, e.toString(),
          backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      isLoading.value = true;
    }
  }

  Future<bool> checkUserExists(String email, String phoneNumber) async {
    var emailQuery = await _firestore
        .collection('RegisteredUsers')
        .where('email', isEqualTo: email)
        .get();
    var phoneQuery = await _firestore
        .collection('RegisteredUsers')
        .where('phoneNumber', isEqualTo: "+91" + phoneNumber)
        .get();

    print("Email Query: " + emailQuery.docs.toString());
    print("Phone Query: " + phoneQuery.docs.toString());

    return emailQuery.docs.isNotEmpty || phoneQuery.docs.isNotEmpty;
  }

  Future<bool> checkIfSameNumberRegisteredInIndividual(
      String phoneNumber) async {
    var phoneQuery = await _firestore
        .collection('Individuals')
        .where('phone_number', isEqualTo: phoneNumber)
        .get();

    print("Phone Query: " + phoneQuery.docs.toString());

    return phoneQuery.docs.isNotEmpty;
  }






  void verifyPhoneNumber() {
    isLoading.value =
    true; // Set loading state to true when verification starts

    FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: "+91" + mobileController.text.toString(),
      verificationCompleted: (PhoneAuthCredential credential) async {
        // Verification completed
        print("myselfid :" + mobileController.text.toString());
        //  isLoading.value = false; // Set loading state to false after verification completes

        try {
          print("myselfid 1:" + mobileController.text.toString());
          await FirebaseAuth.instance.signInWithCredential(credential);
          await linkEmailAndPassword(); // Link email
          //  Get.to(() => RegisterAsCompanyPage());
        } catch (e) {
          isLoading.value = false;
          Get.snackbar(
            "Error",
            "Sign in failed: ${e.toString()}",
            snackPosition: SnackPosition.BOTTOM,
          );
        }
      },
      verificationFailed: (FirebaseAuthException e) {
        print("myselfid : failed");

        // Set loading state to false after verification fails

        String errorMessage;
        switch (e.code) {
          case 'invalid-phone-number':
            errorMessage = "The provided phone number is not valid.";
            break;
          case 'too-many-requests':
            errorMessage = "Too many requests. Please try again later.";
            break;
          case 'quota-exceeded':
            errorMessage = "SMS quota exceeded. Try again later.";
            break;
          default:
            errorMessage = "Verification failed. Please try again.";
            isLoading.value = false;
        }
        isLoading.value = false;
        Get.snackbar(
          "Error",
          errorMessage,
          snackPosition: SnackPosition.BOTTOM,
        );
      },
      codeSent: (String verificationId, int? resendToken) {
        // Code sent to the number
        // Set loading state to false after code is sent
        isLoading.value = false;
        print("my verification id : "+verificationId );
        Get.to(() => OtpScreen(
          verificationId: verificationId,
        ));
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        // Auto retrieval timed out
        isLoading.value = false; // Set loading state to false after timeout
      },
      timeout: Duration(
          seconds: 60), // Adjust timeout duration as per your requirement
    );

    // Your logic for verifying the phone number goes here
    // For now, let's just
  }

  Future<void> linkEmailAndPassword() async {
    User? currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      print("myselfid 1111:" + mobileController.text.toString());
      try {
        AuthCredential credential = EmailAuthProvider.credential(
          email: emailController.text.trim(),
          password: passwordController.text.trim(),
        );
        await currentUser.linkWithCredential(credential);
        print("Email and password linked successfully");

        if (currentUser != null) {
          // Save the user data to Firestore
          await _firestore
              .collection('RegisteredUsers')
              .doc(currentUser.uid)
              .set({
            'uid': currentUser.uid,
            'email': emailController.text.trim(),
            'fullName': currentUser.displayName,
            'phoneNumber': currentUser.phoneNumber,
            'createdAt': Timestamp.now(),
          });

          Get.snackbar("Success", "Registration successful");
        } else {
          Get.snackbar("Error", "User registration failed");
        }
        //   isLoading.value = false;
        // recent coomented
        // Get.offAll(() => RegisterAsCompanyPage(),
        //     arguments: mobileController.text);
        Get.to(() => OnboardingScreen());

        // Navigator.push(
        //     context, MaterialPageRoute(builder: (context) => OnboardingScreen())
        // );

      } catch (e) {
        print("Error linking email and password: $e");
        Get.snackbar("Error".tr, e.toString(),
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.red,
            colorText: Colors.white);
      }
    } else {
      print("No current user found to link email and password");
    }
  }

  void sendOtp() {
    // Add your OTP sending logic here
    print("Sending OTP to ${phoneNumber.value}");




  }





}

class SignUpPage extends StatelessWidget {
  final SignUpController controller = Get.put(SignUpController());




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            // CircleAvatar(
            //   radius: 50,
            //
            //   backgroundColor: Colors.grey[300],
            // ),
            CircleAvatar(
              radius: 50,
           //   backgroundColor: Colors.grey[300],
            //  backgroundImage: NetworkImage('https://example.com/image.jpg'), // Replace with your image URL
              // For assets image, use AssetImage
               backgroundImage: AssetImage('assets/images/logoplace.png'),
            ),

            SizedBox(height: 30),
            Text(
              "Sign Up",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 30),
            // Full Name TextField
            TextField(
              controller: controller.nameController,
              onChanged: (value) {
                controller.fullName.value = value;
              },
              decoration: InputDecoration(
                labelText: 'Full Name*',
                hintText: 'User Name',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 15),
            // Email Id TextField
            TextField(
              onChanged: (value) {
                controller.email.value = value;
              },
              controller: controller.emailController,
              decoration: InputDecoration(
                labelText: 'Email Id (optional)',
                hintText: 'user@gmail.com',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 15),
            // Phone Number TextField
            TextField(
              onChanged: (value) {
                controller.phoneNumber.value = value;
              },
              controller: controller.mobileController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: 'Phone Number*',
                hintText: '+91 9876XXXXXX',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 20),
            // TextField(
            //   onChanged: (value) {
            //     controller.phoneNumber.value = value;
            //   },
            //   controller: controller.passwordController,
            //   keyboardType: TextInputType.phone,
            //   decoration: InputDecoration(
            //     labelText: 'Enter Password*',
            //     hintText: '',
            //     border: OutlineInputBorder(
            //       borderRadius: BorderRadius.circular(12),
            //     ),
            //   ),
            // ),
            // SizedBox(height: 20),

            // Send OTP Button
            // ElevatedButton(
            //
            //   onPressed: () {
            //     controller.sendOtp();
            //   },
            //   style: ElevatedButton.styleFrom(
            //     padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(30),
            //     ),
            //     backgroundColor: Colors.grey, // Background color
            //   ),
            //   child: Text(
            //     "Send OTP",
            //     style: TextStyle(fontSize: 18, color: Colors.white),
            //   ),
            // ),

            // for disable button

    /*    SizedBox(
          width: double.infinity, // Makes button width as large as possible
          child:
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 1.0,
                colors: [
                  Color(0xFF5278C7).withOpacity(0.4), // #5278C7 with 80% opacity
                  Color(0xFF233F78).withOpacity(0.4), // #233F78 with 80% opacity
                ],
              ),
              borderRadius: BorderRadius.circular(30), // Same as button radius
            ),
            child: ElevatedButton(
              onPressed: () {
                controller.sendOtp();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OtpScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 13), // Adjust padding
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                backgroundColor: Colors.transparent, // Set to transparent so gradient shows
                shadowColor: Colors.transparent, // Remove shadow if not needed
              ),
              child: Text(
                "Send OTP",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white.withOpacity(0.6), // 60% opacity for text
                ),
              ),
            ),
          ),



        ),*/

          SizedBox(
              width: double.infinity, // Makes button width as large as possible
              child:

              Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 3.0,
                    colors: [
                      Color(0xFF5278C7), // #5278C7
                      Color(0xFF233F78), // #233F78
                    ],
                  ),
                  borderRadius: BorderRadius.circular(30), // Same as button radius
                ),
                child: ElevatedButton(
                  onPressed: () {
                  //  controller.sendOtp();
                    controller.isLoading.value = true;
                    String sixDigitNumber = controller.  generateRandom6DigitNumber();
                    controller.signUp(controller.nameController.text,controller.emailController.text,controller.mobileController.text,sixDigitNumber);
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(builder: (context) => OtpScreen(verificationId: "verificationId",)),
                    // );
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 13), // Adjust padding
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    backgroundColor: Colors.transparent, // Set to transparent so gradient shows
                    shadowColor: Colors.transparent, // Remove shadow if not needed
                  ),
                  child:

                  Obx(() {
                    return controller.isLoading.value
                        ? Center(
                      child: CircularProgressIndicator(
                        strokeWidth:
                        2, // Set the strokeWidth to make the indicator smaller
                      ),
                    )
                        : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Center(
                          child: Text(
                            "Send OTP",
                            style: TextStyle(fontSize: 18, color: Colors.white),textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    );
                  }),

                ),
              ),


              /*   ElevatedButton(
                onPressed: () {
                  controller.sendOtp();
                //  Get.to(OtpScreen);
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => OtpScreen()));
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 13), // Adjust padding
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  backgroundColor: Colors.grey, // Background color
                ),
                child: Text(
                  "Send OTP",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),*/
            ),

            SizedBox(height: 20),
            // Already have account? Login
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Already have an account?",
                  style: TextStyle(fontSize: 16),
                ),
                TextButton(
                  onPressed: () {
                    // Navigate to login page
                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignInPage()));
                  },
                  child: Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFF233F78),
                    ),
                  ),
                )
              ],
            ),
            SizedBox(height: 20),
            // Terms & Conditions
            Text(
              "By signing up, you accept the Splitwise Term & Conditions.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14),
            ),



/*      RichText(
      textAlign: TextAlign.center,
        text: TextSpan(
          text: 'By signing up, you accept the Splitwise ',
          style: TextStyle(fontSize: 14, color: Colors.black), // Regular text style
          children: [
            TextSpan(
              text: 'Terms & Conditions.', // Underlined part
              style: TextStyle(
                fontSize: 14,
                color: Colors.blue, // Color of the underlined text
                decoration: TextDecoration.underline, // Underline the text
              ),
              recognizer: TapGestureRecognizer()
                ..onTap = () async {
                 // const url = 'https://www.splitwise.com/terms'; // Replace with your URL
                  launchUrl(Uri.parse(
                      'https://socialbay.co.in/privacy-policy/'));
                },
            ),
          ],
        ),
      ),*/

      ],
        ),
      ),
    );
  }
}
