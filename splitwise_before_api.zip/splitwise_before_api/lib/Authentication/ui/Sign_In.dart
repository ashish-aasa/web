import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:splitwise/Authentication/model/sign_up_response_model.dart';
import 'package:splitwise/Authentication/ui/Sign_up.dart';
import 'package:splitwise/Authentication/ui/otp_screen.dart';
import 'package:splitwise/Authentication/ui/otp_screen_login.dart';
import 'package:splitwise/WelcomeScreen/ui/welcome_screen.dart';
import 'package:http/http.dart' as http;
import 'dart:math';

class SignInController extends GetxController {
  var fullName = ''.obs;
  var email = ''.obs;
  var phoneNumber = ''.obs;

  var isLoading = false.obs;
  void sendOtp() {
    // Add your OTP sending logic here
    print("Sending OTP to ${phoneNumber.value}");
  }

  Future<void> signIn(String mobile) async {
    isLoading(true);
    final url = Uri.parse('https://expense-sharing.in1.apiqcloud.com/api/auth/sign-in');

    // Create the request body
    final body = jsonEncode({

      "mobno": "91"+mobile,

    });

    print("testingis : " + body.toString());

    try {
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: body,
      );

      print("testingisaa : " + response.body.toString());

      if (response.statusCode == 200) {
        // Parse the response body into a model
        SignupResponseModel signupResponse = signupResponseModelFromJson(response.body);

        Get.to(() => OtpScreenLogin(
          verificationId: "verificationId",
        ));

        // Save data in SharedPreferences
        await saveUserData(
          id: signupResponse.data?.id ?? '',
          fullName: signupResponse.data?.fullName ?? '',
          email: signupResponse.data?.email ?? '',
          mobile: signupResponse.data?.mobile ?? '',
          token: signupResponse.data?.token ?? '',
        );

        Get.snackbar('Success', 'User Logged in successfully');
      } else {
        Get.snackbar('Error', 'Failed to login user');
      }
    } catch (e) {
      Get.snackbar('Error', 'An error occurred' +e.toString());
    } finally {
      isLoading(false);
    }



  }

  Future<void> saveUserData({
    required String id,
    required String fullName,
    required String email,
    required String mobile,
    required String token,
  }) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('id', id);
    await prefs.setString('fullName', fullName);
    await prefs.setString('email', email);
    await prefs.setString('mobile', mobile);
    await prefs.setString('token', token);
  }

  Future<Map<String, String?>> getUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return {
      'id': prefs.getString('id'),
      'fullName': prefs.getString('fullName'),
      'email': prefs.getString('email'),
      'mobile': prefs.getString('mobile'),
      'token': prefs.getString('token'),
    };
  }
  void verifyPhoneNumber() async {

    print("nois :" + phoneNumber.value.trim());
    isLoading.value =
    true; // Set loading state to true when verification starts
    FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: "+91".tr + phoneNumber.value.trim(),
      verificationCompleted: (PhoneAuthCredential credential) async {
        // Verification completed
        isLoading.value =
        false; // Set loading state to false after verification completes
        await FirebaseAuth.instance.signInWithCredential(credential);
        Get.to(() => OnboardingScreen());
      },
      verificationFailed: (FirebaseAuthException e) {
        // Verification failed
        isLoading.value =
        false; // Set loading state to false after verification fails

        String errorMessage;
        switch (e.code) {
          case 'invalid-phone-number':
            errorMessage = "The provided phone number is not valid.";
            break;
          case 'too-many-requests':
            errorMessage = "Too many requests. Please try again later.";
            break;
          case 'quota-exceeded':
            errorMessage = "SMS quota exceeded. Try again later.";
            break;
          default:
            errorMessage = "Verification failed. Please try again.";
            isLoading.value = false;
        }
        isLoading.value = false;
        Get.snackbar(
          "Error",
          errorMessage,
          snackPosition: SnackPosition.BOTTOM,
        );
      },
      codeSent: (String verificationId, int? resendToken) {
        // Code sent to the number
        isLoading.value =
        false; // Set loading state to false after code is sent
        Get.to(
                () => OtpScreenLogin(
              verificationId: verificationId,
            ),
            transition: Transition.leftToRightWithFade);
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        // Auto retrieval timed out
        isLoading.value = false; // Set loading state to false after timeout
      },
      timeout: Duration(
          seconds: 60), // Adjust timeout duration as per your requirement
    );

    // Your logic for verifying the phone number goes here
    // For now, let's just
  }

}

class SignInPage extends StatefulWidget {
 //  SignInPage({super.key});

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {

  final SignInController controller = Get.put(SignInController());
  late double width;
  late double height;

  @override
  void initState() {
    super.initState();
   // _showLanguagePopup(context);
  }



  void _showLanguagePopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
          ),
          title: Center(
            child: Text(
              'Select Language',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Divider(height:2 ,color: Colors.grey.shade300, ),
              _buildLanguageOption(context, 'English'),

              Divider(height:2 ,color: Colors.grey.shade300, ),
              _buildLanguageOption(context, 'Hindi'),
              Divider(height:2 ,color: Colors.grey.shade300, ),
              _buildLanguageOption(context, 'Spanish'),
              Divider(height:2 ,color: Colors.grey.shade300, ),
              _buildLanguageOption(context, 'French'),
              Divider(height:2 ,color: Colors.grey.shade300, ),
              _buildLanguageOption(context, 'Portuguese'),
              Divider(height:2 ,color: Colors.grey.shade300, ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLanguageOption(BuildContext context, String language) {
    return ListTile(
      title: Center(child: Text(language)),
      onTap: () {
        Navigator.pop(context); // Dismiss the modal
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Selected: $language')),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
         // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height:height *.1,),
            GestureDetector(onTap: (){
              Navigator.push(
                  context,
                  //  MaterialPageRoute(builder: (context) => HomeScreen()));
                  MaterialPageRoute(builder: (context) => OnboardingScreen()));
            },
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.grey[300],
              ),
            ),
            SizedBox(height: 30),
            InkWell(onTap: (){
              _showLanguagePopup(context);
            },
              child: Text(
                "Sign In",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 30),
            // Full Name TextField

            SizedBox(height: 15),
            // Email Id TextField

            SizedBox(height: 15),
            // Phone Number TextField
            TextField(
              onChanged: (value) {
                controller.phoneNumber.value = value;
              },
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: 'Phone Number*',
                hintText: '+91 9876XXXXXX',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 30),
            // Send OTP Button
            // ElevatedButton(
            //
            //   onPressed: () {
            //     controller.sendOtp();
            //   },
            //   style: ElevatedButton.styleFrom(
            //     padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(30),
            //     ),
            //     backgroundColor: Colors.grey, // Background color
            //   ),
            //   child: Text(
            //     "Send OTP",
            //     style: TextStyle(fontSize: 18, color: Colors.white),
            //   ),
            // ),

            SizedBox(
              width: double.infinity, // Makes button width as large as possible
              child: ElevatedButton(
                onPressed: () {
                 // controller.sendOtp();
                //  controller.verifyPhoneNumber();
                  controller.signIn(controller.phoneNumber.value.toString());
                  //  Get.to(OtpScreen);
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(builder: (context) => OtpScreen(verificationId: "verificationId",)));
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 13), // Adjust padding
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  backgroundColor: Colors.grey, // Background color
                ),
                child: Text(
                  "Send OTP",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ),

            SizedBox(height: 20),
            // Already have account? Login
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Don't have an account?",
                  style: TextStyle(fontSize: 16),
                ),
                TextButton(
                  onPressed: () {
                    // Navigate to login page
                    Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignUpPage()));
                  },
                  child: Text(
                    "Sign Up",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue,
                    ),
                  ),
                )
              ],
            ),
            SizedBox(height: 20),
            // Terms & Conditions

          ],
        ),
      ),
    );
  }
}
