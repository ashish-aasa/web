import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:splitwise/Authentication/ui/Sign_up.dart';
import 'package:splitwise/WelcomeScreen/ui/Welcome_page.dart';
import 'package:splitwise/WelcomeScreen/ui/welcome_screen.dart';
import 'package:splitwise/helper/Otp_widget.dart';


class OtpController extends GetxController {
  var otp = List<String>.filled(6, '').obs;

  RxInt timeRemaining = 60.obs;
  String code = '';
  Timer? _timer;

  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (timer.tick == 61) {
        timer.cancel();
      } else {
        timeRemaining.value = timeRemaining.value - 1;
        update();
      }
    });
  }

  void updateOtp(int index, String value) {
    otp[index] = value;
  }

  String get otpValue => otp.join();



  @override
  void onInit() {
    startTimer();
    super.onInit();
  }

  @override
  @override
  void onClose() {
    super.onClose();
    _timer?.cancel();
    timeRemaining.value = 0;
  }
}

class OtpScreen extends StatelessWidget {

  final String verificationId;

  OtpScreen({
    super.key,
    required this.verificationId,
  });
  final OtpController otpController = Get.put(OtpController());

  late double width;
  late double height;


  void _onOTPCompleted11(String otp) async {
    print("OTP Entered: $otp");

  }

  Future<void> _onOTPCompleted1(String otp) async {
    print("OTP Entered: $otp");
    //print("OTP Entered: ");
    // Handle OTP submission here
    try {
      PhoneAuthCredential credential =
      PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: otp,
      );

      await FirebaseAuth.instance
          .signInWithCredential(credential);

      await Get.find<SignUpController>()
          .linkEmailAndPassword();

      // Get.to(() => RegisterAsCompanyPage());
    } catch (e) {
      Get.snackbar("Error".tr, e.toString(),
          backgroundColor: Colors.red, colorText: Colors.white);
    }

  }

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
          
          
            children: [
          
          
             SizedBox(height:height *.2,),
              Text(
                'OTP',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Please Enter The OTP Sent On Your Phone Number',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 30),
          
              OTPWidget(
                length: 6, // Length of the OTP
                onCompleted: _onOTPCompleted1,
              ),
          
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                /*  Container(
                    margin: const EdgeInsets.only(right: 16.0), // Add margin to the right
                    child: GestureDetector(
                      onTap: () {
                        // Resend OTP logic here
                        Get.snackbar('OTP', 'Resend OTP clicked!');
                      },
                      child: Text(
                        'Resend OTP',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[700],
                          decoration: TextDecoration.underline, // Underline the text
                        ),
                      ),
                    ),
                  ),*/
          
                  Obx(() {
                    return otpController.timeRemaining.value == 0
                        ?
                    GestureDetector(
                      onTap: () {
                        Get.find<OtpController>()
                            .updateOtp(1,"");
                        otpController.timeRemaining.value = 60;
                        otpController.startTimer();
                      },
                      child: Text(
                        'Resend OTP',
                        style: TextStyle(
                          fontSize: 16,
                           fontWeight: FontWeight.bold,
                        //  color: Colors.grey[700],
                          color:  Color(0xFF233F78),
                          decoration: TextDecoration.underline, // Underline the text
                        ),
                      ),
                    ):
          
          
                         Text(
                        "Resend in" +
                            ' ' +
                            '${otpController.timeRemaining.value == 60 ? ' 01:00' : '00:' + '${'${otpController.timeRemaining.value}'.padLeft(2, '0')}'}',
                        style: TextStyle(
                          fontSize: 17,
                        ));
                  }),
                ],
              ),
          
              SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
          
                child: Container(
          
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: 3.0,
                      colors: [
                        Color(0xFF5278C7), // #5278C7
                        Color(0xFF233F78), // #233F78
                      ],
                    ),
                    borderRadius: BorderRadius.circular(30), // Same as button radius
                  ),
                  child: ElevatedButton(
          
          
                    onPressed: () {
                      // Confirm OTP logic here
                      String enteredOtp = otpController.otpValue;
                  //    Get.snackbar('OTP', 'Entered OTP: $enteredOtp');
                   //   _onOTPCompleted1;

                      Navigator.push(
                          context, MaterialPageRoute(builder: (context) => OnboardingScreen())
                      );

                     //
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 13), // Adjust padding
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      backgroundColor: Colors.transparent, // Set to transparent so gradient shows
                      shadowColor: Colors.transparent, // Remove shadow if not needed
                    ),
                    child: Text(
                      'Confirm',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
