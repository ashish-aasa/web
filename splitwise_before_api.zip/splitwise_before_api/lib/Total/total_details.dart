import 'package:flutter/material.dart';

class FinancialSummaryScreen extends StatefulWidget {
  @override
  _FinancialSummaryScreenState createState() => _FinancialSummaryScreenState();
}

class _FinancialSummaryScreenState extends State<FinancialSummaryScreen> {
  String dropdownValue = 'All Time'; // Default value for the dropdown

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Financial Summary', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.black), // To set the back button color
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dropdown button
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 5,
                  ),
                ],
              ),
              child: DropdownButton<String>(
                value: dropdownValue,
                isExpanded: true,
                underline: SizedBox(), // Remove default underline
                icon: Icon(Icons.arrow_drop_down),
                items: <String>['This month', 'Last month', 'All Time']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    dropdownValue = newValue!;
                  });
                },
              ),
            ),
            SizedBox(height: 20),
            // Financial details
            buildFinancialDetail('Total Group Spending', '₹56000'),
            buildFinancialDetail('Total You Paid', '₹20000'),
            buildFinancialDetail('Your Total Share', '₹26000'),
            buildFinancialDetail('Payment Made', '₹0'),
            buildFinancialDetail('Payment Received', '₹0'),
            buildFinancialDetail('Total Change in Balance', '₹0'),
          ],
        ),
      ),
    );
  }

  // Helper method to create each financial detail row
  Widget buildFinancialDetail(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 16, color: Colors.grey[700]),
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}