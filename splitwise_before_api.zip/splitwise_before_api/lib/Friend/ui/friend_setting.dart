import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

class FriendSettingsController extends GetxController {
  var friendName = "Friend Name".obs;
  var phoneNumber = "98XXXXXXXX".obs;
  var sharedGroups = [].obs;
  var isBlocked = false.obs;
  var isRemoved = false.obs;
}

class FriendSettingsScreen extends StatelessWidget {
  final FriendSettingsController controller = Get.put(FriendSettingsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Friend Settings'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Friend Profile Section
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                 // color: Colors.grey[200],
                  color: Colors.white,
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.grey[300],
                      child: Icon(Icons.person, size: 40, color: Colors.grey),
                    ),
                    SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Obx(() => Text(
                          controller.friendName.value,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        )),
                        Obx(() => Text(
                          controller.phoneNumber.value,
                          style: TextStyle(color: Colors.grey),
                        )),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),

              // Shared Groups Section
              Text("Shared Groups", style: TextStyle(fontSize: 16)),
              Obx(() {
                if (controller.sharedGroups.isEmpty) {
             //   if (false) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Text("You both are not sharing any group.",
                        style: TextStyle(color: Colors.grey)),
                  );
                } else {
                  return Column(
                    children: controller.sharedGroups.map((group) {
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey[300],
                          child: Icon(Icons.group, color: Colors.grey),
                        ),
                        title: Text(group),
                      );
                    }).toList(),
                  );
                }
              }),
              SizedBox(height: 16),

              // Manage Friend Section
              Text("Manage Friend", style: TextStyle(fontSize: 16)),
              SizedBox(height: 18),

              Column(
                children: [
                  // First Checkbox Row (Remove From Friend List)
                  Row(
                    children: [

                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [

                          Image.asset("assets/images/deletebox.png"),
                          Text(""),
                        ],
                      ),
                      // Obx(() => Checkbox(
                      //   value: controller.isRemoved.value,
                      //   onChanged: (value) {
                      //     controller.isRemoved.value = value!;
                      //   },
                      // )),
                      SizedBox(width: 15), // Spacing between checkbox and text
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Remove From Friend List',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 4), // Spacing between title and subtitle
                          Text(
                            'Remove this user from your friends list.',
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 16), // Spacing between rows

                  // Second Checkbox Row (Block User)
                  Row(
                    children: [
                      // Obx(() => Checkbox(
                      //   value: controller.isBlocked.value,
                      //   onChanged: (value) {
                      //     controller.isBlocked.value = value!;
                      //   },
                      // )),
                     Column(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       children: [
                         Image.asset("assets/images/blockicon.png"),
                       //  Text(""),
                       ],
                     ),
                      SizedBox(width: 15),
                      Text(
                        'Block User',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),



                    ],
                  ),

                  Row(
                    children: [
                  //    Text("       "),
                      SizedBox(width:MediaQuery.of(context).size.width *.1,),
                      Flexible( // Ensures text does not overflow
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            SizedBox(width: 30),
                            Text(
                              'Removing this user will take them off your friend list, hide any shared groups, and block future notifications and expenses from them.',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              )

              /*    ListTile(
                leading: Obx(() => Checkbox(
                  value: controller.isRemoved.value,
                  onChanged: (value) {
                    controller.isRemoved.value = value!;
                  },
                )),
                title: Text('Remove From Friend List'),
                subtitle: Text(
                    'Remove this user from your friends list.'),
              ),
              ListTile(
                leading: Obx(() => Checkbox(
                  value: controller.isBlocked.value,
                  onChanged: (value) {
                    controller.isBlocked.value = value!;
                  },
                )),
                title: Text('Block User'),
                subtitle: Text(
                    'Removing this user will take them off your friend list, hide any shared groups, and block future notifications and expenses from them.'),
              ),*/
            ],
          ),
        ),
      ),
    );
  }
}

