import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:qr_flutter/qr_flutter.dart';

import 'package:splitwise/Expenses/ui/expense_details.dart';
import 'package:splitwise/Friend/ui/friend_setting.dart';
import 'package:splitwise/utils/colors.dart';

class FriendDetailsController extends GetxController {
  var friendName = 'Friend Name'.obs;
  var amountToBePaid = '₹2000'.obs;
  var lastPaymentDate = '06 August 2024'.obs;
  var youPaidAmount = '₹20,000'.obs;
  var friendPaidAmount = '₹15,000'.obs;
}

class FriendDetailsScreen extends StatelessWidget {
  final FriendDetailsController controller = Get.put(FriendDetailsController());

  late double width;
  late double height;

  void showUPIDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.all(16),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              // Friend Name
              Text(
                'Friend Name',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),

              // UPI Id Section
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      readOnly: true,
                      decoration: InputDecoration(
                        labelText: 'UPI Id',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        suffixIcon: Icon(Icons.copy),
                      ),
                      controller: TextEditingController(text: 'upi@okaxis'),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),

              // QR Code Widget

            Container(
              child:QrImageView(
                data: '8577844040@ybl',
                version: QrVersions.auto,
                size: 200.0,
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.all(25.0),
              ) ,
            ),

            ],
          ),
        );
      },
    );
  }
 /* void showUPIDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.all(16),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Friend Name
              Text(
                'Friend Name',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),

              // UPI Id Section
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      readOnly: true,
                      decoration: InputDecoration(
                        labelText: 'UPI Id',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        suffixIcon: Icon(Icons.copy),
                      ),
                      controller: TextEditingController(text: 'upi@okaxis'),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),

              // QR Code
              // QrImage(
              //   data: "upi@okaxis",
              //   version: QrVersions.auto,
              //   size: 200.0,
              // ),
            ],
          ),
        );
      },
    );
  }*/

  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Get.back(),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.settings, color: Colors.black),
            onPressed: () {
              // Handle settings
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => FriendSettingsScreen())
              );

            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Friend Card with avatar and amount owed

            Container(
              width:width ,
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
                // gradient: RadialGradient(
                //   center: Alignment.center,
                //   radius: 3.0,
                //   colors: [
                //     cardColor2, // #5278C7
                //     cardColor, // #233F78
                //   ],
                // ),

                // linear
                // gradient: LinearGradient(
                //   colors: [cardColor, cardColor2],
                //   begin: Alignment.topLeft,
                //   end: Alignment.bottomRight,
                // ),
                // leniar with stop
                gradient: LinearGradient(
                  colors: [cardColor, cardColor2,cardColor2],
                  stops: [0.001, 0.5, 0.8], // Stops for each color
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),

              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.grey[300],
                    child: Icon(Icons.person, size: 60, color: Colors.grey),
                  ),
                  SizedBox(height: 10),
                  Obx(() => Text(
                    controller.friendName.value,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  )),
                  SizedBox(height: 5),
                  Obx(() => Text(
                    'You need to be paid ${controller.amountToBePaid.value}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                    ),
                  )),
                ],
              ),
            ),
            SizedBox(height: 20),

            // Payment History Section
            Text(
              "06 Aug 2024",
              style: TextStyle(color: Colors.grey),textAlign: TextAlign.left,
            ),
            SizedBox(height: 10),
            PaymentDetailsWidget(),
            SizedBox(height: 10),
            Text(
              "06 Aug 2024",
              style: TextStyle(color: Colors.grey),textAlign: TextAlign.left,
            ),
            SizedBox(height: 10),
            TripPaymentItem(),
            Spacer(),

            // Settle Up and Payment ID buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      // Handle Settle Up
                    },
                    style: ElevatedButton.styleFrom(
                     // backgroundColor: Colors.grey[700],
                    // backgroundColor: Color(0xFF5278C7),
                      backgroundColor: Color(0xFF233f78),
                      padding: EdgeInsets.symmetric(vertical: 13),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Text(
                      'Settle Up',
                      style: TextStyle(fontSize: 16,color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      // Handle Payment ID
                      showUPIDialog(context);

                    },
                    style: OutlinedButton.styleFrom(
                     // side: BorderSide(color: Colors.grey[700]!),
                      side: BorderSide(color:Color(0xFF233f78),),
                      padding: EdgeInsets.symmetric(vertical: 13),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Text(
                      'Payment Id',
                      style: TextStyle(fontSize: 16, color: Color(0xFF233f78),),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}


class PaymentDetailsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Friend Name
            Text(
              'Friend Name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.grey[600],
              ),
            ),
            // Arrow and amount
            Column(
              children: [
                Text(
                  '₹ 2,000',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                SizedBox(width: 10),
                Image.asset(
                  'assets/images/arrowblk.png',

                  width: 100,
                  height: 15,
                ),
              ],
            ),
            // You
            Text(
              'You',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }
}




class TripPaymentItem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Colors.white,
        ),
        padding: EdgeInsets.all(10),
        child: GestureDetector(onTap: (){
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => ExpenseDetailsScreen())
          );

        },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Icon and Goa Trip information
              Row(
                children: [
                  // Placeholder for image/icon
                  // Container(
                  //   width: 40,
                  //   height: 40,
                  //   decoration: BoxDecoration(
                  //     color: Colors.grey[300],
                  //     borderRadius: BorderRadius.circular(10),
                  //   ),
                  // ),

                  Container(
                      width: 40,
                      height: 40,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child:
                        Image.asset("assets/images/grp1.png")
                      // Image.network(
                      //   'https://your-image-url.com', // replace with your image URL
                      //   width: 60,
                      //   height: 60,
                      //   fit: BoxFit.cover,
                      // ),
                    ),
                  ),
                  SizedBox(width: 10),
                  // Goa Trip and Paid Info
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Goa Trip',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'Your paid ₹20000',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              // You Lent Info
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'You lent',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    '₹15000',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}




