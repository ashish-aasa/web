import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:splitwise/Friend/ui/friend_details.dart';
import 'package:splitwise/utils/colors.dart';

class ContactController extends GetxController {
  var contacts = List<Contact>.empty(growable: true).obs;
  var selectedContacts = List<Contact>.empty(growable: true).obs;
  var searchQuery = ''.obs;
  RxBool isLoading = false.obs;
  var isPermissionGranted = false.obs;

  @override
  void onInit() {
    super.onInit();
   // requestContactPermission();
    loadSelectedContacts();
  }

  // Request permission to access contacts
  void requestContactPermission() async {
    PermissionStatus permission = await Permission.contacts.status;
    if (permission != PermissionStatus.granted) {
      permission = await Permission.contacts.request();
    }

    if (permission == PermissionStatus.granted) {
      isPermissionGranted.value = true;
      loadContacts();

    } else {
      Get.snackbar('Permission Denied', 'Contact access is required to load contacts.');
    }
  }

  // Load contacts from the phone contact list
  void loadContacts() async {
    isLoading.value = true;
    Iterable<Contact> phoneContacts = await ContactsService.getContacts();
    contacts.assignAll(phoneContacts.toList());
    isLoading.value = false;
  }

  // Select/Deselect contact using radio buttons
  void selectContact(Contact contact) {
    if (selectedContacts.contains(contact)) {
      selectedContacts.remove(contact);
    } else {
      selectedContacts.add(contact);
    }
  }

  void saveSelectedContacts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> selectedContactsJson = selectedContacts.map((contact) => jsonEncode(contact.toMap())).toList();
    prefs.setStringList('selectedContacts', selectedContactsJson);
  }

  void loadSelectedContacts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? selectedContactsJson = prefs.getStringList('selectedContacts');
    if (selectedContactsJson != null) {
      selectedContacts.assignAll(
        selectedContactsJson.map((contact) => Contact.fromMap(jsonDecode(contact))).toList(),
      );
    }
  }

  // Filter contacts based on search query
  List<Contact> get filteredContacts => searchQuery.isEmpty
      ? contacts
      : contacts
      .where((c) => c.displayName != null && c.displayName!.toLowerCase().contains(searchQuery.value.toLowerCase()))
      .toList();
}

class AddFriendScreen extends StatelessWidget {
  final ContactController controller = Get.put(ContactController());
  late double width;
  late double height;


  @override
  Widget build(BuildContext context) {
    width=   MediaQuery.of(context).size.width ;
    height = MediaQuery.of(context).size.height ;
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Friend'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body:
      Obx(() {
        return controller.isPermissionGranted.value
            ? Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(

            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Search Bar

              TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Search...',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                onChanged: (value) => controller.searchQuery.value = value,
              ),
              SizedBox(height: 16),
              Text('From your contacts', style: TextStyle(fontSize: 17,color: Colors.grey),textAlign: TextAlign.left,),
              SizedBox(height: 10),
              Expanded(
                child: Obx(() {
                  return controller.isLoading.value
                      ? Center(child: CircularProgressIndicator()):
                  ListView.builder(
                    itemCount: controller.filteredContacts.length,
                    itemBuilder: (context, index) {
                      Contact contact = controller.filteredContacts[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.grey[300],
                          child: contact.avatar != null
                          //    ? Image.file(contact.avatar!)
                              ? Text("")
                              : Text(
                            contact.displayName != null ? contact.displayName![0] : '',
                            style: TextStyle(
                              color: Colors.pinkAccent,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        title: Text(contact.displayName ?? 'Unknown'),
                        subtitle: Text(contact.phones!.isNotEmpty ? contact.phones!.first.value! : 'No Phone Number'),
                        trailing: Obx(() {
                          return Radio(
                            value: contact,
                            groupValue: controller.selectedContacts.contains(contact) ? contact : null,
                            onChanged: (value) {
                              controller.selectContact(contact);
                            },
                          );
                        }),
                      );
                    },
                  );
                }),
              ),
              SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[800], // Dark button color
                    padding: EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: () {
                    controller.saveSelectedContacts();
                    Get.to(SelectedContactsScreen());
                  },
                  child: Text('Continue', style: TextStyle(fontSize: 16,color: Colors.white)),
                ),
              ),
            ],
          ),
        )
            : Padding(
          padding: const EdgeInsets.symmetric(horizontal: 34.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height:height *.2,),

              CircleAvatar(
                child: Image.asset("assets/images/allowcontact.png"),
                radius: 60,
                backgroundColor: Colors.grey[300],
              ),

              SizedBox(height: 30),
              // Permission request text
              Text(
                'Allow Splitwise to access your contacts to add friends.'+controller.isPermissionGranted.value.toString(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 32),
              // Allow contact access button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
               //     backgroundColor: Colors.grey[800], // Dark button color
                    backgroundColor: uitext, // Dark button color
                    padding: EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () {
                    controller.requestContactPermission();
                  },
                  child: Text(
                    'Allow contact access',
                    style: TextStyle(fontSize: 16,color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        );
      }),



    );
  }
}

class SelectedContactsScreen extends StatelessWidget {
  final ContactController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Selected Friends'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Obx(() {
          return GestureDetector(onTap: (){
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => FriendDetailsScreen())
            );

          },
            child: ListView.builder(
              itemCount: controller.selectedContacts.length,
              itemBuilder: (context, index) {
                Contact contact = controller.selectedContacts[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.grey[300],
                    child: contact.avatar != null
                       // ? Image.file()
                        ? Text("")
                        : Text(
                      contact.displayName != null ? contact.displayName![0] : '',
                      style: TextStyle(
                        color: Colors.pinkAccent,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  title: Text(contact.displayName ?? 'Unknown'),
                  subtitle: Text(contact.phones!.isNotEmpty ? contact.phones!.first.value! : 'No Phone Number'),
                );
              },
            ),
          );
        }),
      ),
    );
  }
}








// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// class ContactPermissionController extends GetxController {
//   var isPermissionGranted = false.obs;
//
//   void requestContactAccess() {
//     // Simulate permission grant
//     isPermissionGranted.value = true;
//   }
// }
//
// class AddFriendScreen extends StatelessWidget {
//   final ContactPermissionController controller =
//   Get.put(ContactPermissionController());
//
//   late double width;
//   late double height;
//
//
//   @override
//   Widget build(BuildContext context) {
//     width=   MediaQuery.of(context).size.width ;
//     height = MediaQuery.of(context).size.height ;
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Add Friend'),
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back),
//           onPressed: () {
//             Get.back(); // Navigate back to the previous screen
//           },
//         ),
//         elevation: 0,
//         backgroundColor: Colors.white,
//         iconTheme: IconThemeData(color: Colors.black),
//       ),
//       body: Obx(() {
//         return controller.isPermissionGranted.value
//             ? Center(
//           child: Text('Contacts permission granted!'),
//         )
//             : Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 34.0),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               SizedBox(height:height *.2,),
//
//               CircleAvatar(
//                 radius: 60,
//                 backgroundColor: Colors.grey[300],
//               ),
//
//               SizedBox(height: 24),
//               // Permission request text
//               Text(
//                 'Allow Splitwise to access your contacts to add friends.',
//                 textAlign: TextAlign.center,
//                 style: TextStyle(
//                   color: Colors.grey,
//                   fontSize: 16,
//                 ),
//               ),
//               SizedBox(height: 32),
//               // Allow contact access button
//               SizedBox(
//                 width: double.infinity,
//                 child: ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.grey[800], // Dark button color
//                     padding: EdgeInsets.symmetric(vertical: 13),
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(14),
//                     ),
//                   ),
//                   onPressed: () {
//                     controller.requestContactAccess();
//                   },
//                   child: Text(
//                     'Allow contact access',
//                     style: TextStyle(fontSize: 16,color: Colors.white),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         );
//       }),
//     );
//   }
// }
//

