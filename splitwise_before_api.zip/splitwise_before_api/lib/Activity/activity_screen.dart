import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ActivityController extends GetxController {
  // Simulating activity data
  var activities = [
    {
      'date': 'Today',
      'data': [
        {
          'time': '10:12 am',
          'description': 'You created the group',
          'group': 'Group Name',
          'type': 'group_creation',
        },
        {
          'time': '10:12 am',
          'description': 'You added a payment from',
          'user1': 'User1',
          'user2': 'User2',
          'group': 'Group Name',
          'type': 'payment',
        },
      ]
    },
    {
      'date': 'Yesterday',
      'data': [
        {
          'time': '10:12 am',
          'description': 'You created the group',
          'group': 'Group Name',
          'type': 'group_creation',
        },
        {
          'time': '10:12 am',
          'description': 'You added a payment from',
          'user1': 'User1',
          'user2': 'User2',
          'group': 'Group Name',
          'type': 'payment',
        },
      ]
    },
    {
      'date': '30 July',
      'data': [
        {
          'time': '10:12 am',
          'description': 'You created the group',
          'group': 'Group Name',
          'type': 'group_creation',
        },
      ]
    }
  ].obs;
}

class ActivityScreen extends StatelessWidget {
  final ActivityController controller = Get.put(ActivityController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Activity'),
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.black,
        ),
      ),
      body: Obx(() {
        return ListView.builder(
          itemCount: controller.activities.length,
          itemBuilder: (context, index) {
            var section = controller.activities[index];
            return
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Date Section Header
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                    child: Text(
                      section['date'] as String, // Explicit type cast
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  // Activity Items
                  ...List.generate((section['data'] as List).length, (itemIndex) {
                    var activity = (section['data'] as List)[itemIndex] as Map<String, dynamic>; // Explicitly casting to List and Map
                    return _buildActivityItem(activity);
                  }),
                ],
              );

          },
        );
      }),
    );
  }

  Widget _buildActivityItem(Map<String, dynamic> activity) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Avatar or Icon
          // CircleAvatar(
          //   backgroundImage: AssetImage('assets/images/.png'), // Placeholder image
          //   radius: 18,
          // ),

          Column(
            children: [
              CircleAvatar(
                backgroundColor: Colors.blue.shade100,
                radius: 18,
                child: Icon(
                  Icons.person,
                  color: Colors.blue,
                  size: 32,
                ),
              ),

              SizedBox(height: 5,),
              Text(
                activity['time'],
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              )
            ],
          ),
          SizedBox(width: 10),
          // Activity Details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildActivityDescription(activity),
                SizedBox(height: 4),
                // Text(
                //   activity['time'],
                //   style: TextStyle(
                //     fontSize: 12,
                //     color: Colors.grey,
                //   ),
                // )
              ],
            ),
          ),
          // Icon (for payments)
          if (activity['type'] == 'payment')
            Icon(Icons.currency_rupee, color: Color(0xFF48BE92), size: 24),
        ],
      ),
    );
  }

  Widget _buildActivityDescription(Map<String, dynamic> activity) {
    // Determine the type of activity and build accordingly
    if (activity['type'] == 'group_creation') {
      return RichText(
        text: TextSpan(
          style: TextStyle(fontSize: 14, color: Colors.black),
          children: [
            TextSpan(text: activity['description'] + ' '),
            TextSpan(
              text: activity['group'],
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Color(0xFFFF5D5D), // Custom color for group name
                decoration: TextDecoration.underline, // Underline for group name
              ),
            ),
            TextSpan(text: '.'),
          ],
        ),
      );
    } else if (activity['type'] == 'payment') {
      return RichText(
        text: TextSpan(
          style: TextStyle(fontSize: 14, color: Colors.black),
          children: [
            TextSpan(text: activity['description'] + ' '),
            TextSpan(
              text: activity['user1'],
              style: TextStyle(
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.underline,
              ),
            ),
            TextSpan(text: ' to '),
            TextSpan(
              text: activity['user2'],
              style: TextStyle(
                fontWeight: FontWeight.bold,
                decoration: TextDecoration.underline,
              ),
            ),
            TextSpan(text: ' in '),
            TextSpan(
              text: activity['group'],
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Color(0xFFFF5D5D), // Custom color for group name
                decoration: TextDecoration.underline, // Underline for group name
              ),
            ),
            TextSpan(text: '.'),
          ],
        ),
      );
    }
    return SizedBox.shrink(); // Return empty if no matching type
  }
}


